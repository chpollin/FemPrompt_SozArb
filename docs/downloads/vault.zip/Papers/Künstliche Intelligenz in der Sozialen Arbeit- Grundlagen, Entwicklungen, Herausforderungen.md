---
title: "Künstliche Intelligenz in der Sozialen Arbeit: Grundlagen, Entwicklungen, Herausforderungen"
authors:
  - O. Steiner
  - D. Tschopp
year: 2022
type: journalArticle
doi: 10.1007/s12054-022-00546-4
url: 
tags:
  - paper
llm_decision: Include
llm_confidence: 0.92
llm_categories:
  - Generative_KI
  - KI_Sonstige
  - Soziale_Arbeit
  - Bias_Ungleichheit
human_decision: Exclude
human_categories:
  - KI_Sonstige
  - Soziale_Arbeit
  - Bias_Ungleichheit
agreement: disagree
---

# Künstliche Intelligenz in der Sozialen Arbeit: Grundlagen, Entwicklungen, Herausforderungen

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** AI_Literacies, KI_Sonstige, Soziale_Arbeit, Bias_Ungleichheit, Diversitaet, Fairness
**Argumente:** 4 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 92 |
| Correctness | 98 |
| Category Validation | 95 |
| **Overall Confidence** | **95** |

### Stufe 4: Assessment

**LLM:** Include (Confidence: 0.92)
**Human:** Exclude

**Kategorie-Vergleich (bei Divergenz):**

| Kategorie | Human | LLM | Divergent |
|-----------|-------|-----|----------|
| AI_Literacies | Nein | Nein |  |
| Generative_KI | Nein | Ja | X |
| Prompting | Nein | Nein |  |
| KI_Sonstige | Ja | Ja |  |
| Soziale_Arbeit | Ja | Ja |  |
| Bias_Ungleichheit | Ja | Ja |  |
| Gender | Nein | Nein |  |
| Diversitaet | Nein | Nein |  |
| Feministisch | Nein | Nein |  |
| Fairness | Nein | Nein |  |

## Wissensdokument

# Künstliche Intelligenz in der Sozialen Arbeit: Grundlagen, Entwicklungen, Herausforderungen

## Kernbefund

Während KI-Technologien wie Predictive Risk Modeling und Chatbots vielversprechende Potenziale für die Soziale Arbeit bieten, bestehen erhebliche Risiken durch Algorithmen-Bias, Datenschutzproblematiken und die Gefahr der Automatisierung sozialer Exklusion, insbesondere wenn KI zu Kosteneinsparungen statt professioneller Unterstützung eingesetzt wird.

## Forschungsfrage

Welche Potenziale, Grenzen und Risiken ergeben sich durch den Einsatz von Künstlicher Intelligenz in der Sozialen Arbeit?

## Methodik

Theoretisch/Review: Systematische Analyse von KI-Technologien und deren Anwendungsszenarien in der Sozialen Arbeit mit kritischer Reflexion bestehender Pilotprojekte und Forschungsliteratur
**Datenbasis:** Sekundäranalyse: Review von wissenschaftlichen Studien, Praxisbeispielen und Pilotprojekten (Neuseeland, Niederlande, klinisch-psychologische Settings); keine primäre Datenerhebung

## Hauptargumente

- KI ist ein interdisziplinäres und heterogenes Feld, das von enger spezialisierter KI bis zu genereller KI reicht; aktuelle Anwendungen basieren meist auf Machine Learning, Deep Learning und neuronalen Netzwerken, die eigenständig lernen und sich optimieren, aber eine 'Black-Box'-Charakteristik aufweisen, die Nachvollziehbarkeit erschwert.
- Predictive Risk Modeling in der Sozialen Arbeit (insbesondere Kindesschutz) verspricht Risikovorhersagen, reproduziert aber strukturelle Ungleichheiten und bestehende Biase der Trainingsdaten, während gleichzeitig reflexive Professionalität gefährdet wird und Datenschutzprobleme entstehen (function creeping, nationale Datenvernetzung).
- Chatbots zeigen hohe Akzeptanz und Engagement bei Nutzer:innen und könnten Beratung und Fallrekonstruktion unterstützen, dürfen aber menschliche Beziehungsarbeit nicht ersetzen und werfen Fragen zu Datensicherheit, digitaler Exklusion und der neo-liberalen Instrumentalisierung von Technologie zur Sparmaßnahmen auf.
- Die zentrale Problematik liegt nicht in der Technologie selbst, sondern in deren managerialisierter Nutzung im Kontext ökonomisierter Wohlfahrtsstaatlichkeit und der unzureichenden ethischen Reflexion sowie Verantwortungszumessung bei KI-gestützten Entscheidungen, die vulnerable Bevölkerungsgruppen betreffen.

## Kategorie-Evidenz

### Evidenz 1

Paper bietet umfassende Begriffserklärungen zu KI-Technologien (Algorithmen, Machine Learning, neuronale Netzwerke, Deep Learning) und diskutiert notwendiges Verständnis für Fachkräfte in der Sozialen Arbeit: 'Um einen groben Einblick in die Funktionsweise aktueller KI-Technologien zu geben, werden im folgenden Abschnitt einige zentrale Begriffe kurz dargestellt'

### Evidenz 2

Ausführliche Behandlung von Predictive Risk Modeling und Algorithmen im sozialen Bereich: 'Predictive Modelling soll im sozialen Bereich datenbasierte Vorhersagen mittels Algorithmen über menschliches Verhalten und Entwicklung treffen'; Analyse von Machine Learning und neuronalen Netzwerken in Entscheidungsunterstützungssystemen

### Evidenz 3

Direkter Fokus auf KI-Anwendungen in Sozialer Arbeit: Kindesschutz, Beratung, Fallrekonstruktion; kritische Analyse zweier Anwendungsszenarien (PRM und Chatbots) und deren Auswirkungen auf professionelle Praxis und Klient:innen

### Evidenz 4

Explizite Thematisierung von Algorithmen-Bias: 'die eingesetzten Algorithmen selbst sind mitnichten neutral, sondern bilden oftmals ungerechte Lebensbedingungen ab und drohen diese durch ihren Bias zu verstetigen'; Warnung vor 'automatisierter sozialer Exklusion durch Algorithmen' und Risiken für vulnerable Bevölkerungsgruppen

### Evidenz 5

Reflexion von Differenzen und Vulnerabilität: Fokus auf unterschiedliche Lebenssituationen, marginalisierte Gruppen (Armutspopulationen, Kinder in Gefährdungssituationen), Jugendliche mit chronischen Erkrankungen; Warnung vor technologischer Exklusion: 'Chatbots können Personen nicht zur Kommunikation animieren, die nicht an Hilfe interessiert sind'

### Evidenz 6

Diskussion von Fairness in algorithmischen Entscheidungssystemen: Potenzial zur Verminderung von 'practitioner bias' durch Standardisierung, aber gleichzeitige Gefahr der Reproduktion bestehender Ungerechtigkeiten; Qualität und Vollständigkeit von Trainingsdaten als Voraussetzung für faire Prädiktionen

## Assessment-Relevanz

**Domain Fit:** Sehr hohe Relevanz für die Schnittstelle KI und Soziale Arbeit. Das Paper bietet eine systematische Einführung in KI-Technologien speziell für Sozialarbeitende und analysiert konkrete Anwendungsszenarien kritisch. Besonders wertvoll ist die ethische Reflexion und die Warnung vor der neo-liberalen Instrumentalisierung von KI zur Kostenreduktion.

**Unique Contribution:** Das Paper leistet einen wichtigen deutschsprachigen Beitrag zur kritischen Analyse von KI in der Sozialen Arbeit, indem es technische Grundlagen mit ethischer Reflexion verbindet und die Gefahren für vulnerable Gruppen sowie die Professionalisierung von Sozialer Arbeit zentral setzt, anstatt nur Optimierungspotenziale zu betonen.

**Limitations:** Das Paper ist eine Literaturanalyse und Theoriereflexion ohne primäre empirische Datenerhebung; die Diskussion von Gender-Aspekten und intersektionalen Perspektiven bleibt unterentwickelt; Fokus liegt primär auf Kindesschutz und nicht auf andere Bereiche Sozialer Arbeit (z.B. Alter, Behinderung, Migration).

**Target Group:** Sozialarbeiter:innen, Fachkräfte in Wohlfahrtsorganisationen, Lehrende und Studierende der Sozialen Arbeit, Policy-Maker im Bereich Digitalisierung und Soziale Dienste, KI-Entwickler:innen im sozialen Sektor, sowie Ethiker:innen und Kritiker:innen von Technologisierung in Care-Arbeit

## Schlüsselreferenzen

- [[Eubanks_2018]] - Automating Inequality: How High-Tech Tools Profile, Police, and Punish the Poor
- [[Gillingham_2016]] - Predictive Risk Modelling to Prevent Child Maltreatment
- [[Oak_2016]] - A Minority Report for Social Work? PRM and Tuituia Assessment Framework
- [[Keymolen_Broeders_2013]] - Innocence Lost: Care and Control in Dutch Digital Youth Care
- [[de_Haan_Connolly_2014]] - Another Pandora's Box? Predictive Risk Modeling
- [[Schneider_Seelmeyer_2019]] - Challenges in Using Big Data for Decision Support Systems in Social Work
- [[Bendig_et_al_2019]] - The Next Generation: Chatbots in Clinical Psychology and Psychotherapy
- [[Jonas_1984]] - The Imperative of Responsibility: Ethics for the Technological Age
- [[Steiner_2021]] - Social Work in the Digital Era: Theoretical, Ethical and Practical Considerations
- [[Lenzen_2020]] - Künstliche Intelligenz: Fakten, Chancen, Risiken
