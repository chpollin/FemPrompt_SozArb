---
title: "AI Countergovernance: Lessons Learned from Canada and Paris"
authors:
  - B. Attard-Frost
  - A. Brandusescu
  - D. G. Widder
  - C. Tessono
year: 2025
type: report
doi: 
url: "https://techpolicy.press/ai-countergovernance-lessons-learned-from-canada-and-paris/"
tags:
  - paper
llm_decision: Include
llm_confidence: 0.82
llm_categories:
  - AI_Literacies
  - KI_Sonstige
  - Bias_Ungleichheit
  - Gender
  - Feministisch
human_decision: Exclude
human_categories:
  - KI_Sonstige
agreement: disagree
---

# AI Countergovernance: Lessons Learned from Canada and Paris

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** KI_Sonstige, Soziale_Arbeit, Bias_Ungleichheit, Diversitaet, Fairness
**Argumente:** 5 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 92 |
| Correctness | 98 |
| Category Validation | 95 |
| **Overall Confidence** | **95** |

### Stufe 4: Assessment

**LLM:** Include (Confidence: 0.82)
**Human:** Exclude

**Kategorie-Vergleich (bei Divergenz):**

| Kategorie | Human | LLM | Divergent |
|-----------|-------|-----|----------|
| AI_Literacies | Nein | Ja | X |
| Generative_KI | Nein | Nein |  |
| Prompting | Nein | Nein |  |
| KI_Sonstige | Ja | Ja |  |
| Soziale_Arbeit | Nein | Nein |  |
| Bias_Ungleichheit | Nein | Ja | X |
| Gender | Nein | Ja | X |
| Diversitaet | Nein | Nein |  |
| Feministisch | Nein | Ja | X |
| Fairness | Nein | Nein |  |

## Wissensdokument

# Submission on the Proposed Artificial Intelligence and Data Act

## Kernbefund

Das kanadische AIDA weist fünf kritische Regulierungslücken auf: unzureichende Definition von 'High-Impact Systems', zu enge Regulierungsweise auf nur High-Impact-Systeme, fehlende Anwendung auf öffentliche Institutionen, zu enge Definition von Schaden (nur Einzelpersonen statt Gemeinschaften), und problematische Regulatory Independence des Commissioners.

## Forschungsfrage

Welche kritischen Lücken und Verbesserungsmöglichkeiten bestehen in Kanadas Artificial Intelligence and Data Act (AIDA) in Bezug auf Regulierung, Fairness und Schutz marginalisierter Gemeinschaften?

## Methodik

Qualitativ - Multi-Stakeholder-Roundtable mit über 30 Experten aus Akademie, Zivilgesellschaft und Industrie; Policy-Analyse; Vergleichende Analyse mit EU AI Act
**Datenbasis:** Qualitative Roundtable-Diskussionen mit 30+ Stakeholdern; Dokumentenanalyse von Bill C-27 und Companion Documents; Vergleichende Analyse mit EU AI Act und kanadischer Directive on Automated Decision-Making

## Hauptargumente

- Das AIDA reguliert nur 'High-Impact' AI-Systeme und lässt damit breitere Schäden aus anderen AI-Systemen unreguliert, während die EU ein risikogestuftes System mit vier Kategorien verwendet, das alle Systeme in mindestens minimaler Form reguliert.
- Die Ausgrenzung des öffentlichen Sektors (Polizei, Immigration, Sicherheit, Armee) schafft eine regulatorische Lücke und einen doppelten Standard, besonders problematisch da diese Institutionen bereits AI-Systeme mit hohem Auswirkungspotenzial einsetzen (Gesichtserkennung, Hiring-Systeme).
- Die Harm-Definition des AIDA beschränkt sich auf individuelle Schäden und ignoriert kollektive Schäden gegenüber Bevölkerungsgruppen (Racial Profiling, Cambridge Analytica, Wahlbeeinflussung), was systemische Diskriminierung unzureichend erfasst.
- Der Commissioner wird vom ISED Minister ernannt und ist daher nicht unabhängig, wodurch Interessenskonflikte zwischen wirtschaftlicher Förderung und Risikominderung entstehen; ein unabhängiger Regulator (via Parlament oder Governor in Council) ist erforderlich.
- Pseudowissenschaftliche AI-Systeme zur Verhaltens- und Geisteszustands-Vorhersage (Biometric-basiert) sind nicht verboten, sondern reguliert, wobei die Beweislast für Diskriminierung bei betroffenen Personen liegt, die oft keinen Zugang zu Information oder Ressourcen haben.

## Kategorie-Evidenz

### Evidenz 1

Das Paper behandelt umfassend algorithmen Entscheidungssysteme, biometrische Systeme, Facial Recognition, AI in Einstellung, Sicherheit und Strafverfolgung sowie Data Governance: 'The AIDA proposes to establish an Artificial Intelligence and Data Commissioner' und 'systems used for biometric identification, education and training, legal and interpretation'

### Evidenz 2

Das Paper adressiert AI-Systeme in Kontexten, die für Soziale Arbeit zentral sind: Immigration, Strafverfolgung, Polizei, staatliche Dienstleistungen. 'The exclusion of public sector institutions from the AIDA creates regulatory gaps and sets a double standard. While the public and private sector have been historically regulated separately... it does not mean that government use of AI should be exempt from accountability and scrutiny.'

### Evidenz 3

Extensive Analyse algorithmischer Diskriminierung und struktureller Ungleichheiten: 'Researchers have debunked such practices as pseudoscience that can reinforce systemic forms of discrimination such as racism and sexism.' und 'racial profiling of racialized groups' sowie systematische Ausgrenzung marginalisierter Gruppen durch zu enge Harm-Definition.

### Evidenz 4

Das Paper fordert explizit Einbeziehung marginalisierter Gemeinschaften und betont fehlende Partizipation: 'we urge the government and Parliamentarians to pay special attention to how it can engage with the Canadian population more rigorously, especially those representing marginalized communities' sowie Fokus auf vulnerable Gruppen: 'systems that exploit vulnerable groups based on their age (such as children) or physical and mental disabilities'

### Evidenz 5

Fairness wird zentral behandelt durch Forderung nach fairem Ansatz: 'establish minimum transparency and accountability requirements for systems that pose 'lower' levels of impact' und Kritik an unfairen Audit-Prozessen: 'research shows that the quality of regulatory audits is poor when the auditee selects and compensates the auditor' sowie Fairness-basierte Kategorisierung analog EU AI Act mit risikogestuftem Ansatz

## Assessment-Relevanz

**Domain Fit:** Hochgradig relevant für die Schnittstelle KI und Soziale Arbeit: Das Paper behandelt Regulierung von AI-Systemen, die direkt in sozialen Diensten, Strafverfolgung und Wohlfahrtsverwaltung eingesetzt werden und marginalisierte Bevölkerungsgruppen betreffen, die traditionelle Zielgruppen Sozialer Arbeit sind.

**Unique Contribution:** Das Paper leistet einen kritischen Policy-Beitrag durch systematische Multi-Stakeholder-Analyse zur Identifikation von fünf grundlegenden Regulierungslücken in Kanadas AIDA, insbesondere zur Ausgrenzung öffentlicher Institutionen und zu engen Harm-Definitionen, mit konkreten Reformempfehlungen.

**Limitations:** Das Paper ist eine Policy-Submission ohne empirische Datenerhebung; die Roundtable-Teilnehmer sind primär Expert:innen und keine Vertreter:innen unmittelbar betroffener Gemeinschaften; tiefere empirische Analysen der Auswirkungen von AI in sozialen Diensten fehlen.

**Target Group:** Policy-Maker und Parlamentarier:innen (House of Commons Standing Committee on Industry & Technology), AI-Regulatoren, zivilgesellschaftliche Organisationen, Sozialarbeiter:innen in öffentlichen Institutionen, Datenschutzbeauftragte, kritische AI-Forscher:innen, marginalisierte Gemeinschaften und ihre Interessensvertretungen

## Schlüsselreferenzen

- [[Tessono_Christelle_Stevens_Yuan_Malik_Momin_Solomun_Sonja_Dwivedi_Supriya_Andrey_Sam_2022]] - AI Oversight, Accountability and Protecting Human Rights
- [[Gray_Mary_L_Suri_Siddharth_2019]] - Ghost Work: How to Stop Silicon Valley from Building a New Global Underclass
- [[Lyon_David_Murakami_Wood_David_2020]] - Big Data Surveillance and Security Intelligence
- [[Williams_Adrienne_Miceli_Milagros_Gebru_Timnit_2022]] - The Exploited Labor Behind Artificial Intelligence
- [[Stark_Luke_Hutson_Jevan_2022]] - Physiognomic Artificial Intelligence
- [[Raji_Inioluwa_Deborah_Xu_Peggy_Honigsberg_Colleen_Ho_Daniel_2022]] - Outsider Oversight: Designing a Third Party Audit Ecosystem for AI Governance
- [[Scassa_Teresa_2022]] - Comments on the Third Review of Canada's Directive on Automated Decision-Making
- [[Fair_Lesley_2019]] - FTC's $5 Billion Facebook Settlement: Record-Breaking and History-Making
- [[Innovation_Science_and_Economic_Development_Canada_2022]] - Learning Together for Responsible Artificial Intelligence: Report of the Public Awareness Working Group
- [[OECD_nicht angegeben]] - Creating a Culture of Independence: Practical Guidance Against Undue Influence
