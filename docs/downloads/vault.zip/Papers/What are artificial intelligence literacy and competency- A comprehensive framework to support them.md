---
title: What are artificial intelligence literacy and competency? A comprehensive framework to support them
authors:
  - Thomas K.F. Chiu
  - Zubair Ahmad
  - Murod Ismailov
  - Ismaila Temitayo Sanusi
year: 2024
type: journalArticle
doi: 10.1016/j.caeo.2024.100171
url: "https://linkinghub.elsevier.com/retrieve/pii/S2666557324000120"
tags:
  - paper
llm_decision: Exclude
llm_confidence: 0.7
llm_categories:
  - AI_Literacies
human_decision: Include
human_categories:
  - AI_Literacies
  - Generative_KI
  - Bias_Ungleichheit
  - Fairness
agreement: disagree
---

# What are artificial intelligence literacy and competency? A comprehensive framework to support them

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** AI_Literacies, Generative_KI, Prompting, KI_Sonstige, Bias_Ungleichheit, Gender, Diversitaet, Fairness
**Argumente:** 3 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 88 |
| Correctness | 92 |
| Category Validation | 87 |
| **Overall Confidence** | **89** |

### Stufe 4: Assessment

**LLM:** Exclude (Confidence: 0.7)
**Human:** Include

**Kategorie-Vergleich (bei Divergenz):**

| Kategorie | Human | LLM | Divergent |
|-----------|-------|-----|----------|
| AI_Literacies | Ja | Ja |  |
| Generative_KI | Ja | Nein | X |
| Prompting | Nein | Nein |  |
| KI_Sonstige | Nein | Nein |  |
| Soziale_Arbeit | Nein | Nein |  |
| Bias_Ungleichheit | Ja | Nein | X |
| Gender | Nein | Nein |  |
| Diversitaet | Nein | Nein |  |
| Feministisch | Nein | Nein |  |
| Fairness | Ja | Nein | X |

## Wissensdokument

# What are artificial intelligence literacy and competency? A comprehensive framework to support them

## Kernbefund

AI-Kompetenz umfasst fünf Schlüsselkomponenten (Technologie, Impact, Ethik, Kollaboration, Selbstreflexion) und sollte Vertrauen sowie selbstreflektive Mindsets integrieren, nicht nur technisches Wissen.

## Forschungsfrage

Wie können AI-Literalität und AI-Kompetenz für K-12-Schüler:innen definiert und durch ein umfassendes Framework unterstützt werden?

## Methodik

Mixed-Methods: Empirisch - iterativer Co-Design-Zyklus mit 30 erfahrenen AI-Lehrkräften aus 15 Schulen über 4 Zyklen mit Konsensabstimmung (75% Schwelle)
**Datenbasis:** n=30 Lehrkräfte (24 männlich, 6 weiblich) aus 15 mittleren Schulen in Hong Kong, durchschnittliches Alter 32 Jahre, mind. 3 Jahre AI-Unterrichtserfahrung

## Hauptargumente

- Bisherige AI-Literacy-Definitionen wurden aus ingenieurswissenschaftlicher Perspektive entwickelt und sind für K-12-Bildung ungeeignet; eine Neudefinition unter Berücksichtigung von Vertrauen und Selbstreflexion ist notwendig.
- AI-Bildung erfordert ein umfassendes Framework mit fünf Komponenten: Die technologische Grundlagen müssen mit Impact, Ethik, Kollaborationsfähigkeiten und Selbstreflektion verbunden werden.
- Praktiker:innenperspektiven (Lehrkräfte) sind essenziell für die Gestaltung von K-12-AI-Bildung; ein Co-Design-Ansatz generiert kontextgerechte, implementierbare Rahmenvorgaben.

## Kategorie-Evidenz

### Evidenz 1

Zentraler Fokus: 'AI literacy is defined as an individual's ability to clearly explain how AI technologies work and impact society...It focuses on knowing (i.e. knowledge and skills).'

### Evidenz 2

'These generative AI tools keep humans learning' und explizite Nennung von 'ChatGPT and Sora' als Beispiele disruptiver Technologien, die in K-12 behandelt werden müssen.

### Evidenz 3

'the students need to learn how to prompt effectively when using ChatGPT' und Diskussion von Prompt-Engineering als notwendige Fähigkeit.

### Evidenz 4

Umfangreiche Behandlung klassischer ML-Konzepte: 'machine learning, and cloud computing', 'big data (velocity, volume, value, variety, and veracity)', 'training models and learning algorithms'.

### Evidenz 5

'fairness and biases' als eines der fünf ethischen Prinzipien; Fokus auf 'risks' und 'potential harmful effects on society'.

### Evidenz 6

Geschlechterverteilung der Stichprobe wird dokumentiert: '24 male and 6 female participants' (20% weiblich), aber kein expliziter Gender-Analysefokus.

### Evidenz 7

'the framework promotes inclusive and diverse education, ensuring success for each student'; Erwähnung von 'underrepresented youth in STEM' und Förderung von Community Engagement.

### Evidenz 8

'fairness and biases' als Kernkomponente der Ethik-Curricula; 'trust and transparency, accountability, social benefit, privacy and security' als Fairness-Prinzipien.

## Assessment-Relevanz

**Domain Fit:** Das Paper ist hochrelevant für AI-Bildung und hat potenziellen Anwendungswert für inklusive Sozialisation in AI-Gesellschaften. Der Fokus auf Ethik, Bias, Diversität und gesellschaftliche Auswirkungen verbindet AI-Literalität mit sozialen Dimensionen, aber es fehlt eine explizite Verbindung zur Sozialen Arbeit als Disziplin oder Praxis.

**Unique Contribution:** Erstmalige systematische Co-Design-Entwicklung von AI-Kompetenz-Definition mit praktizierenden Lehrkräften, die Vertrauen und Selbstreflektion integriert und fünf implementierbare Lernkomponenten für K-12 operationalisiert.

**Limitations:** Begrenzte Geschlechterparität in der Stichprobe (20% weiblich); Framework wurde nicht im Feld validiert; Lehrkräfte-Kapazitätsaufbau nicht adressiert; keine Berücksichtigung von Schüler:innen mit besonderen Bedürfnissen.

**Target Group:** K-12 Lehrkräfte, AI-Curriculum-Designer, Bildungspolitiker:innen, Pädagog:innen in STEM-Bereichen, nicht-technische Fachpersonen, die AI-Kompetenzen vermitteln wollen. Sekundär: Sozialarbeiter:innen mit Bildungsauftrag in digitaler Inklusion.

## Schlüsselreferenzen

- [[Long_Magerko_2020]] - What is AI literacy? Competencies and design considerations
- [[Touretzky_et_al_2019]] - Five Big Ideas in AI / Envisioning AI for K-12
- [[Chiu_2021]] - A holistic approach to Artificial Intelligence (AI) curriculum for K-12 schools
- [[GardnerMcCune_et_al_2023]] - AI4future framework
- [[Xia_et_al_2022]] - Self-determination theory design approach for inclusive AI K-12 education
- [[Williams_et_al_2023]] - AI + ethics curricula for middle school youth
- [[Du_2023]] - Algorithmic literacy in AI-powered applications
- [[Falloon_2020]] - From digital literacy to digital competence
