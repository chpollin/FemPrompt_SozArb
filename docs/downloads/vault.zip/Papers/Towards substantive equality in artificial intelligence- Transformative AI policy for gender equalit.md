---
title: "Towards substantive equality in artificial intelligence: Transformative AI policy for gender equality and diversity"
authors:
  - P. Ricaurte Quijano
  - B. Prud’homme
year: 2024
type: report
doi: 
url: "https://wp.oecd.ai/app/uploads/2025/05/towards-substantive-equality-in-artificial-intelligence_Transformative-AI-policy-for-gender-equality-and-diversity.pdf"
tags:
  - paper
llm_decision: Include
llm_confidence: 0.95
llm_categories:
  - AI_Literacies
  - KI_Sonstige
  - Bias_Ungleichheit
  - Gender
  - Diversitaet
  - Feministisch
  - Fairness
human_decision: Exclude
human_categories: []
agreement: disagree
---

# Towards substantive equality in artificial intelligence: Transformative AI policy for gender equality and diversity

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** AI_Literacies, KI_Sonstige, Soziale_Arbeit, Bias_Ungleichheit, Gender, Diversitaet, Feministisch, Fairness
**Argumente:** 3 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 92 |
| Correctness | 96 |
| Category Validation | 94 |
| **Overall Confidence** | **93** |

### Stufe 4: Assessment

**LLM:** Include (Confidence: 0.95)
**Human:** Exclude

**Kategorie-Vergleich (bei Divergenz):**

| Kategorie | Human | LLM | Divergent |
|-----------|-------|-----|----------|
| AI_Literacies | Nein | Ja | X |
| Generative_KI | Nein | Nein |  |
| Prompting | Nein | Nein |  |
| KI_Sonstige | Nein | Ja | X |
| Soziale_Arbeit | Nein | Nein |  |
| Bias_Ungleichheit | Nein | Ja | X |
| Gender | Nein | Ja | X |
| Diversitaet | Nein | Ja | X |
| Feministisch | Nein | Ja | X |
| Fairness | Nein | Ja | X |

## Wissensdokument

# Towards Substantive Equality in Artificial Intelligence: Transformative AI Policy for Gender Equality and Diversity

## Kernbefund

KI-Systeme sind nicht neutral und reproduzieren strukturelle Ungleichheiten. Eine transformative Gleichstellungspolitik muss systembezogene Nachteile adressieren, demokratische Defizite überbrücken und Fehlrepräsentation umkehren durch inklusives Design, sinnvolle Partizipation und Accountability über den gesamten KI-Lebenszyklus.

## Forschungsfrage

Wie kann transformative KI-Politik Geschlechtergleichstellung und Vielfalt in KI-Ökosystemen fördern und strukturelle Ungleichheiten adressieren?

## Methodik

Mixed: Qualitativ - mehrsprachige regionale und gruppenspezifische Konsultationen mit multi-stakeholder Beteiligung in 5 Regionen (Asien, MENA, Nord-/Südamerika, Europa, Sub-Sahara-Afrika); Literaturanalyse; konzeptionelle Rahmenentwicklung
**Datenbasis:** Regionale und gruppenspezifische Konsultationen mit 100+ Teilnehmenden global; Projektberatungsgruppe mit 35+ Expert:innen; 8 Konsultationsexpert:innen; Analyse von Best Practices aus globalen Initiativen

## Hauptargumente

- KI-Systeme perpetuieren nicht nur durch technische Bias, sondern auch durch Ausschluss von marginalisierten Gruppen aus Designprozessen und Entscheidungsfindung - eine Form der algorithmischen Unterdrückung, die auf intersektionalen Machtverhältnissen basiert.
- Substantive Gleichstellung erfordert einen dreizeiligen Ansatz: Beseitigung systembezogener Nachteile durch faire Systeme, Überbrückung des demokratischen Defizits durch echte Partizipation, und Umkehrung von Fehlrepräsentation durch Würdeschutz und Anerkennung von marginalisierten Gruppen.
- Transformative KI-Politik muss Kapazitätsentwicklung, inklusives Design, Accountability-Mechanismen und sinnvolle Partizipation von Marginalisierten über den gesamten KI-Lebenszyklus integrieren - nicht nur einzelne technische Interventionen an einzelnen Phasen.

## Kategorie-Evidenz

### Evidenz 1

UNESCO Global Dialogue, Data Justice Policy Brief, AI & Equality Human Rights Toolbox, Indigenous Pathfinders in AI - alle fokussieren auf Kapazitätsentwicklung, öffentliche Bildung und AI-Literacies für diverse Gruppen.

### Evidenz 2

Umfassender Fokus auf KI-Lebenszyklen, algorithmische Entscheidungssysteme, KI-Governance, KI-Deployment und Auswirkungen auf verschiedene Bevölkerungsgruppen jenseits generativer KI.

### Evidenz 3

Explizite Fokussierung auf marginalisierte Communities, Junge, Frauen, Indigenous People, Personen mit Behinderungen, Migranten - zentrale Zielgruppen sozialer Arbeit. Integration von Menschenrechten und sozialer Gerechtigkeit als Kernrahmen.

### Evidenz 4

Zentral: 'AI systems reproduce the world models, cultural values, knowledge, and languages...thereby replicating or amplifying systemic inequalities based on gender, race, ethnicity, abilities, social class, and education.' Fokus auf algorithmic oppression und strukturelle Diskriminierung.

### Evidenz 5

Explizit im Titel und durchgehend: Geschlechtergerechtigkeit als Kernziel. UNESCO Global Dialogue on 'Artificial Intelligence and Gender Equality', Analyse von Gender-Bias in KI, sexualisierte Darstellungen racialiser Frauen durch AI image generators.

### Evidenz 6

Zentral: Inklusion von Indigenous Perspectives, Disability Justice, LGBTQI+ Perspektiven, mehrsprachige Global South Repräsentation. Indigenous Pathfinders in AI, RIADIS Workshop, intersektionale Perspektiven throughout.

### Evidenz 7

Explizite feministische Rahmengestaltung: Zitierung von 'feminist scholars (Benjamin, 2019; Eubanks, 2017; Noble and Roberts, 2019; West, 2020)' zu algorithmic oppression. Feminist AI Research Network als Co-Lead und Initiatoren. Data Feminism und intersektionale feministische Theorie strukturieren die Analyse.

### Evidenz 8

Behandlung von Fairness als Dimension von substantiver Gleichstellung, aber über technische Fairness-Metriken hinaus zu Würde, Anerkennung und Gerechtigkeit. 'Fairness' ist notwendig aber nicht hinreichend - erfordert demokratische Partizipation und Umkehrung von Fehlrepräsentation.

## Assessment-Relevanz

**Domain Fit:** Höchst relevant für die Schnittstelle KI/Soziale Arbeit/Gender: Das Report adressiert explizit die Auswirkungen von KI auf marginalisierte Gruppen (zentrale Zielgruppen sozialer Arbeit), integriert Gender-Perspektiven und feministische Theorie, und bietet policy-orientierte Empfehlungen für transformative Praxis.

**Unique Contribution:** Einzigartig ist die Integration eines transnationalen, partizipativen, mehrsprachigen Beratungsprozesses mit 100+ Stakeholdern aus dem Globalen Süden, kombiniert mit expliziter feministischer und intersektionaler Rahmengestaltung sowie einem sektoral-weiten Transformationsansatz, der über technische Lösungen zu Würde und Anerkennung führt.

**Limitations:** Report präsentiert best practices und policy-Empfehlungen, implementiert aber selbst keine empirischen Studien zur Wirksamkeit; Fokus auf Policy-Ebene mit weniger Granularität zu lokalen Kontexten; Messbarkeit von 'substantiver Gleichstellung' in der Praxis unklar.

**Target Group:** KI-Policymaker, Gouvernmentale und multilaterale AI-Governance-Akteure, KI-Entwickler und Deployer, Sozialarbeitende und NGOs mit Fokus auf marginalisierte Communities, Feminist AI Researchers, Global South Technologie-Aktivisten, Indigenous Leaders in Tech, Disability Rights Advocates

## Schlüsselreferenzen

- [[Benjamin_Ruha_2019]] - Race after Technology
- [[Eubanks_Virginia_2017]] - Automating Inequality
- [[Noble_Safiya_U_Roberts_Sarah_T_2019]] - Algorithms of Oppression/Critical Perspectives on Race and Technology
- [[West_Sarah_M_2020]] - Redistribution and Recognition: A Feminist Critique of Algorithmic Fairness
- [[DIgnazio_Catherine_Klein_Lauren_F_2020]] - Data Feminism
- [[Ricaurte_Paola_2019]] - Data Epistemologies, the Coloniality of Power, and Resistance
- [[UN_Women_2015]] - Progress of the World's Women 2015-2016: Substantive Equality for Women
- [[UNESCO_2022]] - Recommendation on the Ethics of Artificial Intelligence
