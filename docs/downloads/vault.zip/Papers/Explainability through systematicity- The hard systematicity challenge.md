---
title: "Explainability through systematicity: The hard systematicity challenge"
authors:
  - J. D. Santos
year: 2024
type: journalArticle
doi: 
url: "https://pmc.ncbi.nlm.nih.gov/articles/PMC12307450/"
tags:
  - paper
llm_decision: Exclude
llm_confidence: 0.95
llm_categories:
  - KI_Sonstige
human_decision: Include
human_categories:
  - Generative_KI
  - Prompting
  - Bias_Ungleichheit
  - Fairness
agreement: disagree
---

# Explainability through systematicity: The hard systematicity challenge

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** AI_Literacies, Generative_KI, KI_Sonstige, Bias_Ungleichheit, Fairness
**Argumente:** 5 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 88 |
| Correctness | 92 |
| Category Validation | 87 |
| **Overall Confidence** | **89** |

### Stufe 4: Assessment

**LLM:** Exclude (Confidence: 0.95)
**Human:** Include

**Kategorie-Vergleich (bei Divergenz):**

| Kategorie | Human | LLM | Divergent |
|-----------|-------|-----|----------|
| AI_Literacies | Nein | Nein |  |
| Generative_KI | Ja | Nein | X |
| Prompting | Ja | Nein | X |
| KI_Sonstige | Nein | Ja | X |
| Soziale_Arbeit | Nein | Nein |  |
| Bias_Ungleichheit | Ja | Nein | X |
| Gender | Nein | Nein |  |
| Diversitaet | Nein | Nein |  |
| Feministisch | Nein | Nein |  |
| Fairness | Ja | Nein | X |

## Wissensdokument

# Explainability Through Systematicity: The Hard Systematicity Challenge for Artificial Intelligence

## Kernbefund

Explainability ist nur eine Facette eines breiteren Ideals der Systematizität. Die angemessene Forderung an KI-Systeme ist nicht nur Mikro-Systematizität (Kompositionialität), sondern Makro-Systematizität: ein integriertes, konsistentes, kohärentes und parsimonisch prinzipiertes Gedankensystem. Diese Forderung wird durch fünf identifizierbare Rationales (kognitiv, hermeneutisch, epistemologisch, kritisch, regulativ) gerechtfertigt.

## Forschungsfrage

Inwiefern müssen wir von KI-Systemen erwarten, dass sie nicht nur explainabel sind, sondern systematisches Denken im umfassenden Sinne (Konsistenz, Kohärenz, Comprehensivität, Parsimoniosität) aufweisen?

## Methodik

Theoretisch - Konzeptuelle Analyse und Begriffsgeschichte; historische Rekonstruktion der Systematizität als epistemisches Ideal vom 18. Jahrhundert bis heute; philosophische Argumentation zur Defusion des 'Systematicity Challenge' von Fodor
**Datenbasis:** Keine empirischen Daten; theoretisches Paper basierend auf Literaturanalyse und konzeptuellem Argument

## Hauptargumente

- Der lange Schatten des Fodor/Pylyshin 'Systematicity Challenge' hat eine breitere, historisch bedeutsamere Konzeption von Systematizität verdunkelt, die auf Wolff, Kant und Lambert zurückgeht und Rationalität, Autorität und Wissenschaftlichkeit prägt.
- Systematizität im makrosystematischen Sinne (Konsistenz, Kohärenz, Comprehensivität, Parsimoniosität) ist fundamental für die Interpretierbarkeit und das echte Verständnis von KI-Outputs, nicht nur für die technische Explainability.
- Fünf historische Rationales rechtfertigen die Systematisierungsforderung: (1) Kognitive Integrativität, (2) Hermeneutische Funktion (Verständnis durch inferentielle Netze), (3) Epistemologische Qualitätskontrolle, (4) Kritische Funktion (Offenlegung von Inkonsisenzen), (5) Regulatorische/Verantwortlichkeitsfunktion (Fairness, Verifizierbeit von Entscheidungen).
- Die Forderung nach Systematizität selbst muss durch diese Rationales reguliert werden – eine dynamische Verstehensweise, die uns sagt, WIE und WANN AI-Systeme systematisch sein müssen.
- LLMs offenbaren ihre Grenzen genau da, wo sie das Ideal der Makro-Systematizität verfehlen: Inkonsistenzen zwischen Outputs, mangelnde rationale Kohärenz, ad-hoc Prinzipien, Mangel an Parcimony.

## Kategorie-Evidenz

### Evidenz 1

Zentrales Thema ist, wie wir KI-Systeme verstehen und bewerten sollen: 'the fundamental question, especially from the perspective of users as opposed to builders of these models, is to what extent AI exhibits systematicity of thought'

### Evidenz 2

Umfangreiche Diskussion von Large Language Models (LLMs) und Transformer-Architekturen: 'With the advent of transformer-based architectures (Vaswani et al., 2017), LLMs have become remarkably proficient at generating linguistic outputs'; detaillierte Analyse von LLM-Limitationen bezüglich Konsistenz und Kohärenz

### Evidenz 3

Diskussion von Neural Networks allgemein, Connectionism vs. Klassische Symbolische KI, Fodor/Pylyshin Systematicity Challenge, Kompositionialität, Architektur-Fragen

### Evidenz 4

Fairness und Bias-Probleme werden als Manifestationen fehlender Systematizität analysiert: 'Rendering fairness verifiable through systematicity is clearly a desirable feature in AI models. As the fast-growing literature on fair-AI and the various techniques for de-biasing these models brings out, the anxiety provoked by the opacity of these models stems in part from the worry that they might be biased'

### Evidenz 5

Fairness wird als vierte und fünfte Rationale für Systematisierung entwickelt: kritische Funktion (Aufdeckung von Bias durch Systematisierung) und Verantwortlichkeitsfunktion: 'That is part of what it means for the decision-making to be fair and to treat like cases alike. Systematicity provides accountability'

## Assessment-Relevanz

**Domain Fit:** Das Paper hat geringen direkten Bezug zu Sozialer Arbeit, ist aber hochrelevant für die philosophische Grundlegung von KI-Governance und die Kritik an KI-Systemen in sozial-relevanten Kontexten. Die Fairness- und Accountability-Argumente berühren zentrale Herausforderungen algorithmischer Entscheidungssysteme in Wohlfahrtsverwaltung.

**Unique Contribution:** Wiederentdeckung und Rekonstruktion eines historisch vergessenen, breiteren Systematizitäts-Ideals gegen die eng verstandene Fodor-Tradition; Entwicklung eines normativen Rahmens für epistemische und ethische Anforderungen an KI durch fünf Rationales der Systematisierung.

**Limitations:** Rein theoretisches Paper ohne empirische Validierung oder konkrete Methoden zur Operationalisierung von Makro-Systematizität in KI-Systemen; keine Diskussion von Zielkonflikten zwischen Systematizität und anderen Werten (Privacy, Effizienz, Autonomie).

**Target Group:** Philosophen und Theoretiker der KI, KI-Sicherheits- und Alignment-Forscher, Designende von explainbaren KI-Systemen, Policy-Maker im Bereich regulatorischer Anforderungen an KI (insbesondere in Hochrisiko-Anwendungen wie Wohlfahrt, Justiz), Informatiker mit Interesse an interpretierbarer und fairer KI

## Schlüsselreferenzen

- [[Fodor_J_A_Pylyshin_Z_W_1988]] - Connectionism and Cognitive Architecture: A Critical Analysis
- [[Vaswani_A_et_al_2017]] - Attention is All You Need
- [[Gaukroger_S_2020]] - The Failures of Philosophy
- [[HoyningenHuene_P_2013]] - Systematicity: The Nature of Science
- [[Rescher_N_2005]] - Cognitive Harmony: The Role of Systemic Harmony in the Constitution of Knowledge
- [[Brandom_R_2009]] - A Spirit of Trust: A Reading of Hegel's Phenomenology
- [[Sellars_W_1997]] - Empiricism and the Philosophy of Mind
- [[van_Fraassen_B_C_1980]] - The Scientific Image
