---
title: Who cares about data? Data care arrangements in everyday organisational practice
authors:
  - J. Jarke
  - S. Büchner
year: 2024
type: journalArticle
doi: 10.1080/1369118X.2024.2320917
url: 
tags:
  - paper
llm_decision: Exclude
llm_confidence: 0.85
llm_categories:
  - Soziale_Arbeit
human_decision: Exclude
human_categories:
  - KI_Sonstige
  - Soziale_Arbeit
agreement: agree
---

# Who cares about data? Data care arrangements in everyday organisational practice

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** KI_Sonstige, Soziale_Arbeit, Bias_Ungleichheit, Diversitaet, Feministisch, Fairness
**Argumente:** 3 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 92 |
| Correctness | 98 |
| Category Validation | 95 |
| **Overall Confidence** | **95** |

### Stufe 4: Assessment

**LLM:** Exclude (Confidence: 0.85)
**Human:** Exclude

## Wissensdokument

# Who cares about data? Data care arrangements in everyday organisational practice

## Kernbefund

Datenpflege ist nicht selbstverständlich, sondern ein soziomaterielles Accomplishment, das durch zugeschriebene Datenwerte und konkrete Pflegearbeiten in stabilen Datenpflegearrangements konfiguriert wird. Heterogene Arrangements entstehen, wenn Akteure unterschiedliche Werte (discovery, truthiness, actionability, self-evidence) Daten zuschreiben.

## Forschungsfrage

Warum und wie kümmern sich Menschen in Organisationen um Daten, und wie entstehen stabile Datenpflegearrangements im Alltag organisationaler Praxis?

## Methodik

Empirisch, qualitativ; zwei Fallstudien mit Interviews, Beobachtungen und Dokumentenanalyse in Jugendhilfeorganisationen (Deutschland) und Schulen (K-12 Bildung, Deutschland)
**Datenbasis:** Zwei qualitative Fallstudien: (1) Jugendhilfeservices mit IMPACT-Evaluationsdatensystem; (2) Schulen mit Stundenausfallsdatenberichterstattung an Ministerien. Inklusive Interviews mit Statistikern, Leitern von Jugendhilfediensten, Sozialarbeitern, Schulleitern, Stundenplanern.

## Hauptargumente

- Data care arrangements entstehen durch die Zuschreibung von Werten zu spezifischen Datensätzen und durch konkrete Arbeiten des Erstellens, Wartens und Reparierens von Daten. Diese Arrangements sind nicht homogen, sondern heterogen und standortgebunden.
- Im Fall der Jugendhilfe führen divergierende Datenwertschätzungen zwischen Management (discovery, truthiness, actionability) und Frontline-Arbeitern (competing care obligations) zu fragmentierten, multiplen Datenpflegearrangements und schlechter Datenqualität ("Swiss cheese").
- Im Fall der Bildung führen zwei ineinandergreifende und stabile Datenpflegearrangements (Stundenplanverwaltung mit self-evidence-Wert; Ministeriumsberichterstattung mit discovery-Wert) zu zuverlässigen Datenflüssen und höherer Datenqualität durch Translation und Dediziertes Datenpflegemanagement.

## Kategorie-Evidenz

### Evidenz 1

Fokus auf algorithmische Systeme, digitale Infrastrukturen, Datenverwaltungssysteme und automatisierte Prozesse in Organisationen: 'school management information systems (SMIS)', 'electronic patient records', 'data-driven technologies'.

### Evidenz 2

Empirische Fallstudie in Jugendhilfeorganisationen mit Fokus auf Sozialarbeitspraxis, Fallkonferenzen und Beratungsarbeit: 'social workers', 'youth welfare services', 'case work', 'Care Planning Conferences'.

### Evidenz 3

Adressiert strukturelle Ungleichheiten in Datenpflegearrangements: 'invisibility and devaluation of care labour often goes hand in hand with the invisibility and devaluation of additional data labour'. Thematisiert, wie Frontline-Arbeiter marginalisiert werden: 'workers...somehow doing data work in addition to and alongside their existing tasks'.

### Evidenz 4

Analyse heterogener und marginalisierter Positionen: unterschiedliche Berufsgruppen (Sozialarbeiter, Lehrer, Schulsekretärinnen, Stundenplaner) mit divergierenden Perspektiven und Pflegepflichten; intersektionale Analyse von Organisationshierarchien und Professionen.

### Evidenz 5

Explizit auf Feminist STS und Care-Theorie gegründet: 'In feminist STS, an interesting body of scholarship has extended research on care work'. Referenzen auf Puig de la Bellacasa (care as ethico-political obligation), Mol (logic of care), Criado & Rodríguez-Giralt (sociomaterial care arrangements). Verwendet feministische Konzepte von 'persistent tinkering', 'dark sides of care', Paternalismus und relationalen Arrangements.

### Evidenz 6

Adressiert faire Datenverwaltung und gerechtigkeit in Datenpflegearrangements: 'dialogue is needed between the multiple departments, hierarchies and professions about prioritisation and the work behind requirements for more and better data'. Kritisiert, dass Managements Datenwerte ohne Berücksichtigung von Frontline-Realitäten durchgesetzt werden, was zu unfairen Arbeitslasten und Datenqualitätsproblemen führt.

## Assessment-Relevanz

**Domain Fit:** Hochrelevant für die Schnittstelle Soziale Arbeit/Digitalisierung/organisationale Gerechtigkeit. Das Paper adressiert zentral die Herausforderungen, wenn digitale Systeme in Sozialdienstleistungen implementiert werden und zeigt, wie frontline-Arbeiter mit konkurrierenden Pflegepflichten belastet werden. Besonders wertvoll für feministische und kritische Perspektiven auf Datenpflege als unsichtbare, untervalueierte Arbeit.

**Unique Contribution:** Das Paper entwickelt das neuartige Konzept der 'data care arrangements' (Datenpflegearrangements) als analytisches Werkzeug, das heterogene, standortgebundene Datenverwaltungspraktiken in alltäglichen Organisationen sichtbar macht und dabei die unsichtbare, oft unbezahlte oder unterbewertete Laborarbeit an der Schnittstelle von Datenverwaltung und Care-Arbeit theorisiert.

**Limitations:** Fallstudien beschränkt auf Deutschland (Jugendhilfe, Bildung), begrenzte Anzahl von Fällen, keine Analyse von Outcomes oder Wirkungen auf Service-Qualität für Nutzer. Fokus liegt auf Arbeitspraktiken, nicht auf Perspektiven der Datensubjekte (Eltern, Kinder, Schüler).

**Target Group:** Sozialarbeiter, Care-Fachkräfte, Organisationsführung im Sozial- und Bildungssektor, Policymaker für digitale Transformation in Sozialservices, Forscher in STS/Feminist Theory/Care Studies, Datenverwaltungsexperten, Befürworter von gerechter Digitalisierung

## Schlüsselreferenzen

- [[Puig_de_la_Bellacasa_María_2011]] - Matters of care in technoscience: Assembling neglected things
- [[Mol_Annemarie_Moser_Ingunn_Pols_Jeannette_2010]] - Care in practice: On tinkering in clinics, homes and farms
- [[Pine_Karen_H_Bossen_Claus_2020]] - Good organizational reasons for better medical records: The data work of clinical documentation integrity specialists
- [[Pink_Sarah_Ruckenstein_Minna_Berg_Marc_Lupton_Deborah_2022]] - Everyday automation: Experiencing and anticipating emerging technologies
- [[Hoeyer_Klaus_Wadmann_Selma_2020]] - Meaningless work: How the datafication of health reconfigures knowledge about work and erodes professional judgement
- [[Suchman_Lucy_2007]] - Human-Machine reconfigurations: Plans and situated actions
- [[Criado_Tatiana_S_RodríguezGiralt_Ignacio_2016]] - Caring through design?
- [[DIgnazio_Catherine_Klein_Lauren_F_2020]] - Data feminism
- [[Tronto_Joan_C_2013]] - Caring democracy: Markets, equality, and justice
- [[Bossen_Claus_Chen_Yu_Pine_Karen_H_2019]] - The emergence of new data work occupations in healthcare: The case of medical scribes
