---
title: "The AI literacy development canvas: Assessing and building AI literacy in organizations"
authors:
  - Alexander Benlian
  - Marc Pinski
year: 2024
type: journalArticle
doi: 10.1016/j.bushor.2025.10.001
url: "https://linkinghub.elsevier.com/retrieve/pii/S0007681325001673"
tags:
  - paper
llm_decision: Exclude
llm_confidence: 0.85
llm_categories:
  - AI_Literacies
human_decision: Include
human_categories:
  - AI_Literacies
  - Generative_KI
  - Prompting
  - Bias_Ungleichheit
  - Fairness
agreement: disagree
---

# The AI literacy development canvas: Assessing and building AI literacy in organizations

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** AI_Literacies, Generative_KI, KI_Sonstige, Bias_Ungleichheit, Diversitaet, Fairness
**Argumente:** 3 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 92 |
| Correctness | 96 |
| Category Validation | 94 |
| **Overall Confidence** | **94** |

### Stufe 4: Assessment

**LLM:** Exclude (Confidence: 0.85)
**Human:** Include

**Kategorie-Vergleich (bei Divergenz):**

| Kategorie | Human | LLM | Divergent |
|-----------|-------|-----|----------|
| AI_Literacies | Ja | Ja |  |
| Generative_KI | Ja | Nein | X |
| Prompting | Ja | Nein | X |
| KI_Sonstige | Nein | Nein |  |
| Soziale_Arbeit | Nein | Nein |  |
| Bias_Ungleichheit | Ja | Nein | X |
| Gender | Nein | Nein |  |
| Diversitaet | Nein | Nein |  |
| Feministisch | Nein | Nein |  |
| Fairness | Ja | Nein | X |

## Wissensdokument

# The AI literacy development canvas: Assessing and building AI literacy in organizations

## Kernbefund

AI-Literacy muss multidimensional (konzeptuell, ethisch, praktisch) und rollenspezifisch sein. Die vorgestellte AI Literacy Assessment Matrix und AI Literacy Development Canvas bieten Organisationen ein strukturiertes Rahmenwerk zur Diagnose von Kompetenzlücken und zur Umsetzung gezielter Upskilling-Programme auf allen Organisationsebenen.

## Forschungsfrage

Wie können Organisationen AI-Kompetenzen systematisch bei Führungskräften, mittlerem Management und allgemeinen Mitarbeitern bewerten und entwickeln?

## Methodik

Theoretisch und praxisorientiert mit illustrierender Fallstudie; kombiniert akademische Forschung (Knoth et al. 2024, Ng et al. 2021) mit Unternehmensworkshops und Interviews bei PharmaCo
**Datenbasis:** Qualitativ: Multiple Workshops und Interviews mit PharmaCo; literaturgestützt auf bestehende AI-Literacy-Forschung

## Hauptargumente

- AI-Literacy ist ein strategischer, ethischer und rechtlicher Imperativ für Organisationen, besonders angesichts von Compliance-Risiken (EU AI Act mit Bußgeldern bis 7% des Gesamtumsatzes) und dokumentierten Fällen von algorithmischer Diskriminierung (z.B. Workday-Klage).
- Unterschiedliche Organisationsrollen erfordern unterschiedliche AI-Literacy-Profile: Führungskräfte benötigen strategisches Verständnis für Business-Implikationen und Risikomanagement; mittleres Management benötigt operative Integrationsfähigkeit; allgemeine Mitarbeiter benötigen praktische Anwendungskompetenz und kritisches Denken.
- Ein ganzheitliches Literacy-Modell mit tripartiter Struktur (Kognition-Verhalten-Einstellung) über drei Domänen (generische AI-Konzepte, domänenspezifische Anwendungen, Ethik) ist notwendig, um fragmentierte und ineffektive AI-Adoption zu vermeiden.

## Kategorie-Evidenz

### Evidenz 1

AI literacy refers to 'the cognitive and behavioral capabilities that enable individuals at all organizational levels to critically understand, evaluate, and interact with AI systems' (Ng et al., 2021); umfangreicher Fokus auf tripartites Kompetenzmodell (Cognition-Behavior-Attitude) über Konzeptuelles, Ethisches und Praktisches.

### Evidenz 2

Explizite Erwähnungen von 'generative AI', GenAI-Tools für Mitarbeiter: 'Non-IT employees increasingly rely on AI tools in their daily work' inkl. 'generative AI for drafting reports or AI-enhanced customer service platforms'; Fallstudie erwähnt 'advanced prompting techniques'.

### Evidenz 3

Umfassende Behandlung von AI-Systemen jenseits Generativ-KI: 'AI-based applicant recommendation systems', 'AI-driven applications', 'algorithmic decision-making', 'predictive maintenance', 'sales analytics', 'recruitment screening'.

### Evidenz 4

Workday-Fallbeispiel mit Anklage wegen Geschlechts-, Alters- und Behinderungsdiskriminierung; Thematisierung von 'algorithmic bias' und 'bias in automated decision-making'; Forderung nach Verständnis für 'AI limitations, such as bias in automated decision-making'.

### Evidenz 5

Erwähnung verschiedener Organisationsgruppen und deren unterschiedliche Zugänge; Fokus auf 'employees at all levels', 'diverse workforce populations'; Pharma-Fallstudie behandelt drei verschiedene Mitarbeitersegmente (Executives, Middle Managers, Non-IT Staff) mit differenzierten Bedarfen.

### Evidenz 6

Explizite Erwähnung von Fairness im Kontext AI governance: 'fair AI systems', 'bias-aware AI adoption'; Regulatory Compliance und ethische Standards als zentral; EU AI Act Compliance als Fairness-Requirement.

## Assessment-Relevanz

**Domain Fit:** Das Paper ist hochrelevant für KI-Kompetenzentwicklung und Organisationslernens, jedoch hat es KEINEN direkten Bezug zu Sozialer Arbeit als Fachdisziplin oder deren spezifischen Zielgruppen. Die Relevanz liegt primär im Unternehmenskontext (Pharmazie, allgemein). Für die Schnittstelle AI/Soziale Arbeit/Gender ist das Paper nur marginal relevant.

**Unique Contribution:** Das Paper bietet ein praktisches, rollenspezifisches Rahmenwerk (zwei komplementäre Tools: Assessment Matrix und Development Canvas) zur systematischen Diagnose und strategischen Entwicklung von AI-Kompetenz auf Organisationsebene, was in existierenden Ansätzen für nicht-technische, heterogene Workforces fehlt.

**Limitations:** Das Paper ist Industry-agnostisch positioniert, doch die empirische Validierung beschränkt sich auf eine Fallstudie im Pharmasektor; Generalisierbarkeit auf KMU, unterschiedliche kulturelle Kontexte und evolvierende Technologien (z.B. Autonome Systeme) ist unklar; keine Longitudinalstudien zur langfristigen Wirksamkeit vorhanden.

**Target Group:** Unternehmensführungskräfte, HR-Profis, Change-Manager und Organisationsentwickler in großen Organisationen; Berater im Digital-Transformation-Kontext; mittleres Management als Zielgruppe für AI-Upskilling; sekundär: KI-Forscher im Bereich Organizational Learning und Digital Literacy

## Schlüsselreferenzen

- [[Ng_et_al_2021]] - Conceptualizing AI literacy: An exploratory review
- [[Long_Magerko_2020]] - What is AI literacy? Competencies and design considerations
- [[Knoth_et_al_2024]] - Developing a holistic AI literacy assessment matrix
- [[Pinski_Benlian_2024]] - AI literacy for users - A comprehensive review
- [[Almatrafi_et_al_2024]] - A systematic review of AI literacy conceptualization
- [[Sunyaev_et_al_2025]] - High-Risk Artificial Intelligence
- [[Bartsch_et_al_2025]] - Governance of High-Risk AI Systems
- [[Brenner_et_al_2025]] - AI Bias Lawsuit Against Workday
