---
title: Voll (dia)logisch? Ein Werkstattbericht über den Einsatz von generativer KI in der Hochschulbildung für Soziale Arbeit – Curriculare Überlegungen und veränderte Akteurskonstellationen
authors:
  - E. Engelhardt
  - T. Ley
year: 2025
type: bookSection
doi: 
url: "https://www.pedocs.de/volltexte/2025/33133/pdf/Engelhardt_Ley_2025_Voll_dia_logisch.pdf"
tags:
  - paper
llm_decision: Include
llm_confidence: 0.95
llm_categories:
  - AI_Literacies
  - Generative_KI
  - Prompting
  - Soziale_Arbeit
human_decision: Include
human_categories:
  - Generative_KI
  - Prompting
  - KI_Sonstige
  - Soziale_Arbeit
  - Bias_Ungleichheit
agreement: agree
---

# Voll (dia)logisch? Ein Werkstattbericht über den Einsatz von generativer KI in der Hochschulbildung für Soziale Arbeit – Curriculare Überlegungen und veränderte Akteurskonstellationen

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** AI_Literacies, Generative_KI, Prompting, Soziale_Arbeit, Bias_Ungleichheit, Diversitaet, Fairness
**Argumente:** 4 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 92 |
| Correctness | 98 |
| Category Validation | 95 |
| **Overall Confidence** | **95** |

### Stufe 4: Assessment

**LLM:** Include (Confidence: 0.95)
**Human:** Include

## Wissensdokument

# Voll (dia)logisch? Ein Werkstattbericht über den Einsatz von generativer KI in der Hochschulbildung für Soziale Arbeit. Curriculare Überlegungen und veränderte Akteurskonstellationen

## Kernbefund

Generative KI sollte nicht nur als Werkzeug, sondern als kooperativer nicht-menschlicher Akteur verstanden werden, der transformativ in Hochschulbildung einschreitet und neue curriculare sowie didaktische Anforderungen schafft.

## Forschungsfrage

Welche Potenziale und Herausforderungen entstehen durch den Einsatz generativer KI in der Hochschulbildung für Soziale Arbeit, und wie verändern sich die Rollen von Lehrenden und Lernenden?

## Methodik

Theoretisch; Werkstattbericht mit praktischen Szenarien und konzeptionellen Überlegungen basierend auf Fachliteratur und Praxiserfahrungen
**Datenbasis:** Keine empirische Datenerhebung; basiert auf Literaturanalyse, konzeptionellen Überlegungen und drei idealtypischen Anwendungsszenarien

## Hauptargumente

- Generative KI-Systeme wie ChatGPT bieten Potenziale zur Bereicherung und Diversifizierung von Lehr-/Lernprozessen, erfordern aber eine ausgewogene Nutzung, die akademische Redlichkeit sicherstellt und kritische Denk- und Analysefähigkeit fördert.
- Die Rolle der KI in der Hochschulbildung sollte über eine verkürzte Chancen-Risiken-Diskussion hinausgehen und als transformative Funktion verstanden werden, wobei KI-Tools als kooperative Agenten und nicht-menschliche Akteure fungieren, die sich in die Hochschulbildung einschreiben.
- Prompting-Kompetenz stellt eine metakognitive Grundfähigkeit dar, die Studierende erwerben müssen, um KI-Systeme effektiv zu steuern und eigene Recherche- und Arbeitsprozesse selbstreflexiv zu gestalten.
- Für die Hochschulbildung Sozialer Arbeit ergeben sich curriculare Konsequenzen in drei Bereichen: Data Literacy in fachwissenschaftlichen Grundlagen, neue didaktische Methoden für die Vermittlung von Beratungskompetenzen, und kritische Reflexion der ethischen, sozialen und diskriminierenden Potenziale von KI.

## Kategorie-Evidenz

### Evidenz 1

Prompting-Kompetenz als 'metakognitive Fähigkeit' und 'grundlegende Fähigkeit' wird als zentral für Studierende erachtet. Darüber hinaus wird 'Data Literacy' als grundlegende Informations- und Datenkompetenz für das Studium der Sozialen Arbeit gefordert.

### Evidenz 2

Der gesamte Artikel konzentriert sich auf Large Language Models wie ChatGPT und GPT-4o. Es werden drei konkrete Anwendungsszenarien mit generativer KI beschrieben: akademische Schreibassistenz, methodischer Übungspartner und Chatbots als Produktivumgebung.

### Evidenz 3

Ein ganzer Abschnitt (Kapitel 3) ist dem Prompting gewidmet: 'Prompting-Kompetenz kann man demnach als eine metakognitive Fähigkeit beschreiben, die sich auf die effektive Formulierung von Fragen und Anweisungen bezieht.' Chain-of-Thought-Prompting wird als nützliche Vorgehensweise erläutert.

### Evidenz 4

Der gesamte Artikel behandelt explizit die Hochschulbildung für Soziale Arbeit. Es werden Szenarien zur Beratungsausbildung, zur Einübung von Beratungstechniken und zur Entwicklung von Chatbots für Hilfearrangements in der Sozialen Arbeit diskutiert.

### Evidenz 5

Der Artikel thematisiert 'systematische Verzerrung und der Reproduktion von Vorurteilen (sog. bias)', die 'Auswahl der Trainingsdaten kann zu einer systematischen Verzerrung und der Reproduktion von Vorurteilen (sog. bias) führen' und fordert, dass 'das normierende und diskriminierende Potenzial, das zur datengetriebenen Reproduktion und Verschärfung sozialer Ungleichheit führen kann, hervorgehoben werden' müsse.

### Evidenz 6

Die Autoren fordern 'die heterogenen Vorausetzungen und Zugänge Lernender (und Lehrender) didaktisch zu beachten' und weisen auf Fragen digitaler Teilhabe hin. Sie betonen, dass unterschiedliche Hilfesettings und -arrangements in den Blick genommen werden können.

### Evidenz 7

Der Artikel behandelt ethische Fragen der KI-Nutzung, einschließlich 'ethischen Umgang mit KI-generierten Daten' und fordert eine 'wertebasierte Diskussion' sowie die Berücksichtigung 'ethischer Aspekte der Bot-Nutzung'.

## Assessment-Relevanz

**Domain Fit:** Das Paper hat hohe Relevanz für die Schnittstelle KI und Soziale Arbeit durch konkrete Szenarien für Hochschulbildung, didaktische Ansätze und die Betonung ethischer sowie sozialer Implikationen von KI in einem sozialen Handlungsfeld.

**Unique Contribution:** Der Beitrag bietet eine über Chancen-Risiken-Debatten hinausgehende konzeptionelle Rahmung, die generative KI als kooperativen nicht-menschlichen Akteur theoretisiert und konkrete, implementierbare Szenarien für die Hochschulbildung Sozialer Arbeit entwickelt.

**Limitations:** Der Artikel basiert nicht auf empirischen Daten, sondern auf theoretischen Überlegungen und idealtypischen Szenarien; fachwissenschaftliche Fragen zur Nutzung von KI in der beruflichen Praxis der Sozialen Arbeit werden explizit ausgeblendet.

**Target Group:** Hochschullehrende in Sozialer Arbeit, Curriculumentwickler, Studierende der Sozialen Arbeit, Bildungsforscher, Policymaker in Hochschulbildung, sowie Fachvertreter der Sozialen Arbeit, die sich mit Digitalisierung auseinandersetzen

## Schlüsselreferenzen

- [[Rammert_Werner_2007]] - Technik - Handeln - Wissen. Zu einer pragmatistischen Technik- und Sozialtheorie
- [[Linnemann_Gesa__Löhe_Julian__Rottkemper_Beate_2024]] - Bedeutung von Selbstoffenbarungseffekten in quasisozialen Beziehungen mit auf generativer KI basierten Systemen
- [[Ley_Thomas__Seelmeyer_Udo_2020]] - Digitale Technologien als Informationsinfrastrukturen
- [[Weßels_Doris_2022]] - ChatGPT - ein Meilenstein der KI-Entwicklung
- [[Reinmann_Gabi__Watanabe_Alice_2024]] - KI in der universitären Lehre: Vom Spannungs- zum Gestaltungsfeld
- [[Witter_Stefanie_et_al_2024]] - ChatGPT im Studium der Sozialen Arbeit. Eine quantitative Studie zur Nutzung, Bewertung und Thematisierung
- [[Schreiber_Gerhard__Ohly_Lukas_2024]] - KI:Text. Diskurse über KI-Textgeneratoren
- [[Engelhardt_Emily_2024]] - Einsatz generativer KI in der Beratungsausbildung: Lehrmethoden und Praxisbeispiele
