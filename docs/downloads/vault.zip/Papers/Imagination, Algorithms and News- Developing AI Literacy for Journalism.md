---
title: "Imagination, Algorithms and News: Developing AI Literacy for Journalism"
authors:
  - Mark Deuze
  - Charlie Beckett
year: 2022
type: journalArticle
doi: 10.1080/21670811.2022.2119152
url: "https://www.tandfonline.com/doi/full/10.1080/21670811.2022.2119152"
tags:
  - paper
llm_decision: Exclude
llm_confidence: 0.75
llm_categories:
  - AI_Literacies
  - KI_Sonstige
human_decision: Exclude
human_categories:
  - AI_Literacies
  - KI_Sonstige
  - Bias_Ungleichheit
agreement: agree
---

# Imagination, Algorithms and News: Developing AI Literacy for Journalism

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** AI_Literacies, KI_Sonstige, Bias_Ungleichheit, Diversitaet, Fairness
**Argumente:** 3 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 92 |
| Correctness | 96 |
| Category Validation | 95 |
| **Overall Confidence** | **94** |

### Stufe 4: Assessment

**LLM:** Exclude (Confidence: 0.75)
**Human:** Exclude

## Wissensdokument

# Imagination, Algorithms and News: Developing AI Literacy for Journalism

## Kernbefund

AI-Literalität für Journalismus erfordert nicht nur technisches Wissen, sondern auch kritisches Verständnis der normativen Dimensionen von KI, die Fähigkeit zur Reflexion über Einsatzmöglichkeiten, und eine Kultur der Imagination statt bloßer instrumenteller Anwendung. Ein großes Wissensdefizit in der Nachrichtenindustrie gefährdet deren Autonomie gegenüber Tech-Konzernen.

## Forschungsfrage

Wie können Journalist:innen und die Nachrichtenindustrie AI-Literalität entwickeln, um KI-Systeme kreativ, ethisch und verantwortungsvoll in ihrer Arbeit einzusetzen?

## Methodik

Theoretisch/Konzeptionell basierend auf track record der Autoren in Medientechnologie-Forschung und der LSE JournalismAI Initiative; Taxonomie-Entwicklung und konzeptuelle Analyse

## Hauptargumente

- Die Nachrichtenindustrie überemphasiert instrumentale über imaginative Ansätze zu KI, wodurch die kreativen Potenziale ungenutzt bleiben und technische Lösungen als Selbstzweck behandelt werden.
- Das Narrativ von KI als allmächtige, perfekte Technologie ist historisch fallacious und verschleiert die messy Infrastruktur, ethischen Probleme (Bias, Exploitation, Datenschutz, Umweltfolgen) und die menschliche Gestaltung von KI-Systemen.
- AI-Literalität sollte als reflexiver Prozess verstanden werden, der nicht nur Wissen über KI umfasst, sondern auch die Fähigkeit zur kreativen Anwendung, zum kritischen Umgang mit Bias und Ungleichheit, sowie zur Imaginierung neuer journalistischer Praktiken jenseits bloßer Automation.

## Kategorie-Evidenz

### Evidenz 1

AI literacy defined as 'knowledge and beliefs about artificial intelligence which aid their recognition, management, and application' with three key components: knowledge about AI, ability to recognize instances where AI should/shouldn't be applied, and skills to teach others about AI implementation.

### Evidenz 2

Discusses machine learning, natural language processing, automated statistical data analysis, algorithms, and their pervasive role in journalism workflows from story ideation to monetization.

### Evidenz 3

AI systems are 'vulnerable to manipulations and mistakes, tend to be systemically biased, amplifying and exacerbating existing inequalities.' Paper identifies urgent historical-ethical concerns including 'technology bias, machine-driven exploitation of human labor, loss of human dignity at work governed by automated systems... particularly affect society's least privileged individuals and communities.'

### Evidenz 4

AI presented 'as an amplifier of all existing issues that benchmark contemporary journalism and its role in society, including how it wins (and loses) trust, how it covers and exemplifies diversity and inclusion, and how it assumes responsibility for the key challenges we all face in the 21st century.'

### Evidenz 5

Discusses fairness concerns in relation to AI's role in journalism: 'how it covers and exemplifies diversity and inclusion' and the danger of 'journalism being captured by technology (and the tech sector)' rather than using it responsibly. Emphasizes critical awareness of 'ways in which AI tends to amplify existing social and digital inequalities when left to technology companies.'

## Assessment-Relevanz

**Domain Fit:** Das Paper ist relevant für die KI-Literacy-Debatte und thematisiert systemische Ungleichheiten sowie Bias in KI-Systemen, hat aber keinen direkten Bezug zu Sozialer Arbeit oder Gender Studies. Die Perspektive auf marginalisierte Communities und Fairness ist jedoch transferierbar auf andere Domänen.

**Unique Contribution:** Das Paper entwickelt ein theoretisches Framework für AI-Literacy in der Journalistik, das über technisches Wissen hinausgeht und normative, ethische und imaginative Dimensionen integriert, sowie vor der Mythologisierung von KI als allmächtige Technologie warnt.

**Limitations:** Keine empirischen Daten oder Fallstudien; fokussiert primär auf Journalismus ohne Bezug zu anderen Branchen oder Sozialer Arbeit; Evidenz für AI-Knowledge-Defizite stammt hauptsächlich aus der LSE JournalismAI Initiative ohne breitere Datenbasis.

**Target Group:** Journalist:innen, Medienschaffende, Redakteur:innen, Medieneducator:innen, Policymaker im Medienbereich, KI-Ethiker:innen, sowie Personen interessiert in Fragen von Algorithmen-Governance und Digital Literacy in professionellen Kontexten

## Schlüsselreferenzen

- [[Anderson_C_W_2018]] - Apostles of Certainty: Data Journalism and the Politics of Doubt
- [[Beckett_C_and_M_Deuze_2016]] - On the Role of Emotion in the Future of Journalism
- [[Deuze_M_2023]] - Life in Media
- [[Kissinger_H_A_E_Schmidt_and_D_Huttenlocher_2021]] - The Age of AI and Our Human Future
