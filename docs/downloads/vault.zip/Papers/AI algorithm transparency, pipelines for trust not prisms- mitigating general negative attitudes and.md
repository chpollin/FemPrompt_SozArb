---
title: "AI algorithm transparency, pipelines for trust not prisms: mitigating general negative attitudes and enhancing trust toward AI"
authors:
  - K. Park
  - H. Y. Yoon
year: 2025
type: journalArticle
doi: 10.1057/s41599-025-05116-z
url: "https://www.nature.com/articles/s41599-025-05116-z"
tags:
  - paper
llm_decision: Exclude
llm_confidence: 0.85
llm_categories:
  - AI_Literacies
  - Prompting
  - KI_Sonstige
  - Fairness
human_decision: Exclude
human_categories:
  - AI_Literacies
  - Generative_KI
  - Bias_Ungleichheit
agreement: agree
---

# AI algorithm transparency, pipelines for trust not prisms: mitigating general negative attitudes and enhancing trust toward AI

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** AI_Literacies, Generative_KI, KI_Sonstige, Bias_Ungleichheit, Diversitaet, Fairness
**Argumente:** 3 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 92 |
| Correctness | 98 |
| Category Validation | 95 |
| **Overall Confidence** | **94** |

### Stufe 4: Assessment

**LLM:** Exclude (Confidence: 0.85)
**Human:** Exclude

## Wissensdokument

# AI algorithm transparency, pipelines for trust not prisms: mitigating general negative attitudes and enhancing trust toward AI

## Kernbefund

Algorithmen-Transparenz vermindert signifikant die negative Beziehung zwischen allgemeiner negativer Einstellung gegenüber KI und Vertrauen in das Mutterunternehmen, besonders bei hohem Issue-Involvement. Transparenz funktioniert als Signalisierungsmechanismus für Organisationsverantwortung und nicht nur als Prism-Modell der Reputation.

## Forschungsfrage

Wie kann Transparenz von KI-Algorithmen negative Einstellungen gegenüber KI abschwächen und Vertrauen in KI-Systeme und ihre Unternehmen erhöhen?

## Methodik

Empirisch: Online-Experiment mit 2x2 zwischen-Subjekt-Design (AI-Algorithmen-Transparenz: Hoch vs. Niedrig × Issue-Involvement: Hoch vs. Niedrig); hierarchische Regressionsanalysen und PROCESS Macro Model 3 für moderierte Moderationseffekte; n=1059 Teilnehmer.
**Datenbasis:** n=1059 Online-Umfrage-Teilnehmer, 2x2 experimentelles Design, Datenerhebung 29. Oktober bis 5. November 2023

## Hauptargumente

- Allgemeine negative Einstellungen gegenüber KI entstehen aus Besorgnis über Unkontrollierbarkeit und unvorhersehbare Folgen von KI-Systemen; diese negativen Einstellungen untergraben das Vertrauen in KI-Systeme und ihre Betreiber-Unternehmen.
- Das klassische Prism-Modell von Vertrauensaufbau (basierend auf Unternehmensreputation) ist für KI-Systeme unzureichend, da algorithmische Opazität und Informationsasymmetrien Skepsis erzeugen, besonders bei unbekannten Unternehmen; ein Pipeline-Modell durch Transparenz ist notwendig.
- Transparenz wirkt als direkter Pipeline-Effekt, der Wissen und Verständnis fördert, und signalisiert zugleich Organisationsverantwortlichkeit; bei hohem Issue-Involvement verstärkt sich dieser Effekt signifikant, wie das Elaboration Likelihood Model vorhersagt.

## Kategorie-Evidenz

### Evidenz 1

Die Studie untersucht, wie Transparenz von KI-Algorithmen das Wissen und Verständnis von Nutzern fördert: 'transparency can reduce uncertainty and enhance trust in AI systems' und 'transparency serves as a strategic tool to reduce uncertainty and enhance knowledge'.

### Evidenz 2

Expliziter Fokus auf generative KI wie ChatGPT: 'Given the growing importance of generative AI such as ChatGPT in stakeholder communications' und 'The integration of generative artificial intelligence (AI) with chatbots such as ChatGPT, is becoming increasingly prevalent'.

### Evidenz 3

Umfassende Behandlung algorithmischer Entscheidungssysteme: 'algorithmic systems may reinforce biases' und Analyse von Vertrauensdynamiken in KI-Systemen generell.

### Evidenz 4

Adressiert algorithmische Verzerrungen und deren gesellschaftliche Auswirkungen: 'Recent studies have pointed out how algorithmic systems may reinforce biases or even spur radicalization' und 'promoting an inclusive approach to AI adoption that avoids technological disparity'.

### Evidenz 5

Berücksichtigung unterschiedlicher Stakeholder-Gruppen und Zugangsbarrieren: 'varying attitudes toward AI' und 'support ethical AI integration across diverse contexts'; Fokus auf inklusive KI-Adoption.

### Evidenz 6

Implizit adressiert durch Fokus auf Transparenz als Fairness-Mechanismus: 'transparency not only fosters understanding but also acts as a signaling mechanism for organizational accountability' und Engagement mit Konzepten von Vertrauenswürdigkeit und Integrität.

## Assessment-Relevanz

**Domain Fit:** Das Paper hat begrenzte direkte Relevanz für die Soziale Arbeit, adressiert aber wichtige Schnittstellen zwischen KI-Literacies, Vertrauensbildung, und gesellschaftlicher Inklusion. Die Erkenntnisse zu Transparenz und Bias-Reduktion könnten für Sozialarbeiter bedeutsam sein, die mit KI-gestützten Systemen in der Praxis arbeiten.

**Unique Contribution:** Innovative Verschiebung vom Reputations-Prism-Modell zum Wissens-fokussierten Pipeline-Modell des KI-Vertrauens, mit empirischem Nachweis, dass Transparenz als Signalisierungsmechanismus für Organisationsverantwortlichkeit fungiert.

**Limitations:** Die Studie berücksichtigt nur Online-Umfrage-Daten mit US-amerikanischen Teilnehmern; kulturelle Unterschiede im Vertrauensverständnis und langfristige Effekte von Transparenz-Maßnahmen bleiben unterexpliziert; keine direkten Interaktionen mit realen KI-Systemen.

**Target Group:** KI-Entwickler, Organisationen mit KI-Integration, Kommunikations- und PR-Profis, Policymaker im Bereich KI-Regulierung, KI-Literacy-Pädagogen, Verbraucher und Stakeholder-Gruppen mit skeptischer KI-Haltung

## Schlüsselreferenzen

- [[Podolny_2001]] - Networks as the pipes and prisms of the market
- [[Petty_Cacioppo_1981]] - Elaboration Likelihood Model of persuasion
- [[Liu_2021]] - In AI we trust? Effects of agency locus and transparency on uncertainty reduction
- [[Johnson_Verdicchio_2017]] - AI anxiety
- [[Shin_Jitkajornwanich_2024]] - How algorithms promote self-radicalization
- [[Murtarelli_et_al_2023]] - Ethical challenges of AI-assisted and chatbot-based communications
- [[Zhang_Dafoe_2019]] - Artificial intelligence: American attitudes and trends
- [[Gefen_et_al_2003]] - Trust and TAM in online shopping
- [[European_Union_2024]] - EU Artificial Intelligence Act
- [[Schepman_Rodway_2023]] - General Attitudes towards Artificial Intelligence Scale (GAAIS)
