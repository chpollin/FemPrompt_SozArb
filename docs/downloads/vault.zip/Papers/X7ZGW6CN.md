---
title: "Intersectional Artificial Intelligence Is Essential: Polyvocal, Multimodal, Experimental Methods to Save AI"
authors:
  - S. Ciston
year: 2024
type: journalArticle
doi: 10.7559/CITARJ.V11I2.665
url: 
tags:
  - paper
llm_decision: Include
llm_confidence: 0.95
llm_categories:
  - AI_Literacies
  - Generative_KI
  - KI_Sonstige
  - Bias_Ungleichheit
  - Gender
  - Diversitaet
  - Feministisch
  - Fairness
human_decision: Include
human_categories:
  - KI_Sonstige
  - Bias_Ungleichheit
  - Gender
  - Feministisch
agreement: agree
---

# Intersectional Artificial Intelligence Is Essential: Polyvocal, Multimodal, Experimental Methods to Save AI

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** AI_Literacies, KI_Sonstige, Bias_Ungleichheit, Gender, Diversitaet, Feministisch, Fairness
**Argumente:** 3 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 92 |
| Correctness | 98 |
| Category Validation | 95 |
| **Overall Confidence** | **93** |

### Stufe 4: Assessment

**LLM:** Include (Confidence: 0.95)
**Human:** Include

## Wissensdokument

# Intersectional Artificial Intelligence Is Essential: Polyvocal, Multimodal, Experimental Methods to Save AI

## Kernbefund

Intersektionale Strategien auf allen Ebenen der KI (von Daten bis Design bis Implementierung) können durch polyvokale, multimodale und experimentelle Ansätze strukturelle Verzerrungen adressieren und alternative Ethiken enthüllen. Community-fokussierte und künstlerische Praktiken sind entscheidend für die Entwicklung intersektionaler KI-Möglichkeiten.

## Forschungsfrage

Wie kann intersektionale Theorie angewendet werden, um KI-Systeme zu analysieren, zu kritisieren und neu zu gestalten, um strukturelle Ungleichheiten zu adressieren?

## Methodik

Theoretisch/Review + interdisziplinäre Analyse mit kunstgestützten und gemeinschaftlichen Methoden
**Datenbasis:** nicht empirisch; konzeptuelle und case-study basierte Analyse

## Hauptargumente

- KI reproduziert bestehende Machtstrukturen und Vorurteile durch ihre Daten und Prozesse, wobei die Eigenschaft der Eigentumsrechte und kulturelle Missverständnisse diese Verzerrungen verschleiern und ihnen den Status wissenschaftlicher Neutralität verleihen.
- Intersektionalität ist nicht einfach eine Frage der Identitätsrepräsentation oder mehr Daten, sondern eine kritische Analyse institutioneller Machtsysteme; feministische Datenvisualisierung und intersektionale Queer-Theorie können normative algorithmische Annahmen unterlaufen.
- Praktiken aus Black-Feminist, Mixed-Race, Queer und Trans-Communities bieten Strategien der Reflexivität, Polyvokalisierung und des 'Passing', die KI-Design und -Implementierung subversiv umgestalten können, besonders wenn sie in gemeinschaftliche und künstlerische Experimente integriert werden.

## Kategorie-Evidenz

### Evidenz 1

Ciston argumentiert für 'the application of intersectional strategies to Artificial Intelligence at every level, from data to design to implementation, from technologist to user' und betont kritisches Verständnis und reflexive Praxis im Umgang mit KI-Systemen.

### Evidenz 2

Das Paper diskutiert Algorithmen, maschinelles Lernen, neuronale Netze, Computer Vision (ImageNet), Criminal Risk Assessment AI und algorithmen-basierte Entscheidungssysteme im Kontext von Voreingenommenheit.

### Evidenz 3

ProPublica-Studie zeigt, dass AI Criminal Risk Assessment 'particularly likely to falsely flag black defendants as future criminals'; ImageNet Beispiel demonstriert, wie 'laborers' biases were ultimately embedded into the project' und staatliche Systeme diese verstärken.

### Evidenz 4

Expliziter Gender-Fokus: 'using queer strategies to disorient those categories can also push back on assumptions about technologies themselves' und die Analyse von Gender-Bias in Kategorisierungssystemen.

### Evidenz 5

Paper betont marginalisierte Communities: 'strategies from mixed race, trans, bisexual, and femme communities' und organisationen wie Color Coded, das 'technology-rich environments only for historically excluded people to collaborate and learn' schafft.

### Evidenz 6

Explizite Verwendung von Black-Feminist-Theorie (Safiya Noble, Ruha Benjamin), Queer-Feminist-Theorie und Referenzen auf D'Ignazio & Klein, Chun, hooks-adjacent thinking: 'Brittney Cooper reminds us how intersectionality is often misunderstood' und die Anwendung feministischer Datenvisualisierungsprinzipien.

### Evidenz 7

Ciston diskutiert 'Data Nutrition Label' zur Verhinderung von Datenbias und 'Algorithmic Justice League' als Interventionen gegen 'coded gaze', sowie Frameworks zur Fairness in ML-Systemen.

## Assessment-Relevanz

**Domain Fit:** Sehr relevant für die Schnittstelle KI/Soziale Arbeit/Gender Studies: Das Paper bietet eine theoretisch fundierte intersektionale Analyse von KI-Systemen, die strukturelle Ungleichheiten adressiert, die auch Sozialarbeit betreffen (Risikobewertungssysteme, Algorithmen in Care-Kontexten). Die Betonung von Community-Methoden und marginalizierten Perspektiven resoniert mit Social-Justice-Ansätzen in der Sozialen Arbeit.

**Unique Contribution:** Das Paper leistet einen wichtigen Beitrag, indem es Black-Feminist-, Queer-, und Mixed-Race-Strategien nicht nur zur Kritik von KI-Bias nutzt, sondern diese als generative Ressourcen für die Umgestaltung von KI-Design positioniert, kombiniert mit praktischen Beispielen künstlerischer und gemeinschaftlicher Interventionen.

**Limitations:** Das Paper ist primär konzeptionell und spekulativ; es bietet wenig quantitative Evaluation der vorgeschlagenen Strategien und basiert stark auf theoretischen Argumenten und illustrativen Case Studies (ladymouth, Feminist.AI, Color Coded) ohne umfassende empirische Validierung ihrer Effektivität.

**Target Group:** KI-Entwickler und Designer, Gender-Studies- und Queer-Theory-Akademiker:innen, Critical Race Theory Forscher:innen, Aktivist:innen im Bereich Algorithmic Justice, progressive Sozialarbeiter:innen mit Critical-Theory-Hintergrund, Kunstler:innen und Kulturwissenschaftler:innen im Tech-Kontext, Policymaker mit Interesse an intersektionaler Tech-Governance

## Schlüsselreferenzen

- [[Angwin_Larson_Mattu_Kirchner_2016]] - Machine Bias (ProPublica study on COMPAS)
- [[Benjamin_Ruha_2019]] - Race After Technology: Abolitionist Tools for the New Jim Code
- [[Buolamwini_Joy_2017]] - How I'm fighting bias in algorithms
- [[Crawford_Kate_Paglen_Trevor_2019]] - Excavating AI: The Politics of Images in Machine Learning Training Sets (ImageNet Roulette)
- [[DIgnazio_Catherine_Klein_Lauren_F_2020]] - Feminist Data Visualization (Six Principles)
- [[Chun_Wendy_HK_2018]] - Queerying Homophily in Pattern Discrimination
- [[Keeling_Kara_2014]] - Queer OS
- [[Noble_Safiya_U_2018]] - Algorithms of Oppression: How Search Engines Reinforce Racism
- [[Roberts_Sarah_T_2016]] - Commercial Content Moderation: Digital Laborers' Dirty Work
- [[Holland_et_al_2018]] - The Dataset Nutrition Label: A Framework To Drive Higher Data Quality Standards
