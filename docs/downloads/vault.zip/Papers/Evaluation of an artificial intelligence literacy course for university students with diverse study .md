---
title: Evaluation of an artificial intelligence literacy course for university students with diverse study backgrounds
authors:
  - Siu-Cheung Kong
  - William Man-Yin Cheung
  - Guo Zhang
year: 2021
type: journalArticle
doi: 10.1016/j.caeai.2021.100026
url: "https://linkinghub.elsevier.com/retrieve/pii/S2666920X21000205"
tags:
  - paper
llm_decision: Exclude
llm_confidence: 0.85
llm_categories:
  - AI_Literacies
human_decision: Include
human_categories:
  - AI_Literacies
  - KI_Sonstige
  - Gender
agreement: disagree
---

# Evaluation of an artificial intelligence literacy course for university students with diverse study backgrounds

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** AI_Literacies, KI_Sonstige, Bias_Ungleichheit, Gender, Diversitaet, Fairness
**Argumente:** 3 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 92 |
| Correctness | 98 |
| Category Validation | 95 |
| **Overall Confidence** | **95** |

### Stufe 4: Assessment

**LLM:** Exclude (Confidence: 0.85)
**Human:** Include

**Kategorie-Vergleich (bei Divergenz):**

| Kategorie | Human | LLM | Divergent |
|-----------|-------|-----|----------|
| AI_Literacies | Ja | Ja |  |
| Generative_KI | Nein | Nein |  |
| Prompting | Nein | Nein |  |
| KI_Sonstige | Ja | Nein | X |
| Soziale_Arbeit | Nein | Nein |  |
| Bias_Ungleichheit | Nein | Nein |  |
| Gender | Ja | Nein | X |
| Diversitaet | Nein | Nein |  |
| Feministisch | Nein | Nein |  |
| Fairness | Nein | Nein |  |

## Wissensdokument

# Evaluation of an artificial intelligence literacy course for university students with diverse study backgrounds

## Kernbefund

120 Studierende aus verschiedenen Studienrichtungen machten signifikante Fortschritte beim Verständnis von KI-Konzepten (von 6.31 auf 9.71 Punkte), bei selbstwahrgenommener KI-Literacy (von 2.93 auf 3.98) und beim Gefühl der Empowerment (von 3.93 auf 4.06), unabhängig von Vorkenntnissen in Programmierung.

## Forschungsfrage

Können Universitätsstudierende aus verschiedenen Disziplinen durch einen AI-Literacykurs ein konzeptuelles Verständnis von KI-Konzepten entwickeln?

## Methodik

Empirisch (Mixed-Methods): Quantitativ mit Pre-Post-Tests (14-Item AI Concepts Test, AI Literacy Survey mit 10 Items, AI Empowerment Survey mit 17 Items) und qualitativ mit Focus-Group-Interviews. Flipped-Classroom-Design.
**Datenbasis:** n=120 Universitätsstudierende (freiwillige Teilnehmende), 7-Stunden-Kurs, Pre-Post-Tests, Focus-Group-Interviews

## Hauptargumente

- KI-Literacy sollte sich auf konzeptionelles Verständnis von KI-Kernkonzepten (Machine Learning, Supervised/Unsupervised Learning, Regression, Classification, Clustering) konzentrieren, nicht auf Programmierung und Algorithmen, um für diverse Studierende zugänglich zu sein.
- AI-Literacy besteht aus drei Komponenten: (1) Verständnis von KI-Konzepten, (2) Anwendung von KI-Konzepten zur Evaluation, und (3) Nutzung von KI-Konzepten zur Problemlösung im realen Leben - Empowerment durch KI ist zentral.
- Der Flipped-Classroom-Ansatz ermöglicht selbstgesteuertes Lernen und Inklusion von Studierenden verschiedener Hintergründe; geschlechtsspezifische Unterschiede in der Selbstwirksamkeit vor dem Kurs können durch qualitativ hochwertige AI-Literacy-Kurse reduziert werden.

## Kategorie-Evidenz

### Evidenz 1

We propose that AI literacy includes three components: AI concepts, using AI concepts for evaluation, and using AI concepts for understanding the real world through problem solving. Understanding AI concepts is essential for learners developing AI literacy.

### Evidenz 2

The course served as a pilot initiative to promote AI literacy to the public. This article reports the process of designing, implementing and evaluating this AI literacy course, which is named 'Understanding Artificial Intelligence' and concentrates on concepts related to machine learning.

### Evidenz 3

Along with the new benefits and options that AI can offer, these new technologies also raise public concerns over issues such as bias, digital privacy and security.

### Evidenz 4

Gender stereotypes may account for the fact that female participants feel less empowered before the course even though they have similar performance as that of their male counterparts in AI Concepts Test and AI Literacy Survey. It was reported that female students were more critical of their abilities in STEM than male students even if they had the same grades.

### Evidenz 5

The objective of this study was to design, implement and evaluate an AI literacy course for university students. One of the study's research questions was whether university students from a variety of disciplines could develop a conceptual understanding of AI through a literacy course. These findings indicated that the participants of diverse study backgrounds, and of both genders, could understand the concepts of machine learning.

### Evidenz 6

Prior knowledge of programming was not necessary for AI concepts development, and the flipped classroom learning approach enabled more flexible learning by the participants. This course was similarly beneficial in promoting understanding of AI for participants of all disciplines and of both genders.

## Assessment-Relevanz

**Domain Fit:** Das Paper ist relevant für KI-Bildung und Literacyförderung, behandelt aber Soziale Arbeit nicht direkt. Jedoch sind die Erkenntnisse zu Gender-Stereotypen, Diversität und inklusivem Zugang zu KI-Bildung für sozialarbeiterische Kontexte und vulnerable Populationen potenziell wertvoll.

**Unique Contribution:** Das Paper leistet einen Beitrag durch empirische Evidenz, dass Studierende aus diversen Disziplinen ohne Programmierungsvorkenntnisse KI-Konzepte verstehen können, und zeigt, wie geschlechtsspezifische Unterschiede in der Selbstwirksamkeit durch qualitativ hochwertige Literacykurse verringert werden können.

**Limitations:** Die Stichprobe stammt von nur einer Universität in Hongkong und ist daher nicht repräsentativ; die Reliabilität des AI Concepts Test mit Cronbach's alpha von 0.66 liegt an der unteren Grenze akzeptabler Werte; es fehlt die Analyse langfristiger Effekte und Transfer der Lernergebnisse.

**Target Group:** Bildungsforschende, Hochschuldozenten, Curriculumentwickler, Policymaker im Bereich Digitale Bildung, sowie potentiell Sozialarbeiter und Fachpersonen in der Erwachsenenbildung die KI-Literacykurse für diverse Populationen entwickeln möchten

## Schlüsselreferenzen

- [[Long_Magerko_2020]] - What is AI literacy? Competencies and design considerations
- [[Sabouret_2020]] - Understanding artificial intelligence
- [[Anderson_Anderson_2006]] - Machine ethics
- [[Touretzky_et_al_2019]] - Envisioning AI for k-12: What should every child know about AI?
- [[Ertl_Luttenberger_Paechter_2017]] - The impact of gender stereotypes on the self-concept of female students in STEM subjects
- [[Bandura_1982]] - Self-efficacy mechanism in human agency
- [[Kong_et_al_2018]] - A study of primary school students' interest, collaboration attitude, and programming empowerment in computational thinking education
- [[Pan_2016]] - Heading toward artificial intelligence 2.0
- [[Stone_et_al_2016]] - Artificial intelligence and life in 2030 - one hundred year study on artificial intelligence
- [[OECD_2018]] - Bridging the digital gender divide: Include, upskill, innovate
