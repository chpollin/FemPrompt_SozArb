---
title: "Thinking like a scientist: Can interactive simulations foster critical AI literacy?"
authors:
  - Y. Zhao
  - A. Michal
  - N. Thain
  - H. Subramonyam
year: 2025
type: conferencePaper
doi: 10.1007/978-3-031-98417-4_5
url: 
tags:
  - paper
llm_decision: Include
llm_confidence: 0.92
llm_categories:
  - AI_Literacies
  - Generative_KI
  - Bias_Ungleichheit
  - Fairness
human_decision: Include
human_categories:
  - AI_Literacies
  - Generative_KI
  - KI_Sonstige
  - Bias_Ungleichheit
  - Fairness
agreement: agree
---

# Thinking like a scientist: Can interactive simulations foster critical AI literacy?

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** AI_Literacies, Generative_KI, KI_Sonstige, Bias_Ungleichheit, Diversitaet, Fairness
**Argumente:** 3 extrahiert

### Stufe 4: Assessment

**LLM:** Include (Confidence: 0.92)
**Human:** Include

## Wissensdokument

# Thinking Like a Scientist: Can Interactive Simulations Foster Critical AI Literacy?

## Kernbefund

Interaktive Simulationen verbessern KI-Literalität signifikant und unterstützen stärkere Wissensgeneralisierung über Themen hinweg. Die Menge der Interaktion korreliert jedoch schwach mit Lerngewinnen – Qualität der Engagement ist entscheidender als Quantität.

## Forschungsfrage

Können interaktive Simulationen (Explorable Explanations) durch wissenschaftliches Denken (Hypothesentesten, Experimentation, Beobachtung) zur kritischen KI-Literalität beitragen?

## Methodik

Empirisch - Kontrollierte Studie mit drei Bedingungen (Explorable/Interaktiv, Statisches PDF, Kontrollgruppe); Pre-/Post-Tests mit quantitativen Messungen, Engagement-Analyse von Interaktionsprotokollen
**Datenbasis:** n=612 Teilnehmende (nach Bereinigung: 47-51 pro Bedingung/Thema), Online-Studie via Prolific-Plattform, USA-basiert, 18-jährig und älter, englischsprachig

## Hauptargumente

- Traditionelle AI-Literacy-Ansätze (Blog-Artikel, statische Lektionen) fördern nicht ausreichend tiefes konzeptionelles Verständnis und kritisches Engagement, daher sind interaktive, exploratorische Methoden notwendig.
- Interactive Simulations ermöglichen es Lernenden, wissenschaftlich zu denken (Hypothesentesten, Beobachtung, Iteration), was zu besserer Generalisierung von Wissen auf neue Kontexte führt, besonders im Vergleich zur passiven Exposition.
- Engagement-Qualität statt -Quantität ist entscheidend: Rohmetriken wie Scrolltiefe oder Häufigkeit von Interaktionen korrelieren schwach mit Lernergebnissen, während spezifische Aufgabentypen (z.B. 'Identify Issue' bei Fairness) differenzierbare Effekte zeigen.

## Kategorie-Evidenz

### Evidenz 1

AI literacy is defined as 'a set of competencies that enables individuals to critically evaluate AI technologies' (S. 2). Die Studie untersucht systematisch 'Know & Understand AI', 'Use & Apply AI', 'Detect AI', und 'AI Ethics' mittels Meta AI Literacy Scale (18 Items).

### Evidenz 2

Eines der vier Explorable-Themen ist 'Large Language Models', das 'advances in language technology' zeigt und LLM-spezifische Lernoutcomes misst.

### Evidenz 3

Algorithmic decision-making, machine learning, dataset representativeness und algorithmic fairness werden als zentrale KI-Konzepte behandelt (beyond generative AI).

### Evidenz 4

Kernthema: 'a hiring algorithm trained on historical recruitment data may inadvertently perpetuate biases, disadvantaging historically underrepresented groups' (S. 1). Explicitly: 'datasets are not neutral—they are shaped by the choices, assumptions, and limitations of their creators'.

### Evidenz 5

Ein Explorable fokussiert auf 'Diversity and Fairness' mit Messungen von Repräsentation; Analyse der Teilnehmer-Demografie (63% White, 15.5% Black/African American, 11% Asian).

### Evidenz 6

Explizites Fairness-Thema in den vier Explorables; 'Fairness' als eigenes Topic mit Pre/Post-Messungen; Szenarien zur Mitigation von Bias in Recruitment-Algorithmen; 'measure-fairness' Explorable.

## Assessment-Relevanz

**Domain Fit:** Das Paper adressiert AI Literacy Education und kritisches Denken über KI-Systeme, mit explizitem Fokus auf Bias, Fairness und ethische Implikationen. Für Soziale Arbeit direkt relevant als Evidence-base für digitale Literacy-Interventionen mit marginalisierten Gruppen, jedoch ohne expliziten Bezug zu klassischer Sozialer Arbeit.

**Unique Contribution:** Empirischer Nachweis, dass Quality-of-Engagement statt bloße Quantität für KI-Literalität entscheidend ist, und dass Explorable Explanations (interaktive, spielerische Erkundungen) superiore Wissensgeneralisierung gegenüber statischen Materialien ermöglichen.

**Limitations:** Begrenzte Stichprobendiversität (65% unter 40, 63% White, online-basiert, selbstselektiv), kurzzeitige Messung ohne Langzeitfolge-up, wenig qualitative Daten zu kognitiven Prozessen, Topic-abhängige Effekte (LLM zeigte Leistungsrückgänge).

**Target Group:** KI-Bildungsdesigner, Informatik-Lehrende, Policymaker im Bildungsbereich, UX-Forscher, AI Ethics-Praktiker, potentiell Sozialarbeitende als Vermittler digitaler Kompetenzen

## Schlüsselreferenzen

- [[Chi_Wylie_2014]] - The ICAP Framework: Linking Cognitive Engagement to Active Learning
- [[De_Jong_Van_Joolingen_1998]] - Scientific Discovery Learning with Computer Simulations
- [[Long_Magerko_2020]] - What is AI Literacy? Competencies and Design Considerations
- [[Carolus_et_al_2023]] - MAILS – Meta AI Literacy Scale
- [[Raub_2018]] - Bots, Bias and Big Data: AI, Algorithmic Bias and Disparate Impact in Hiring
- [[Dignum_2019]] - Responsible Artificial Intelligence
- [[Ng_et_al_2021]] - Conceptualizing AI Literacy: An Exploratory Review
- [[Kasinidou_et_al_2021]] - Educating Computer Science Students about Algorithmic Fairness, Accountability, Transparency and Ethics
- [[Hitron_et_al_2019]] - Can Children Understand Machine Learning Concepts?
