---
title: Shaping feminist artificial intelligence
authors:
  - S. Toupin
year: 2024
type: journalArticle
url: https://journals.sagepub.com/doi/full/10.1177/14614448221150776
doi: 10.1177/14614448221150776
tags:
  - paper
  - feminist-ai
  - bias-research
date_added: 2026-02-22
date_modified: 2026-02-22
bias_types:
  - Discrimination
  - Intersectionality
mitigation_strategies:
  - Intersectionality
---

# Shaping feminist artificial intelligence

## Abstract

Comprehensive examination of feminist artificial intelligence through historical analysis and contemporary typology development. Provides detailed framework categorizing FAI as: model, design, policy, culture, discourse, and science. Traces FAI's evolution from foundational work to contemporary initiatives, analyzing tensions between commercialized approaches and community-oriented methods.

## Key Concepts

### Bias Types
- [[Discrimination]]
- [[Intersectionality]]

### Mitigation Strategies
- [[Intersectionality]]

## Full Text

---
title: "Shaping feminist artificial intelligence"
authors: ["Sophie Toupin"]
year: 2023
type: journalArticle
language: en
processed: 2026-02-05
source_file: Toupin_2024_Shaping_feminist_artificial_intelligence.md
confidence: 88
---

# Shaping feminist artificial intelligence

## Kernbefund

FAI ist ein plurales Konzept mit multiplen Bedeutungen und Manifestationen, das sich in sechs Typologien manifestiert (als Modell, Design, Policy, Kultur, Diskurs und Wissenschaft), jedoch bleibt es bislang in der technoliberalen Sphäre der Inklusion stecken und stellt keine transformative Politik dar, die kapitalistische Ungleichheitsstrukturen fundamental herausfordert.

## Forschungsfrage

What does the term feminist artificial intelligence (FAI) mean and how has FAI been shaped over time?

## Methodik

Kritische Literaturübersicht und Analyse von Schriften und Praktiken; Purposive Sampling aus akademischen Datenbanken, Suchmaschinen und Twitter; kritische Untersuchung von Mikrogeschichte durch Alison Adam und zeitgenössische Beispiele aus Global South und Global North
**Datenbasis:** nicht empirisch; qualitative Analyse von Schriften (akademische Texte, Online-Präsentationen, Projektdokumentationen) und Praktiken aus globalen Kontexten; Fokus auf Werke, die den Begriff FAI verwenden oder verwandte Konzepte (intersectional AI, transfeminist AI, decolonial AI)

## Hauptargumente

- Feminist artificial intelligence wurzelt in konstruktivistischen Perspektiven der Wissenschafts- und Technikforschung und Alison Adam hat bereits in den 1990ern die Grundlagen von FAI gelegt, indem sie fragte, wie AI-Systeme gender, race und class berücksichtigen können und wie feministische Theorie AI informieren kann.
- Zeitgenössische FAI manifestiert sich in mindestens sechs verschiedenen Formen: als experimentelles Modell (z.B. Sinders' Feminist Data Set), als Designpraktik (z.B. feminist.ai mit Poieto-Software), als internationale Entwicklungspolitik (f<a+i>r-Netzwerk), als diskursive Kategorie zur Kritik von AI, und als wissenschaftliche Praxis, die alternative AI-Imaginaries schafft.
- Trotz der Bemühungen um Partizipation, Langsamkeit und Gemeinschaftsorientierung bleiben FAI-Projekte in einer technoliberalen Logik der Inklusion stecken, die die grundlegenden Macht- und Ungleichheitsstrukturen des kapitalistischen Systems sowie Umweltdestruktion nicht fundamental herausfordert; eine dekoloniale feministische Intelligenz müsste über technische Lösungen hinausgehen.

## Kategorie-Evidenz

### Evidenz 1

Die Analyse betont Bildungs- und Kompetenzaspekte: 'The culture of the users means that participatory design with women, queer, trans, and Black, Indigenous and People of Color (BIPOC) individuals is part and parcel of Poieto' und 'The promise of including community in the design of AI... to lower the barriers to entry for doing AI for the community to be engaged in this process'.

### Evidenz 2

Umfassende Analyse von AI-Systemen jenseits generativer Modelle: 'Knowledge-based systems, better known in symbolic AI parlance as expert systems', Chatbots, predictive systems, word embeddings, robotics, algorithmic decision-making systems.

### Evidenz 3

Direkter Bezug zu Jugendhilfe und rechtlicher Beratung: Furnival's FAI-Projekt für 'low-income women pursuing gender discrimination cases who did not have access to a lawyer' und Projekte zu 'gender-based violence (GBV) cases against women and LGBTIQ+ people' mit Ziel der Justizsystemreform.

### Evidenz 4

Zentrale Analyse von Diskriminierung: 'A good example of discriminatory word embedding is with terms like 'nurse,' 'care,' or 'sewing' usually being associated with women, whereas terms like 'salary,' 'sports,' and 'leader' are associated with men' und Kritik der 'systemic gender, racial, and intersectional bias'.

### Evidenz 5

Expliziter Gender-Fokus durchgängig: 'Furnival's FAI project aimed to compile feminist jurisprudence on issues of gender discrimination' und 'Scott was a feminist computational language knowledge-based system. The goal of the system was to repair in a meaningful way misunderstandings in communication between men and women'.

### Evidenz 6

Starker Fokus auf marginalisierte Communities und intersektionale Perspektiven: 'She specifically called for pieces of work from non-cis women, women of color, and trans creators to enrich her data set' und Betonung der Partizipation von 'women, queer, trans, and non-binary designers from all backgrounds, origins, and geographies'.

### Evidenz 7

Explizit feministische Theorie und Methodik: 'Influenced by these conversations, British computer scientist and historian of science Alison Adam started criticizing AI from a feminist perspective... Her aim was to bring together gender, race, and class specifically and power more generally into the critique of AI'. Extensive Verwendung von Haraway (situated knowledge), Crenshaw (Intersektionalität), Combahee River Collective, Audre Lorde, hooks, D'Ignazio & Klein (Data Feminism), und dekolonialen Feminist:innen wie Lugones.

### Evidenz 8

Fokus auf faire und gerechtere AI-Systeme: 'The promise associated with FAI is that a fairer, slower, consensual, collaborative AI is possible' und Analyse von Sinders' Praktiken zur Sichtbarmachung von 'invisible, slow, and nitty-gritty work of creating a community-led data set'.

## Assessment-Relevanz

**Domain Fit:** Äußerst relevant für die Schnittstelle AI/Soziale Arbeit/Gender: Das Paper verbindet feministische Theorie mit praktischen AI-Systemen in der Sozialen Arbeit (z.B. rechtliche Beratung, Gewaltprävention) und bietet eine dekoloniale Perspektive auf inklusive Technologieentwicklung.

**Unique Contribution:** Die systematische Typologisierung von FAI in sechs Dimensionen (Modell, Design, Policy, Kultur, Diskurs, Wissenschaft) sowie die Mikrogeschichte von Alison Adam als Gründungsfigur bereichern plurale AI-Geschichtsschreibung und machen unsichtbare feministische Wissensproduktion sichtbar.

**Limitations:** Die Analyse konzentriert sich primär auf englischsprachige Quellen und bewusst auf qualitative Literaturanalyse ohne systematische Vollständigkeit; empirische Evidenz über tatsächliche Wirkungen der FAI-Projekte liegt nicht vor und bleibt Gegenstand zukünftiger Forschung.

**Target Group:** Sozialarbeiter:innen und Sozialarbeitswissenschaftler:innen, die AI-Systeme in ihrer Praxis verstehen wollen; AI-Entwickler:innen und Designer:innen mit Interesse an kritischen, feministischen Ansätzen; Policy-Maker im Bereich Technologie und Entwicklung; Feminist Technology Studies Wissenschaftler:innen; Digital Rights und zivilgesellschaftliche Akteur:innen; Studierende in den Bereichen STS, Gender Studies, Critical AI Studies und Soziale Arbeit

## Schlüsselreferenzen

- [[Adam_1998]] - Artificial Knowing: Gender and the Thinking Machine
- [[DIgnazio_Klein_2020]] - Data Feminism
- [[Haraway_1988]] - Situated Knowledges
- [[Crenshaw_1991]] - Mapping the Margins: Intersectionality, Identity Politics, and Violence Against Women of Color
- [[Noble_2018]] - Algorithms of Oppression: How Search Engines Reinforce Racism
- [[Benjamin_2019]] - Race after Technology: Abolitionist Tools for the New Jim Code
- [[Atanasoski_Vora_2019]] - Surrogate Humanity: Race, Robots, and the Politics of Technological Futures
- [[Bardzell_2010]] - Feminist HCI: Taking Stock and Outlining an Agenda for Design
- [[Combahee_River_Collective_1979]] - A Black Feminist Statement
- [[CostanzaChock_2018]] - Design Justice, A.I., and Escape from the Matrix of Domination
