---
title: "Beyond transparency and explainability: On the need for adequate and contextualized user guidelines for LLM use"
authors:
  - K. G. Barman
  - N. Wood
  - P. Pawlowski
year: 2024
type: journalArticle
doi: 10.1007/s10676-024-09778-2
url: "https://doi.org/10.1007/s10676-024-09778-2"
tags:
  - paper
llm_decision: Include
llm_confidence: 0.85
llm_categories:
  - AI_Literacies
  - Generative_KI
  - Prompting
  - Bias_Ungleichheit
  - Diversitaet
human_decision: Exclude
human_categories:
  - Generative_KI
  - Prompting
agreement: disagree
---

# Beyond transparency and explainability: On the need for adequate and contextualized user guidelines for LLM use

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** AI_Literacies, Generative_KI, Prompting, KI_Sonstige, Bias_Ungleichheit, Diversitaet, Fairness
**Argumente:** 3 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 88 |
| Correctness | 92 |
| Category Validation | 87 |
| **Overall Confidence** | **89** |

### Stufe 4: Assessment

**LLM:** Include (Confidence: 0.85)
**Human:** Exclude

**Kategorie-Vergleich (bei Divergenz):**

| Kategorie | Human | LLM | Divergent |
|-----------|-------|-----|----------|
| AI_Literacies | Nein | Ja | X |
| Generative_KI | Ja | Ja |  |
| Prompting | Ja | Ja |  |
| KI_Sonstige | Nein | Nein |  |
| Soziale_Arbeit | Nein | Nein |  |
| Bias_Ungleichheit | Nein | Ja | X |
| Gender | Nein | Nein |  |
| Diversitaet | Nein | Ja | X |
| Feministisch | Nein | Nein |  |
| Fairness | Nein | Nein |  |

## Wissensdokument

# Beyond transparency and explainability: on the need for adequate and contextualized user guidelines for LLM use

## Kernbefund

Aktuelle Fokussierung auf Transparenz und Explainability reicht nicht aus; stattdessen sollten kontextspezifische, praktische Nutzerrichtlinien zur Schulung, Risikominderung und ethischen Verwendung von LLMs im Vordergrund stehen, da Nutzer primär praktische Anleitung statt technischer Erklärungen benötigen.

## Forschungsfrage

Sind nutzerzentrierte Richtlinien für verantwortungsvolle LLM-Nutzung effektiver als Transparenz- und Erklärbarkeitsmethoden, um verschiedene Nutzergruppen angemessen zu unterstützen?

## Methodik

Theoretisch-analytisch mit Literaturreview und konzeptionellem Rahmen. Diskussion praktischer Anwendungsfälle in Bildung, Workplace und Fachberatung. Kritische Analyse von XAI-Ansätzen und Entwicklung eines nutzerzentrierten Guideline-Frameworks.
**Datenbasis:** Keine primäre empirische Datenerhebung; konzeptionelle Analyse und Literaturreview mit Fallbeispielen aus realen LLM-Anwendungen

## Hauptargumente

- Transparenz und XAI-Methoden sind technisch begrenzt und können Nutzern nicht die praktischen Informationen liefern, die sie für verantwortungsvolle LLM-Nutzung benötigen; selbst gute Erklärungen helfen nicht unbedingt bei der Frage, wie man LLMs richtig einsetzt.
- Nutzerzentrierte Richtlinien mit klaren Dos-and-Don'ts, Heuristiken zur Fehlerdetekion und Prompting-Strategien sind praktischer und effizienter als technische Erklärbarkeit, besonders für durchschnittliche Nutzer ohne spezialisiertes KI-Wissen.
- Effektive LLM-Governance erfordert institutionelle und regulatorische Ansätze (Bildung, Richtlinien, Protokolle), nicht nur technische Lösungen; ähnlich wie Verkehrssicherheit nicht erfordert, dass Fahrer Motorentechnik verstehen, sondern Verkehrsregeln kennen.

## Kategorie-Evidenz

### Evidenz 1

Schwerpunkt auf Nutzerschulung, Kompetenzentwicklung und praktische Richtlinien: 'we argue that LLM users should be given guidelines on what tasks LLMs can do well and which they cannot' und 'teaching users the right way to use these tools, as well as informing them of not only the strengths, potential uses, and best practices'

### Evidenz 2

Fokus auf Large Language Models wie ChatGPT, GPT-4, Claude und Llama: 'Large language models (LLMs) such as ChatGPT present immense opportunities'

### Evidenz 3

Explizite Behandlung von Prompt-Strategien: 'teaching users to refine and elaborate adequate prompts, be provided with good procedures for prompt iteration' und 'prompt engineering strategies'

### Evidenz 4

Behandlung von XAI, Interpretierbarkeit und algorithmischen Entscheidungssystemen: 'Explainable Artificial Intelligence (XAI) has emerged as a significant field'

### Evidenz 5

Thematisierung von Bias, Diskriminierung und ungleichem Zugang: 'widely recognized issues such as bias', 'misinformation', 'This approach democratizes the use of advanced AI technologies, making them more accessible to a broader audience, irrespective of their technical background'

### Evidenz 6

Fokus auf unterschiedliche Nutzergruppen und kontextspezifische Bedürfnisse: 'diverse needs and concerns of various user groups', 'different disciplines and domains where lack of reliability can have serious negative consequences', 'collaborative endeavor, involving AI experts, ethicists, educators, and perhaps most importantly, end-users'

### Evidenz 7

Behandlung fairer und ethischer LLM-Nutzung sowie Bias-Mitigation: 'ethical considerations, bias mitigation strategies', 'guidelines for responsible LLM usage' und 'ensuring these models are employed for the collective good'

## Assessment-Relevanz

**Domain Fit:** Das Paper ist relevant für AI-Literacy und verantwortungsvolle KI-Nutzung, hat aber keinen direkten Bezug zur Sozialen Arbeit als Praxisfeld. Es adressiert allerdings grundsätzliche Fragen von Nutzerkompetenzen, Zugänglichkeit und ethischen Richtlinien, die für soziale Professionen bei LLM-Einsatz bedeutsam sind.

**Unique Contribution:** Der Hauptbeitrag liegt in der kritischen Infragestellung von XAI als Lösungsansatz und der Begründung eines nutzerzentrierten Guideline-Frameworks, das praktische, kontextualisierte Richtlinien über technische Explainability priorisiert.

**Limitations:** Das Paper ist primär konzeptionell-theoretisch; es fehlen empirische Daten zu Nutzerkompetenzen, Guideline-Effektivität oder reale Implementierungserfahrungen. Keine Differenzierung zwischen unterschiedlichen LLM-Typen oder Nutzerprofielen.

**Target Group:** KI-Ethiker, Bildungsfachleute, Policymaker, institutionelle Entscheidungsträger in Bildung und Arbeit, Entwickler von KI-Systemen und deren Integration in Anwendungen, Nutzer von LLMs (Studierende, Fachkräfte); sekundär relevant für Sozialarbeiter, die LLMs in ihrer Praxis einsetzen

## Schlüsselreferenzen

- [[Bender_et_al_2021]] - On the dangers of stochastic parrots
- [[Burrell_2016]] - How the machine 'thinks': Understanding opacity in machine learning
- [[Arrieta_et_al_2020]] - Explainable artificial intelligence (XAI): concepts, taxonomies, opportunities and challenges
- [[Lundberg_Lee_2017]] - A unified approach to interpreting model predictions (SHAP)
- [[Ribeiro_et_al_2016]] - Model-agnostic interpretability of machine learning (LIME)
- [[Noy_Zhang_2023]] - Experimental evidence on the productivity effects of generative artificial intelligence
- [[Kasneci_et_al_2023]] - ChatGPT for good? On opportunities and challenges of large language models for education
- [[Pan_et_al_2023]] - On the risk of misinformation pollution with large language models
- [[Wood_2024]] - Explainable AI in the military domain
- [[Conmy_et_al_2023]] - Towards automated circuit discovery for mechanistic interpretability
