---
title: "ReflectAI: Design and evaluation of an AI coach to support public servants' self-reflection"
authors:
  - H.-H. Näscher
  - J. Schaffner
  - M. Koddebusch
year: 2025
type: conferencePaper
doi: 10.1007/978-3-032-02515-9_7
url: 
tags:
  - paper
llm_decision: Include
llm_confidence: 0.85
llm_categories:
  - AI_Literacies
  - Generative_KI
  - Prompting
  - Soziale_Arbeit
human_decision: Exclude
human_categories:
  - Generative_KI
agreement: disagree
---

# ReflectAI: Design and evaluation of an AI coach to support public servants' self-reflection

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** keine
**Argumente:** 3 extrahiert

### Stufe 4: Assessment

**LLM:** Include (Confidence: 0.85)
**Human:** Exclude

**Kategorie-Vergleich (bei Divergenz):**

| Kategorie | Human | LLM | Divergent |
|-----------|-------|-----|----------|
| AI_Literacies | Nein | Ja | X |
| Generative_KI | Ja | Ja |  |
| Prompting | Nein | Ja | X |
| KI_Sonstige | Nein | Nein |  |
| Soziale_Arbeit | Nein | Ja | X |
| Bias_Ungleichheit | Nein | Nein |  |
| Gender | Nein | Nein |  |
| Diversitaet | Nein | Nein |  |
| Feministisch | Nein | Nein |  |
| Fairness | Nein | Nein |  |

## Wissensdokument

# Electronic Participation: 17th IFIP WG 8.5 International Conference, ePart 2025 Krems, Austria, August 31 - September 4, 2025 Proceedings

## Kernbefund

Herausforderungen bei intra-gouvernementaler Zusammenarbeit lassen sich in drei Kategorien einteilen: interpersonelle und individuelle Dynamiken, strukturelle und systemische Herausforderungen sowie vertragliche und risikobezogene Herausforderungen. Die Sättigung wurde nach zehn Interviews erreicht.

## Forschungsfrage

Welche Herausforderungen ergeben sich bei der intra-gouvernementalen Zusammenarbeit bei IT-basierten Implementierungen aus einer Agency-Theory-Perspektive?

## Methodik

Empirisch qualitativ: Semi-strukturierte Interviews (n=10) mit Regierungsbeamten in verschiedenen Rollen und Ministerien, thematische Analyse mit induktiver und axialer Kodierung
**Datenbasis:** n=10 Semi-strukturierte Interviews mit Civil Servants aus 5 Ministerien (von 15 insgesamt), dokumentarische Evidenz, 10 IT-basierte Fallstudien der letzten 15 Jahre

## Hauptargumente

- Intra-gouvernementale Zusammenarbeit wird durch Vertrauensprobleme, Autonomiebestrebungen und kulturelle Unterschiede erschwert, die sich aus der sozialen Natur von Organisationen ergeben.
- Strukturelle und systemische Herausforderungen wie Machtungleichgewichte, widersprüchliche Interessen, Mehrprinzipal-Probleme und Informationsasymmetrie erschweren die Governance in IT-Projekten erheblich.
- Begrenzte Rationalität, unvollständige Verträge und unterschiedliche Risikoapetite führen zu Opportunismus und unterminieren die Effektivität von Governance-Mechanismen in komplexen IT-Implementierungen.

## Kategorie-Evidenz

*Keine Kategorie-Evidenz verfügbar*

## Assessment-Relevanz

**Domain Fit:** Das Paper hat keine direkte Relevanz für die Schnittstelle AI/Soziale Arbeit/Gender Studies. Es behandelt intra-gouvernementale Governance-Herausforderungen bei IT-Implementierungen aus einer Agency-Theory-Perspektive, ohne KI-Systeme, sozialarbeiterische Dimensionen oder Geschlechterperspektiven zu adressieren.

**Unique Contribution:** Die Studie bietet eine systematische Klassifizierung von Governance-Herausforderungen in intra-gouvernementaler Zusammenarbeit bei IT-Projekten basierend auf empirischen Interviews und theoretischer Synthese, wobei Sättigung bereits nach 10 Interviews erreicht wurde.

**Limitations:** Die Studie konzentriert sich auf niederländische Ministerien mit IT-basierten Implementierungen und hat möglicherweise begrenzte Generalierbarkeit auf andere Länder, Sektoren oder nicht-IT-basierte Governance-Kontexte.

**Target Group:** Governance-Professionelle in öffentlichen Verwaltungen, IT-Projektmanager in Regierungsinstitutionen, Policy-Maker, Forschende im Bereich Digital Government und Public Administration

## Schlüsselreferenzen

- [[Mitnick_1992]] - Agency Problems and Agency Theory
- [[OLeary_Bingham_nicht angegeben]] - Collaborative Governance and Personality Issues
- [[Bendickson_et_al_nicht angegeben]] - Psychological Factors in Governance
- [[Arnold_De_Lange_nicht angegeben]] - Organizational Culture and Opportunism
- [[Hennink_Kaiser_nicht angegeben]] - Sample Size Saturation in Qualitative Research
