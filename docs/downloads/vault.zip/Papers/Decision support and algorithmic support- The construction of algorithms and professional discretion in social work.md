---
title: Decision support and algorithmic support: The construction of algorithms and professional discretion in social work
authors:
  - M. L. Meilvang
  - A. M. Dahler
year: 2024
type: bookSection
tags:
  - paper
  - feminist-ai
  - bias-research
date_added: 2026-02-22
date_modified: 2026-02-22
bias_types:
  - Discrimination
  - Algorithmic Bias
mitigation_strategies: []
llm_decision: Include
llm_confidence: 0.95
llm_categories:
  - KI_Sonstige
  - Soziale_Arbeit
  - Bias_Ungleichheit
  - Fairness
human_decision: Exclude
human_categories:
  - KI_Sonstige
  - Soziale_Arbeit
  - Bias_Ungleichheit
agreement: disagree
---

# Decision support and algorithmic support: The construction of algorithms and professional discretion in social work

## Abstract

Critical analysis examining three decision-support algorithms developed for Danish municipalities in child and family social work, analyzing how they affect professional discretion despite claims to merely support professionals. Demonstrates how algorithmic systems designed to minimize subjective judgment and promote efficiency actually embody positivist assumptions that professional discretion can and should be eliminated. Key findings reveal how political actors favor standardized, automated approaches to avoid high-profile cases, effectively negating professional judgment central to ethical social work practice. Drawing on street-level bureaucracy and digitalization literature, argues that framing algorithms as neutral decision support obscures their role in fundamentally restructuring professional autonomy, expertise, and nature of care relationships.

## Assessment

**LLM Decision:** Include (Confidence: 0.95)
**LLM Categories:** KI_Sonstige, Soziale_Arbeit, Bias_Ungleichheit, Fairness
**Human Decision:** Exclude
**Human Categories:** KI_Sonstige, Soziale_Arbeit, Bias_Ungleichheit
**Agreement:** Disagree

## Key Concepts

### Bias Types
- [[Algorithmic Bias]]
- [[Discrimination]]

## Full Text

---
title: "Decision support and algorithmic support: the construction of algorithms and professional discretion in social work"
authors: ["Marie Leth Meilvang", "Anne Marie Dahler"]
year: 2024
type: journalArticle
language: en
processed: 2026-02-05
source_file: Meilvang_2024_Decision_support_and_algorithmic_support_The.md
confidence: 95
---

# Decision support and algorithmic support: the construction of algorithms and professional discretion in social work

## Kernbefund

Algorithms in Danish social work create an ambivalent and undecided relationship with professional discretion: they are designed to constrain subjective judgment through standardization and objectification, yet fundamentally depend on professional discretion for contextual information, data provision, and bias assessment.

## Forschungsfrage

How do decision-support algorithms in social work reconfigure ideas about professional discretion, and what is meant by professionals needing 'decision support'?

## Methodik

Mixed methods: Two-step qualitative study combining semi-structured interviews (n=11 initial interviews + project-specific interviews), observations, and document analysis of three Danish municipal algorithmic projects in social work with vulnerable children and families.
**Datenbasis:** 11 initial expert interviews; interviews with 4 assistants, 2 social workers, 1 project manager, 1 digital consultant, 1 data scientist, 1 unit manager (Rita Referral project); 2 expert group meetings with multiple stakeholders (Algorithm Project); informal talks and document analysis (Referrals in Focus project). Total: 3 municipal projects analyzed.

## Hauptargumente

- Political anxiety about high-profile child protection failures (Tønder and Brønderslev cases) drives algorithmic decision-support development, framing professional discretion as a liability requiring technological control rather than as a legitimate source of expertise.
- Algorithms are intended to standardize casework, objectify data, and eliminate bias, but these aims contradict the necessity of contextual judgment in social work—creating a paradox where algorithms require the very professional discretion they are designed to constrain.
- The claim of 'objective' data is undermined by the fact that social workers themselves produce or fundamentally shape the data feeding algorithms, while data quality is acknowledged as poor—suggesting validity comes from volume rather than quality.

## Kategorie-Evidenz

### Evidenz 1

The study examines how professionals understand, interpret, and use algorithmic systems in their practice: 'professionals should be aware of potential bias in data and, hence, in algorithmic systems. Discussions about known bias or potential future bias should be a key concern in the development of algorithms.'

### Evidenz 2

Focuses on algorithmic decision-support systems in social work: 'algorithms in social work are most frequently used as systems that work as decision support' and analyzes predictive and categorization algorithms used in referral screening.

### Evidenz 3

Direct engagement with social work practice, casework, professional discretion in child protection services: 'the analysis of intentions, designs, and workings of decision-support algorithms in casework with vulnerable children and families' across three Danish municipalities.

### Evidenz 4

Examines algorithmic bias and concerns about discrimination: 'considerable efforts are made to avoid such bias as relate to gender, ethnicity, and age' and discusses how poor data quality and subjective decision-making create systematic biases.

### Evidenz 5

Discusses marginalized communities and representation: concern that algorithms may replicate patterns of discrimination based on protected characteristics (gender, ethnicity, age) and the importance of including diverse professional perspectives in algorithm design.

### Evidenz 6

Directly addresses algorithmic fairness: 'eliminating bias from casework' is identified as a key theme, and the paper discusses fairness in algorithmic categorization and the need for regular testing of algorithms for bias.

## Assessment-Relevanz

**Domain Fit:** Highly relevant for AI/Social Work intersection. The paper provides empirical analysis of how algorithmic systems reshape professional practice in child protection, addressing tensions between automation, standardization, and professional expertise in vulnerable populations' casework.

**Unique Contribution:** Reveals the paradoxical and ambivalent relationship between algorithms and professional discretion in social work—showing that algorithms depend on the very professional judgment they are designed to replace, rather than eliminating discretion as technological determinism might suggest.

**Limitations:** Study limited to development and testing phases of algorithms in Danish municipalities; implementation at scale may reveal different dynamics. Access to algorithm use in practice was limited, and conclusions may not generalize to other national contexts or types of social work interventions.

**Target Group:** Social work practitioners and managers, algorithmic designers/developers working in public administration, policymakers overseeing algorithmic implementation in welfare services, researchers in social work, digital governance, and critical AI studies, organizational leaders in municipal social services.

## Schlüsselreferenzen

- [[Lipsky_1980]] - Street-level Bureaucracy
- [[Bovens_Zouridis_2002]] - From Street-level to System-level Bureaucracies
- [[Busch_Henriksen_2018]] - Digital Discretion
- [[Eubanks_2018]] - Automating Inequality
- [[Gillingham_2019]] - Predictive Algorithms in Child Protection
- [[Bowker_Star_1999]] - Sorting Things Out: Classification and Its Consequences
- [[Petersen_et_al_2021]] - We would never write that down
- [[Jørgensen_et_al_2021]] - Comparative Policy Analysis of Predictive Tools in Child Protection Services
- [[Williamson_Piattoeva_2019]] - Objectivity as Standardization in Data-scientific Education Policy
- [[Parton_2008]] - Changes in the Form of Knowledge in Social Work
