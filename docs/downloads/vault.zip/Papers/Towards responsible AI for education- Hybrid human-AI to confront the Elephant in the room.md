---
title: "Towards responsible AI for education: Hybrid human-AI to confront the Elephant in the room"
authors:
  - J. Goellner
  - V. Kumar
  - V. Aleven
year: 2025
type: report
doi: 
url: "https://arxiv.org/pdf/2504.16148"
tags:
  - paper
llm_decision: Include
llm_confidence: 0.85
llm_categories:
  - AI_Literacies
  - KI_Sonstige
  - Bias_Ungleichheit
  - Fairness
human_decision: Exclude
human_categories:
  - AI_Literacies
  - KI_Sonstige
agreement: disagree
---

# Towards responsible AI for education: Hybrid human-AI to confront the Elephant in the room

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** AI_Literacies, Generative_KI, KI_Sonstige, Bias_Ungleichheit, Diversitaet, Fairness
**Argumente:** 3 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 88 |
| Correctness | 94 |
| Category Validation | 92 |
| **Overall Confidence** | **91** |

### Stufe 4: Assessment

**LLM:** Include (Confidence: 0.85)
**Human:** Exclude

**Kategorie-Vergleich (bei Divergenz):**

| Kategorie | Human | LLM | Divergent |
|-----------|-------|-----|----------|
| AI_Literacies | Ja | Ja |  |
| Generative_KI | Nein | Nein |  |
| Prompting | Nein | Nein |  |
| KI_Sonstige | Ja | Ja |  |
| Soziale_Arbeit | Nein | Nein |  |
| Bias_Ungleichheit | Nein | Ja | X |
| Gender | Nein | Nein |  |
| Diversitaet | Nein | Nein |  |
| Feministisch | Nein | Nein |  |
| Fairness | Nein | Ja | X |

## Wissensdokument

# Towards responsible AI for education: Hybrid human-AI to confront the Elephant in the room

## Kernbefund

Neural-Symbolic AI und hybrid human-AI Methoden bieten einen vielversprechenden Weg zur Entwicklung verantwortungsvoller KI-Systeme im Bildungsbereich, indem sie Domain-Wissen mit datengesteuerten Ansätzen kombinieren und damit Fairness, Transparenz und Kontextangemessenheit verbessern.

## Forschungsfrage

Wie können Hybrid-AI-Methoden, insbesondere Neural-Symbolic AI, neun persistente Herausforderungen bei der Entwicklung fairer, transparenter und effektiver KI-Systeme im Bildungsbereich adressieren?

## Methodik

Kritische Analyse und theoretische Position Paper mit empirischen Beispielen aus der Literatur. Kombination von theoretischer Fundierung und Best-Practice-Beispielen zur Illustration von Problemen und Lösungen.
**Datenbasis:** Nicht primär empirisch: Literatur-basierte kritische Analyse mit illustrativen Beispielen aus existierender Forschung (z.B. Studien zu Knowledge Tracing, Learner Modelling); keine originäre Datenerhebung berichtet.

## Hauptargumente

- Es existieren neun kritische, oft übersehene Herausforderungen in KI-Systemen für Bildung: mangelnde Klarheit über KI-Definitionen, Vernachlässigung von Motivation/Emotion/Metakognition, begrenzte Domain-Knowledge-Integration, ungeeignete Modellwahl für sequenzielle Daten, Misuse von Evaluationsmetriken, unzuverlässige XAI-Methoden, ethisch unkritische Datenbearbeitung, fehlende systematische Benchmarking und Fokus auf globale statt lokale Empfehlungen.
- Hybrid human-AI Methoden wie Neural-Symbolic AI integrieren explizites symbolisches Domänenwissen mit Deep Learning, um sowohl Genauigkeit als auch Interpretierbarkeit zu erreichen und damit Blackbox-Probleme zu vermeiden, die in hochriskanten Kontexten wie Bildung ethisch und rechtlich problematisch sind.
- Die bisherige Dominanz von LLMs und domain-agnostischen Unternehmensmodellen verdrängt spezialisierte, pädagogisch fundierte KI-Ansätze und ignoriert dabei die spezifischen Anforderungen von Lernprozessen (Motivation, Emotion, Metakognition) sowie deren kontextabhängige Natur.

## Kategorie-Evidenz

### Evidenz 1

Das Paper diskutiert kritisches Verständnis von KI-Systemen im Bildungsbereich, Notwendigkeit von Klarheit über verschiedene KI-Familien und deren Einsatz: 'the lack of clarity around what AI for education truly means-often ignoring the distinct purposes, strengths, and limitations of different AI families'

### Evidenz 2

Explizite Kritik am Trend, KI für Bildung mit großen Sprachmodellen gleichzusetzen: 'the growing trend of equating it with domain-agnostic, company-driven large language models' und spätere Diskussion von LLM-Problemen

### Evidenz 3

Umfassende Behandlung verschiedener KI-Methoden: Expert Systems, Machine Learning, Deep Learning, Bayesian Networks, Neural-Symbolic AI, Explainable AI (SHAP, LIME), Knowledge Tracing, Learner Modelling

### Evidenz 4

Thematisiert systematische Vorurteile in Algorithmen: 'A-level algorithm' war systematisch vorurteilsbehaftet gegen bestimmte Studierende und Schulen. Diskussionspunkt: 'class imbalance' in Datensätzen führt zu Generalisierungsproblemen, die Ungleichheiten verstärken

### Evidenz 5

Betonung von Inklusion und diverse Stakeholder-Beteiligung: 'limited integration of domain knowledge and lack of stakeholder involvement in AI design and development' sowie Fokus auf individuelle studentische Unterschiede statt globale Prescriptions

### Evidenz 6

Zentrale Fairness-Herausforderungen werden diskutiert: 'reinforcing inequalities', 'class imbalance' in Trainingssets, Notwendigkeit fairer ML-Praktiken, und Fairness als Kernelement Verantwortungsvoller KI definiert als 'fair, accountable, not biased, non-discriminating'

## Assessment-Relevanz

**Domain Fit:** Das Paper ist hochrelevant für die Schnittstelle AI und Bildung/Pädagogik, mit starkem Fokus auf ethische und faire KI-Entwicklung. Der Bezug zu Sozialer Arbeit ist indirekt (Bildung ist ein sozialpolitisches Feld), aber das Paper behandelt nicht explizit sozialarbeiterische Kontexte, Zielgruppen oder Methoden.

**Unique Contribution:** Das Paper leistet einen wichtigen kritischen Beitrag durch systematische Identifikation von neun spezifischen, oft übersehenen Herausforderungen in KI-für-Bildung und demonstriert, wie Neural-Symbolic AI als integrative Lösung diese adressieren kann, statt nur technische Fixes anzubieten.

**Limitations:** Das Paper ist primär theoretisch-analytisch; während illustrative Beispiele aus Forschung eingebunden sind, werden diese Befunde nicht durch neue empirische Studien systematisch validiert. Die Anwendbarkeit von Neural-Symbolic AI auf verschiedene Bildungskontexte und Skalierbarkeit bleibt teilweise unklar.

**Target Group:** Forschende in AI/Bildung, Learning Analytics, Educational Data Mining; Pädagog:innen und Bildungstechnolog:innen; Policymakers im Bildungsbereich; KI-Ethiker:innen und Entwickler:innen verantwortungsvoller KI-Systeme; Universitäten und Bildungsinstitutionen, die KI implementieren

## Schlüsselreferenzen

- [[European_Union_2024]] - EU AI Act
- [[Rudin_2019]] - Stop explaining black box machine learning models for high stakes decisions
- [[Garcez_Lamb_2023]] - Neural-Symbolic AI Integration
- [[Heaton_et_al_2023]] - UK A-level Algorithm Bias Study
- [[UNESCO_2019]] - Beijing Consensus on Artificial Intelligence and Education
- [[Goellner_et_al_2024]] - Definition of Responsible AI
- [[Hooshyar_et_al_2024]] - Knowledge-Enhanced Autoencoders for Synthetic Data Generation
- [[Tato_Nkambou_2022]] - Bayesian Networks for Learner Modelling
- [[Cui_et_al_2024]] - Class Imbalance in Knowledge Tracing Datasets
- [[Jakesch_et_al_2022]] - Responsible AI for Human Dignity and Autonomy
