---
title: "AI literacy in K-12: a systematic literature review"
authors:
  - Lorena Casal-Otero
  - Alejandro Catala
  - Carmen Fernández-Morante
  - Maria Taboada
  - Beatriz Cebreiro
  - Senén Barro
year: 2023
type: journalArticle
doi: 10.1186/s40594-023-00418-7
url: "https://stemeducationjournal.springeropen.com/articles/10.1186/s40594-023-00418-7"
tags:
  - paper
llm_decision: Exclude
llm_confidence: 0.95
llm_categories:
  - AI_Literacies
human_decision: Include
human_categories:
  - AI_Literacies
  - KI_Sonstige
  - Gender
agreement: disagree
---

# AI literacy in K-12: a systematic literature review

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** AI_Literacies, KI_Sonstige, Bias_Ungleichheit, Gender, Diversitaet, Fairness
**Argumente:** 3 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 88 |
| Correctness | 97 |
| Category Validation | 92 |
| **Overall Confidence** | **92** |

### Stufe 4: Assessment

**LLM:** Exclude (Confidence: 0.95)
**Human:** Include

**Kategorie-Vergleich (bei Divergenz):**

| Kategorie | Human | LLM | Divergent |
|-----------|-------|-----|----------|
| AI_Literacies | Ja | Ja |  |
| Generative_KI | Nein | Nein |  |
| Prompting | Nein | Nein |  |
| KI_Sonstige | Ja | Nein | X |
| Soziale_Arbeit | Nein | Nein |  |
| Bias_Ungleichheit | Nein | Nein |  |
| Gender | Ja | Nein | X |
| Diversitaet | Nein | Nein |  |
| Feministisch | Nein | Nein |  |
| Fairness | Nein | Nein |  |

## Wissensdokument

# AI literacy in K-12: a systematic literature review

## Kernbefund

AI-Literacyförderung in K-12 konzentriert sich auf technische, konzeptuelle und angewandte Kompetenzen, allerdings gibt es kaum Assessments von Lernoutcomes und wenig Aufmerksamkeit für unerwünschte Konsequenzen von AI. Ein kohärenter Kompetenzrahmen ist erforderlich, um Curricula zu strukturieren und Geschlechterparität zu adressieren.

## Forschungsfrage

How are current approaches integrating AI literacy into K-12 education worldwide?

## Methodik

Systematische Literaturübersicht (SLR) - Scopus-Datenbank, 179 Dokumente analysiert, thematische Klassifizierung in zwei Gruppen: Lernexperienzen und theoretische Perspektiven
**Datenbasis:** 179 Dokumente aus Scopus (primäre Quellen von Elsevier, Springer, ACM, IEEE); Zeitraum nicht explizit angegeben, aber Überblick über aktuelle K-12 AI-Literatur weltweit

## Hauptargumente

- AI-Literacykompetenzen sollten über drei Achsen strukturiert werden: Lernen über AI, Verstehen wie AI funktioniert, Lernen zum Leben mit AI. Dies ermöglicht kritische Reflexion und verantwortungsvolle Nutzung durch Bürger, die in einer AI-durchdrungenen Welt aufwachsen.
- Lehrer sind zentrale Akteure für erfolgreiche AI-Integration in K-12 und benötigen standardisierte Kompetenzrahmen sowie Ko-Design von Curricula mit Praktikern. Professionelle Entwicklung sollte TPACK-Modelle nutzen und Lehrer bei der Konzeption einbeziehen.
- AI-Literacyförderung sollte interdisziplinär sein, Ethik, Sicherheit und soziale Implikationen adressieren sowie Geschlechterperspektive integieren. Allerdings werden unerwünschte Folgen wie Arbeitsautomation und wachsende Ungleichheit in K-12 kaum thematisiert.

## Kategorie-Evidenz

### Evidenz 1

AI literacy is defined as 'a set of skills that enable a solid understanding of AI through three priority axes: learning about AI, learning about how AI works, and learning for life with AI'. The paper systematically reviews 179 documents on AI literacy approaches in K-12 education worldwide.

### Evidenz 2

The paper addresses machine learning, data-driven design, robotics, computer vision, natural language processing, and knowledge representation as components of AI education in K-12 contexts.

### Evidenz 3

The paper identifies that 'little attention has been paid to the undesirable consequences of an indiscriminate and insufficiently thought-out application of AI' including 'the increase in socio-economic inequality between countries and within countries, resulting from the increasing automation of employment'.

### Evidenz 4

Explicitly addresses gender diversity: 'Due to the gender gap in issues related to computer science, it is also necessary to address the gender perspective.' Literature highlights 'proposals designed with a perspective toward gender, where the activities designed are specifically aimed at girls'.

### Evidenz 5

Paper discusses inclusion and representation: 'the existence of proposals designed with a perspective toward gender' and addresses reaching 'minority, female and disadvantaged students' in K-12 AI education.

### Evidenz 6

Calls for ethical framework: 'It should also address issues related to the ethical dimension, which is fundamental to the literacy of K-12 students as it enables them to understand the basic principles of AI' and includes fairness in AI system design considerations.

## Assessment-Relevanz

**Domain Fit:** Das Paper adressiert K-12 AI-Bildung mit explizitem Fokus auf Geschlechterparität und Diversität, thematisiert aber Soziale Arbeit nicht direkt. Der Bezug zu Sozialarbeit ergibt sich indirekt über Equity, Inklusion und marginalisierte Gruppen in Bildung, nicht durch Bezug zu sozialen Diensten oder Fachpraxis.

**Unique Contribution:** Systematische Übersicht über weltweite K-12 AI-Literacyansätze mit kritischer Analyse von Lücken (fehlende Assessments, unbeachtete Nebenwirkungen, Geschlechterperspektive), die einen Kompetenzrahmen und kohärente Curricula fordert.

**Limitations:** Fokus auf formale K-12-Bildung; begrenzte Analyse der Implementierbarkeit in ressourcenarm ausgestatteten Schulen; keine empirischen Daten zu tatsächlichen Lernoutcomes in Schulen; Zeitrahmen der Literatursuche nicht explizit angegeben.

**Target Group:** Bildungspolitiker, K-12-Lehrer und Lehrerausbilder, AI-Forscher im Bildungsbereich, Curriculum-Entwickler, Schulleitung, Bildungsforschende interessiert an 21st-century skills und Chancengleichheit

## Schlüsselreferenzen

- [[Long_Magerko_2020]] - AI Literacy Framework (three axes)
- [[Touretzky_et_al_2019]] - Envisioning AI for K-12
- [[Mishra_Koehler_2006]] - TPACK - Technological Pedagogical Content Knowledge
- [[Russell_Norvig_2021]] - Artificial Intelligence: A Modern Approach
- [[Kandlhofer_et_al_2016]] - AI Literacy comparable to reading and writing
- [[Yue_et_al_2021]] - Analysis of K-12 AI curricula in eight countries
- [[Heintz_2021]] - AI education from earliest stages
- [[Sanusi_et_al_2022]] - Systematic review of teaching machine learning in K-12
- [[Chai_Chiu_2020]] - Teacher perspectives on AI curriculum development
