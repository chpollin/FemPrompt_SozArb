---
title: "AI FORA – Artificial Intelligence for Assessment: Fairness bei der Verteilung öffentlicher sozialer Leistungen"
authors:
  - P. Ahrweiler
year: 2025
type: report
doi: 
url: "https://nachrichten.idw-online.de/2025/03/18/wie-koennte-kuenstliche-intelligenz-weltweit-fairness-bei-der-verteilung-oeffentlicher-sozialer-leistungen-erhoehen"
tags:
  - paper
llm_decision: Include
llm_confidence: 0.92
llm_categories:
  - KI_Sonstige
  - Soziale_Arbeit
  - Bias_Ungleichheit
  - Diversitaet
  - Fairness
human_decision: Exclude
human_categories:
  - Generative_KI
  - KI_Sonstige
  - Bias_Ungleichheit
  - Gender
  - Fairness
agreement: disagree
---

# AI FORA – Artificial Intelligence for Assessment: Fairness bei der Verteilung öffentlicher sozialer Leistungen

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** AI_Literacies, KI_Sonstige, Soziale_Arbeit, Bias_Ungleichheit, Diversitaet, Fairness
**Argumente:** 3 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 92 |
| Correctness | 98 |
| Category Validation | 95 |
| **Overall Confidence** | **95** |

### Stufe 4: Assessment

**LLM:** Include (Confidence: 0.92)
**Human:** Exclude

**Kategorie-Vergleich (bei Divergenz):**

| Kategorie | Human | LLM | Divergent |
|-----------|-------|-----|----------|
| AI_Literacies | Nein | Nein |  |
| Generative_KI | Ja | Nein | X |
| Prompting | Nein | Nein |  |
| KI_Sonstige | Ja | Ja |  |
| Soziale_Arbeit | Nein | Ja | X |
| Bias_Ungleichheit | Ja | Ja |  |
| Gender | Ja | Nein | X |
| Diversitaet | Nein | Ja | X |
| Feministisch | Nein | Nein |  |
| Fairness | Ja | Ja |  |

## Wissensdokument

# Participatory Artificial Intelligence in Public Social Services. From Bias to Fairness in Assessing Beneficiaries

## Kernbefund

Gerechtigkeitskriterien für staatliche Leistungen sind kultur- und kontextabhängig, daher reicht ein standardisiertes KI-System nicht aus. Stattdessen sind flexible, adaptive Systeme notwendig, die unter Einbeziehung aller gesellschaftlichen Akteure, besonders vulnerabler Gruppen, entwickelt werden.

## Forschungsfrage

Wie kann Künstliche Intelligenz bei der Verteilung öffentlicher sozialer Leistungen weltweit fairer und gerechter gestaltet werden, unter Berücksichtigung kultureller und kontextabhängiger Fairnesskriterien?

## Methodik

Mixed Methods: Internationale vergleichende Fallstudien in neun Ländern auf vier Kontinenten kombiniert mit partizipativer Forschung; ergänzt durch Modellierungs- und Simulationsforschung
**Datenbasis:** Neun Länder auf vier Kontinenten (Deutschland, Spanien, Estland, Ukraine, USA, Nigeria, Iran, Indien, China); 3,5-jähriges Forschungsprojekt; Sammelband mit ca. 300 Seiten; partizipative Forschungsmethoden

## Hauptargumente

- Künstliche Intelligenz wird zunehmend weltweit bei sozialen Bewertungen eingesetzt (Renten, Arbeitslosengeld, Asyl, Kindergartenplätze), aber die zugrunde liegenden Fairnesskonzepte sind kulturabhängig (z.B. Kastensystem in Indien, Bürgerscore in China), weshalb standardisierte globale Systeme inadäquat sind.
- Innerhalb von Gesellschaften existieren unterschiedliche und ständig ausgehandelte Perspektiven auf Gerechtigkeit, die sich in der Technologie niederschlagen müssen - eine Ein-Größe-passt-allen-Lösung ist nicht möglich.
- Die Entwicklung fairer KI-Systeme für öffentliche Leistungsvergabe ist auf partizipative, kontextspezifische und inklusive Entwicklungsprozesse angewiesen, die die Perspektiven von vulnerablen und marginalisierten Gruppen einbeziehen.

## Kategorie-Evidenz

### Evidenz 1

Das Projekt befasst sich mit der Notwendigkeit, dass 'alle gesellschaftlichen Akteure' zur 'Gestaltung von partizipativer, kontextspezifischer und fairer KI' beitragen müssen, was kritisches Verständnis und Kompetenzen im Umgang mit KI erfordert.

### Evidenz 2

Das Projekt untersucht KI-Systeme für automatisierte soziale Bewertungen und algorithmische Entscheidungsfindung in der öffentlichen Verwaltung.

### Evidenz 3

Der direkte Fokus liegt auf der Verteilung öffentlicher sozialer Leistungen (Renten, Arbeitslosengeld, Asylbewilligung, Kindergartenplätze) und damit auf Kernbereichen der Sozialen Arbeit und sozialer Dienste.

### Evidenz 4

Das Projekt adressiert explizit 'Diskriminierungsprobleme' ('Bias'), strukturelle Benachteiligung und die Tatsache, dass KI-Systeme unterschiedliche Gruppen ungleich behandeln können je nach Fairnesskonzept.

### Evidenz 5

Die Studie untersucht neun Länder mit unterschiedlichen kulturellen, politischen und sozialen Kontexten und betont die Notwendigkeit, 'vulnerable Gruppen' und die Perspektiven von 'marginalisierten' Akteuren in die KI-Entwicklung einzubeziehen.

### Evidenz 6

Das gesamte Projekt konzentriert sich auf 'Fairnesskriterien' und 'Fairness bei der Verteilung', wobei die Fallstudien zeigen, dass Fairnesskonzepte kultur- und kontextabhängig sind und nicht standardisiert sein können.

## Assessment-Relevanz

**Domain Fit:** Hochgradig relevant für die Schnittstelle KI-Systeme und Soziale Arbeit. Das Paper adressiert direkt, wie KI-Systeme in sozialen Diensten fairere und gerechtere Entscheidungen treffen können und betont dabei die Notwendigkeit partizipativer, kontextsensibler Entwicklung unter Einbeziehung vulnerabler Gruppen.

**Unique Contribution:** Das Projekt bietet einen seltenen internationalen, vergleichenden Überblick (9 Länder, 4 Kontinente) über KI-Systeme in sozialen Bewertungen und entwickelt ein theoretisches und praktisches Rahmenwerk für kontextabhängige, adaptive und partizipative KI-Systeme statt standardisierter Lösungen.

**Limitations:** Als Pressemitteilung sind Methodische Details begrenzt; die vollständige methodische Tiefe wird erst in den Publikationen (Sammelband und folgendes Buch) erkennbar.

**Target Group:** Policymaker und Administratoren in sozialen Diensten, KI-Entwickler und Data Scientists im öffentlichen Sektor, Sozialarbeiter und Fachkräfte in sozialen Diensten, Vertreter von marginalisierten Gruppen und Interessenverbänden, Wissenschaftler im Bereich KI, Soziale Arbeit, und Gerechtigkeit

## Schlüsselreferenzen

- [[Ahrweiler_Petra_Ed_2025]] - Participatory Artificial Intelligence in Public Social Services. From Bias to Fairness in Assessing Beneficiaries
