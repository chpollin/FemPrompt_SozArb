---
title: "Intersectional analysis of visual generative AI: the case of stable diffusion"
authors:
  - S. Sharma
  - A. Ovalle
  - A. Subramonian
year: 2024
type: journalArticle
doi: 
url: "https://link.springer.com/article/10.1007/s00146-025-02498-1"
tags:
  - paper
llm_decision: Include
llm_confidence: 0.95
llm_categories:
  - Generative_KI
  - Bias_Ungleichheit
  - Gender
  - Diversitaet
  - Feministisch
human_decision: Include
human_categories:
  - Generative_KI
  - Prompting
  - Bias_Ungleichheit
  - Gender
  - Feministisch
  - Fairness
agreement: agree
---

# Intersectional analysis of visual generative AI: the case of stable diffusion

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** AI_Literacies, KI_Sonstige, Soziale_Arbeit, Bias_Ungleichheit, Gender, Diversitaet, Fairness
**Argumente:** 3 extrahiert

### Stufe 4: Assessment

**LLM:** Include (Confidence: 0.95)
**Human:** Include

## Wissensdokument

# Understanding how users may work around algorithmic bias

## Kernbefund

Das Paper entwickelt einen theoretischen Rahmen, der zeigt, wie Nutzer:innen durch Cue-Routes (Wahrnehmung) und Action-Routes (Verhalten) unterschiedliche Workaround-Strategien entwickeln, um mit algorithmischem Bias umzugehen. Die vier Kategorien von Bias führen zu verschiedenen Ergebnissen: von Empowerment bei erfolgreichen Workarounds bis zu technologischer Naivität bei unwahrgenommenen Bias.

## Forschungsfrage

Wie reagieren und passen sich Nutzer:innen an vier epistemische Kategorien von algorithmischem Bias an (existent/wahrgenommen, existent/nicht wahrgenommen, nicht existent/wahrgenommen, nicht existent/nicht wahrgenommen)?

## Methodik

Theoretisch - Konzeptuelle Analyse unter Anwendung der HAII-TIME (Human-AI Interaction Theory of Interactive Media Effects) auf Workaround-Strategien; Systematische Literaturanalyse zu Bias-Quellen und Manifestationen
**Datenbasis:** nicht angegeben (konzeptuelles theoretisches Paper)

## Hauptargumente

- Algorithmischer Bias ist ein weit verbreitetes Problem mit dokumentierten Fällen in Gesundheitswesen, Justiz, Einstellungsverfahren und sozialen Medien, das bestimmte Gruppen (besonders Menschen mit dunkler Hautfarbe, Frauen, marginalisierte Communities) systematisch benachteiligt.
- Workarounds sind ein geeignetes Konzept zur Charakterisierung von Nutzer:innen-Reaktionen auf algorithmischen Bias, da sie sowohl technische Anpassungen (VPNs, Incognito-Modus, Einstellungsänderungen) als auch verhaltensbasierte Strategien (Content-Curation, veränderte Kommunikationsmuster) umfassen.
- Die HAII-TIME-Theorie ermöglicht ein nuanciertes Verständnis dafür, wie Nutzer:innen Bias erkennen (Cue-Route) und dann Workarounds entwickeln (Action-Route) durch Interaktion, Agentur, soziale Austauschprozesse und gegenseitige Verstärkung mit KI-Systemen.

## Kategorie-Evidenz

### Evidenz 1

Das Paper diskutiert explizit 'algorithmic literacy' und wie Nutzer:innen ihre Fähigkeit entwickeln, algorithmische Systeme zu verstehen und zu navigieren: 'Understanding these adaptive strategies provides crucial insights for developing inclusive technologies and fostering algorithmic literacy'.

### Evidenz 2

Fokus auf algorithmische Entscheidungssysteme (nicht generativ) in verschiedenen Bereichen wie Gesichtserkennungsalgorithmen, Kreditscoring, Einstellungsalgorithmen, Healthcare-Algorithmen, Empfehlungssysteme.

### Evidenz 3

Expliziter Fokus auf vulnerable und marginalisierte Gruppen, die durch algorithmischen Bias benachteiligt werden; Bezug zu sozialen Wohlfahrtssystemen und deren algorithmischen Kontrolle: 'Algorithms leading to widespread rejection of welfare benefit claims for low-income applicants'; Zitation von Eubanks (2018) 'Automating Inequality'.

### Evidenz 4

Zentrale Thematik des gesamten Papers; dokumentiert systematische Benachteiligung durch Algorithmen: 'smartwatches have been found to provide less accurate data...to those with dark skin'; 'facial recognition systems more frequently misgender individuals with darker skin'; 'healthcare algorithms systematically favor White patients over Black patients'.

### Evidenz 5

Mehrfach explizit behandelt: 'justice algorithms more often label women as high recidivism risks when determining parole'; 'hiring algorithms discriminating based on gender, race, and personality'; COMPAS-Algorithmus mit geschlechtsspezifischen Effekten; 'NIST audit finding...facial algorithms perform worse for women'.

### Evidenz 6

Intersektionale Perspektive auf verschiedene marginalisierte Gruppen: Menschen mit dunkler Hautfarbe, Frauen, Menschen mit afrikanisch-amerikanischem Englisch, Mieter:innen mit schwarzem/hispanischem Hintergrund, Menschen mit Behinderungen (blind assistive technology).

### Evidenz 7

Diskussion von fairness-relevanten Konzepten: 'proxy bias' (Variablen als unbeabsichtigte Proxies für geschützte Merkmale), 'equalized odds', Fairness-Metriken in ML, 'bias mitigation' Strategien, verschiedene Fairness-Ansätze in Algorithmendesign.

## Assessment-Relevanz

**Domain Fit:** Das Paper ist hochgradig relevant für die Schnittstelle KI/Soziale Arbeit/Gender Studies, da es systematisch dokumentiert, wie algorithmische Systeme vulnerable Gruppen (insbesondere marginalisierte Communities, Frauen, Menschen mit dunkler Hautfarbe) in kritischen Bereichen wie Wohlfahrt, Justiz und Gesundheit benachteiligen, und Ansätze zur Nutzer:innen-Agency gegen diese Systeme entwickelt.

**Unique Contribution:** Der innovative Beitrag liegt in der konzeptuellen Integration von Workaround-Theorie mit HAII-TIME zur Entwicklung eines 2x2-Typologierahmens (vier epistemische Kategorien von Bias), der differenziert erklärt, wie und wann Nutzer:innen Bias-Workarounds entwickeln und welche Outcomes entstehen.

**Limitations:** Das Paper ist rein theoretisch-konzeptuell ohne empirische Validierung; es übersieht strukturelle und kollektive Faktoren zugunsten individueller kognitiver Prozesse; die HAII-TIME-Theorie ist neu und wenig validiert; die Analyse berücksichtigt nicht ausreichend, dass marginalisierte Gruppen Bias-Umgang durch kollektive Erfahrung statt nur technische Cues entwickeln.

**Target Group:** Wissenschaftler:innen in KI/Mensch-Computer-Interaktion, Sozialarbeiter:innen und Policy-Maker:innen, die mit algorithmischer Diskriminierung konfrontiert sind, Technologiedesigner:innen, Bildungsverantwortliche für KI-Literacy, Forscher:innen in Digital-Divide und Gender Studies

## Schlüsselreferenzen

- [[Buolamwini_Gebru_2018]] - Gender Shades - Intersectional Accuracy Disparities in Commercial Gender Classification
- [[Eubanks_2018]] - Automating Inequality: How High-Tech Tools Profile, Police, and Punish the Poor
- [[Noble_2018]] - Algorithms of Oppression: How Search Engines Reinforce Racism
- [[Obermeyer_et_al_2019]] - Dissecting Racial Bias in an Algorithm Used to Manage the Health of Populations
- [[Friedman_Nissenbaum_1996]] - Bias in Computer Systems
- [[Sweeney_2013]] - Discrimination in Online Ad Delivery
- [[Sundar_2020]] - Rise of Machine Agency: A Framework for Studying the Psychology of Human-AI Interaction (HAII)
- [[Hamilton_2019]] - The Sexist Algorithm
- [[ONeil_2016]] - Weapons of Math Destruction: How Big Data Increases Inequality
- [[Lee_et_al_2019]] - Algorithmic Bias Detection and Mitigation: Best Practices and Policies to Reduce Consumer Harms
