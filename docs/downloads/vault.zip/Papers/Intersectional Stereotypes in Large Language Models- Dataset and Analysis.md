---
title: Intersectional Stereotypes in Large Language Models: Dataset and Analysis
authors:
  - W. Ma
  - B. Chiang
  - T. Wu
  - L. Wang
  - S. Vosoughi
year: 2023
type: conferencePaper
url: https://aclanthology.org/2023.findings-emnlp.575.pdf
doi: 10.18653/v1/2023.findings-emnlp.575
tags:
  - paper
  - feminist-ai
  - bias-research
date_added: 2026-02-22
date_modified: 2026-02-22
bias_types:
  - Stereotypen
  - Discrimination
  - Stereotypisierungsmustern
  - Intersectional Stereotypes
  - Stereotypenkategorien
  - Intersectionality
  - Stereotypisierungsgrad
  - Stereotype
  - Stereotypical
  - Stereotyping
  - Intersectional Demographic
mitigation_strategies:
  - Debiasing
  - Intersectional Demographic
  - Intersectional Stereotypes
  - Intersectionality
llm_decision: Include
llm_confidence: 0.95
llm_categories:
  - Generative_KI
  - Prompting
  - Bias_Ungleichheit
  - Gender
  - Diversitaet
  - Feministisch
  - Fairness
human_decision: Include
human_categories:
  - Generative_KI
  - Prompting
  - Bias_Ungleichheit
  - Gender
  - Diversitaet
agreement: agree
---

# Intersectional Stereotypes in Large Language Models: Dataset and Analysis

## Abstract

This EMNLP paper introduces a dataset for studying intersectional stereotypes and applies it to three LLMs. Results reveal emergent stereotypes not predictable from single-attribute analysis. Prompt engineering reduces but does not eliminate such patterns, highlighting persistent biases in generated narratives.

## Assessment

**LLM Decision:** Include (Confidence: 0.95)
**LLM Categories:** Generative_KI, Prompting, Bias_Ungleichheit, Gender, Diversitaet, Feministisch, Fairness
**Human Decision:** Include
**Human Categories:** Generative_KI, Prompting, Bias_Ungleichheit, Gender, Diversitaet
**Agreement:** Agree

## Key Concepts

### Bias Types
- [[Discrimination]]
- [[Intersectional Demographic]]
- [[Intersectional Stereotypes]]
- [[Intersectionality]]
- [[Stereotype]]
- [[Stereotypen]]
- [[Stereotypenkategorien]]
- [[Stereotypical]]
- [[Stereotyping]]
- [[Stereotypisierungsgrad]]
- [[Stereotypisierungsmustern]]

### Mitigation Strategies
- [[Debiasing]]
- [[Intersectional Demographic]]
- [[Intersectional Stereotypes]]
- [[Intersectionality]]

## Full Text

---
title: "Intersectional Stereotypes in Large Language Models: Dataset and Analysis"
authors: ["Weicheng Ma", "Brian Chiang", "Tong Wu", "Lili Wang", "Soroush Vosoughi"]
year: 2023
type: conferencePaper
language: en
processed: 2026-02-05
source_file: Ma_2023_Intersectional_Stereotypes_in_Large_Language.md
confidence: 95
---

# Intersectional Stereotypes in Large Language Models: Dataset and Analysis

## Kernbefund

Trotz Debiasing-Maßnahmen zeigen moderne LLMs (GPT-3, ChatGPT) komplexe intersektionale Stereotypen gegenüber 106 verschiedenen Gruppen, mit unterschiedlichen Stereotypisierungsmustern pro Modell, was spezifische Mitigationsmaßnahmen erfordert.

## Forschungsfrage

Inwiefern propagieren Large Language Models intersektionale Stereotypen gegenüber Gruppen, die mehrere demografische Merkmale kombinieren?

## Methodik

Empirisch: Automatische Datengenerierung mit ChatGPT zur Erstellung eines Stereotypen-Datensatzes (14 demografische Merkmale über 6 Kategorien), manuelle Validierung durch 3 Annotatoren (98,33% Übereinstimmung), anschließende Prüfung von GPT-3 und ChatGPT mittels simulierter Rollen und Stereotype Degree (SDeg)-Messung über 16 Stereotypenkategorien.
**Datenbasis:** Automatisch generierter Datensatz von 478 Stereotypen (4,53 durchschnittlich pro Gruppe) für 106 intersektionale Gruppen, validiert durch 3 menschliche Annotatoren; Test mit 10 simulierten Rollen pro intersektionaler Gruppe

## Hauptargumente

- Bisherige Stereotypen-Forschung in LLMs fokussiert isolierte Kategorien (Rasse, Geschlecht), ignoriert aber intersektionale Effekte, wo sich mehrere marginalisierte Identitäten überschneiden und eigenständige, komplexere Stereotype erzeugen.
- ChatGPT kann effektiv zur Generierung realistischer Stereotypen bis zu vier intersektionalen Merkmalen eingesetzt werden, wenn durch Prompt-Design (Problem Statement, Regulation, Disclaimer) und nachfolgende Validierung Halluzinationen und Overgeneralisierung minimiert werden.
- Unterschiedliche LLMs entwickeln spezifische intersektionale Bias-Muster (z.B. GPT-3 stärker bei 'junge schwarze Menschen', ChatGPT bei 'schwarze Menschen ohne Behinderung'), daher ist eine differenzierte, modell- und gruppenspezifische Debiasing-Strategie notwendig.

## Kategorie-Evidenz

### Evidenz 1

Das Paper untersucht explizit zwei generative LLMs: 'we probed the presence of stereotypes within two contemporary LLMs, GPT-3 (Brown et al., 2020) and ChatGPT (GPT-3.5)' und nutzt ChatGPT zur Datengenerierung.

### Evidenz 2

Detailliertes Prompt-Design mit drei Komponenten: 'The design of our prompts, which are used to retrieve stereotypes from ChatGPT, encompasses three key components: the problem statement, regulation, and disclaimer.' (Section 2.2)

### Evidenz 3

NLP-Analyse, Stereotypen in Sprachmodellen, Untersuchung von Bias in trainierten Modellen über Generierungsaufgaben.

### Evidenz 4

Zentrales Thema: 'Despite many stereotypes targeting intersectional demographic groups, prior studies on stereotypes within Large Language Models (LLMs) primarily focus on broader, individual categories.' Die Paper dokumentiert systematisch Diskriminierungsmuster.

### Evidenz 5

Expliziter Fokus auf intersektionale Gruppen: 'we significantly broaden our scope by considering six demographic categories: race (white, black, and Asian), age (young and old), religion (non-religious, Christian, and Muslim), gender (men and women), political leaning (conservative and progressive), and disability status'

### Evidenz 6

Evaluation algorithmischer Fairness durch Stereotype Degree (SDeg)-Metriken zur Quantifizierung von Stereotypisierungsgrad in LLMs: 'We quantify the stereotype exhibited by the LLM by examining the maximum frequency with which the ten responses generated by the LLM match each expected answer.'

## Assessment-Relevanz

**Domain Fit:** Das Paper ist für die Schnittstelle KI und Fairness hochrelevant, da es systematisch aufzeigt, wie moderne generative KI-Systeme strukturelle Diskriminierungsmuster gegen marginalisierte, intersektionale Gruppen propagieren. Die Erkenntnisse haben direkte Implikationen für die verantwortungsvolle Entwicklung und den Einsatz von KI-Systemen.

**Unique Contribution:** Das Paper schließt eine Forschungslücke durch die erste umfassende, intersektional differenzierte Untersuchung von Stereotypen in LLMs (6 demografische Kategorien, bis zu 4+ intersektionale Merkmale, 16 Stereotypenkategorien) und demonstriert zugleich eine innovative Methodik zur Datengenerierung und -validierung mithilfe von LLMs selbst.

**Limitations:** Das Paper weist selbst darauf hin, dass ChatGPT als Datengenerierungs-Tool möglicherweise eigene 'Standpunkte' und soziale Werte in die generierten Stereotypen einbringt; zudem funktioniert die automatische Generierung ab 5+ intersektionalen Merkmalen schlecht, was größere Kombinationen ausschließt.

**Target Group:** KI-Entwickler und Machine Learning-Forscher (Debiasing-Strategien), NLP-Community, Policy-Maker im Bereich KI-Regulierung und Fairness, sowie Organisationen, die Large Language Models evaluieren und einsetzen (Compliance, Risikobewertung)

## Schlüsselreferenzen

- [[Cheng_et_al_2023]] - Marked personas: Using natural language prompts to measure stereotypes in language models
- [[Cao_et_al_2022]] - Theory-grounded measurement of U.S. social stereotypes in English language models
- [[Hassan_et_al_2021]] - Unpacking the interdependent systems of discrimination: Ableist bias in nlp systems through an intersectional lens
- [[Zhao_et_al_2018]] - Gender bias in coreference resolution: Evaluation and debiasing methods
- [[Nadeem_et_al_2021]] - StereoSet: Measuring stereotypical bias in pretrained language models
- [[Nangia_et_al_2020]] - CrowS-pairs: A challenge dataset for measuring social biases in masked language models
- [[Tan_Celis_2019]] - Assessing social and intersectional biases in contextualized word representations
- [[Rudinger_et_al_2018]] - Gender bias in coreference resolution
- [[Brown_et_al_2020]] - Language models are few-shot learners
- [[Ferrara_2023]] - Should chatgpt be biased? challenges and risks of bias in large language models
