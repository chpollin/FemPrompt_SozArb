---
title: Investigating AI systems: examining data and algorithmic bias through hermeneutic reverse engineering
authors:
  - N. Shukla
year: 2025
type: journalArticle
url: https://www.frontiersin.org/journals/communication/articles/10.3389/fcomm.2025.1380252/full
tags:
  - paper
  - feminist-ai
  - bias-research
date_added: 2026-02-22
date_modified: 2026-02-22
bias_types:
  - Algorithmic Bias
  - Intersectional Accuracy
  - Intersectionality
mitigation_strategies:
  - Intersectional Accuracy
  - Intersectionality
  - Inclusive And
---

# Investigating AI systems: examining data and algorithmic bias through hermeneutic reverse engineering

## Abstract

This work presents hermeneutic reverse engineering as a framework for investigating bias in AI systems. The approach considers AI systems as boundary objects and analyzes cultural meanings and assumptions embedded in techno-cultural objects. The study proposes three research perspectives: (1) comparative exploration of algorithmic bias, (2) investigation of impacts on various social groups, and (3) participatory approaches to include users in AI design.

## Key Concepts

### Bias Types
- [[Algorithmic Bias]]
- [[Intersectional Accuracy]]
- [[Intersectionality]]

### Mitigation Strategies
- [[Inclusive And]]
- [[Intersectional Accuracy]]
- [[Intersectionality]]

## Full Text

---
title: "Investigating AI systems: examining data and algorithmic bias through hermeneutic reverse engineering"
authors: ["Nishanshi Shukla"]
year: 2025
type: journalArticle
language: en
processed: 2026-02-05
source_file: Shukla_2025_Investigating_AI_systems_examining_data_and.md
confidence: 95
---

# Investigating AI systems: examining data and algorithmic bias through hermeneutic reverse engineering

## Kernbefund

AI-Systeme als Boundary Objects zu betrachten und durch hermeneutisches Reverse Engineering kritisch zu untersuchen ermöglicht es, versteckte Bias in Daten und Algorithmen aufzudecken und alternative, inklusivere Futures zu imaginieren. Bias ist kein Fehler sondern systemische Kodierung der dominanten sozialen Struktur.

## Forschungsfrage

Wie können KI-Systeme durch hermeneutisches Reverse Engineering untersucht werden, um Bias in Daten und Algorithmen aufzudecken und alternative, gerechtere Zukünfte zu gestalten?

## Methodik

Theoretisch/Review - Literaturbasierte kritische Analyse mit Einsatz von hermeneutischem Reverse Engineering als Rahmenwerk; kritische Daten-, Algorithmen- und Code-Studien sowie feministische Wissenschafts- und Technologiestudien

## Hauptargumente

- AI-Systeme haben Politiken und üben Macht aus; Bias in KI ist nicht zufällig sondern systemic coding of dominant social fabric, der rassistische, geschlechtsspezifische und ableistische Geschichte reproduziert und verstärkt.
- Daten sind politische Werkzeuge, die immer subjektiv und partiell sind; die Trennung von Daten aus ihrem historischen und kontextuellen Ursprung maskiert subjektive Bedeutungen und ermöglicht diskriminatorische algorithmische Entscheidungen.
- Algorithmen und Code sind ebenfalls politische Werkzeuge; ihre Untersuchung durch hermeneutisches Reverse Engineering mit intersektional-feministischer Perspektive offenbart Power Play und ermöglicht die Imagination alternativer, nicht-diskriminatorischer Realitäten.

## Kategorie-Evidenz

### Evidenz 1

Paper argumentiert für kritische Untersuchung und Verständnis von KI-Systemen: 'examining each part related to the building and working of AI systems is essential for unpacking the political play and potential insert points of biases'

### Evidenz 2

Fokus auf AI systems generell, deren Daten, Algorithmen, Code und deren Auswirkungen: 'AI systems, like all other technologies, have politics and exercise power'

### Evidenz 3

Paper diskutiert Impact auf verschiedene soziale Gruppen und marginalisierte Communities: 'the groups most impacted by the results of injustices enacted by AI are often devoid of resources to design and deploy these systems'

### Evidenz 4

Zentral: 'Bias based on race, gender, ability, language, class, economic background, and religion, among many other indicators, perpetuating in the AI systems are not just a glitch or an error, but systemic coding of the dominant social fabric'

### Evidenz 5

Explizites Genderbeispiel: 'Keyes (2018) showcases how a conventional binary understanding of gender within tools of Automatic Gender Recognition (AGR) operationalizes non-inclusive and harmful technologies for transgender people'

### Evidenz 6

Intersektionale Perspektive durchgehend: 'such as women, people of color, disabled people, and queer people'; 'interlocking systems of structural oppression'

### Evidenz 7

Explizit intersektional-feministische Theorie: 'based in intersectional feminist thought of acknowledging and understanding interlocking systems of structural oppression as stated by the Combahee River Collective Statement'; verwendet Combahee River Collective (1978) als theoretisches Fundament

### Evidenz 8

Fokus auf algorithmische Fairness und Gerechtigkeit: 'actionable AI audits that lead to the reduction of biased results'; 'strategies based on alignments between AI practitioners and fairness literature'; 'tensions of fairness at the intersection of individual and group needs'

## Assessment-Relevanz

**Domain Fit:** Sehr relevant für Schnittstelle AI/Soziale Arbeit/Gender - das Paper verbindet KI-Kritik explizit mit sozialer Gerechtigkeit, marginalisierten Gruppen und intersektional-feministischer Theorie, was direkt für Soziale Arbeit als gesellschaftlich orientierte Disziplin relevant ist.

**Unique Contribution:** Das Paper bietet einen systematischen methodologischen Rahmen (hermeneutisches Reverse Engineering) zur kritischen Analyse von AI-Bias unter explizit intersektional-feministischer Perspektive und konkretisiert dies durch Analyse von Daten, Algorithmen und Code.

**Limitations:** Das Paper ist primär theoretisch-konzeptuell; es fehlen empirische Fallstudien oder konkrete Anwendungen der hermeneutischen Reverse Engineering-Methodik auf spezifische AI-Systeme.

**Target Group:** AI-Entwickler und -Praktiker, Sozialarbeiter und Sozialwissenschaftler, Policymaker und Regulatoren, Genderforschung, Critical Algorithm Studies-Forschende, marginalisierte Communities, Tech-Ethics-Professionelle

## Schlüsselreferenzen

- [[Buolamwini_J_2023]] - Unmasking AI: My mission to protect what is human in a world of machines
- [[Benjamin_R_2019]] - Race after technology: abolitionist tools for the new Jim code
- [[Buolamwini_J_Gebru_T_2018]] - Gender Shades: Intersectional accuracy disparities in commercial gender classification
- [[Crawford_K_2021]] - Atlas of AI
- [[Eubanks_V_2019]] - Automating inequality: how high-tech tools profile, police, and punish the poor
- [[Noble_S_U_2018]] - Algorithms of oppression: how search engines reinforce racism
- [[Gebru_T_2020]] - Race and gender: data-driven claims about race and gender
- [[Balsamo_A_2011]] - Designing culture: the technological imagination at work
- [[Broussard_M_2023]] - More than a glitch: Confronting race, gender, and ability bias in tech
- [[Combahee_River_Collective_1978]] - A Black Feminist Statement
