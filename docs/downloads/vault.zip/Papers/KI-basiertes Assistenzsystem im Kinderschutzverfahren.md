---
title: KI-basiertes Assistenzsystem im Kinderschutzverfahren
authors:
  - M. Feist-Ortmanns
  - A. Sauer
  - M. Brinkmann
year: 2025
type: bookSection
doi: 
url: "https://afet-ev.de/assets/themenplattform/KI-in-der-Kinder--und-Jugendhilfe-Naher-Grasshoff-Forum-2.pdf"
tags:
  - paper
llm_decision: Include
llm_confidence: 0.92
llm_categories:
  - AI_Literacies
  - KI_Sonstige
  - Soziale_Arbeit
  - Bias_Ungleichheit
  - Fairness
human_decision: Exclude
human_categories: []
agreement: disagree
---

# KI-basiertes Assistenzsystem im Kinderschutzverfahren

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** AI_Literacies, Generative_KI, Prompting, KI_Sonstige, Soziale_Arbeit, Bias_Ungleichheit, Diversitaet, Fairness
**Argumente:** 3 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 88 |
| Correctness | 92 |
| Category Validation | 85 |
| **Overall Confidence** | **88** |

### Stufe 4: Assessment

**LLM:** Include (Confidence: 0.92)
**Human:** Exclude

**Kategorie-Vergleich (bei Divergenz):**

| Kategorie | Human | LLM | Divergent |
|-----------|-------|-----|----------|
| AI_Literacies | Nein | Ja | X |
| Generative_KI | Nein | Nein |  |
| Prompting | Nein | Nein |  |
| KI_Sonstige | Nein | Ja | X |
| Soziale_Arbeit | Nein | Ja | X |
| Bias_Ungleichheit | Nein | Ja | X |
| Gender | Nein | Nein |  |
| Diversitaet | Nein | Nein |  |
| Feministisch | Nein | Nein |  |
| Fairness | Nein | Ja | X |

## Wissensdokument

# KI-basiertes Assistenzsystem in der Kinder- und Jugendhilfe: Digitalität, Kinderschutz und Hilfeplanung

## Kernbefund

KI-Systeme sind nicht neutrale Werkzeuge sondern Akteure, die die sozialpädagogische Praxis grundlegend transformieren. Ein verantwortungsvoller Einsatz erfordert kritische Reflexion von Bias, Transparenz und das Primat des Kindeswohls.

## Forschungsfrage

Wie können KI-Systeme und digitale Technologien in der Kinder- und Jugendhilfe verantwortungsvoll eingesetzt werden, und welche Auswirkungen haben sie auf die Praktiken in Kinderschutz und Hilfeplanung?

## Methodik

Theoretisch-konzeptionell mit praktischen Explorationen und Zukunftsszenarios; kombiniert Literaturreview zu Digitalität mit Use-Case-Szenarien und Diskussionsprompts für Fachkräfte
**Datenbasis:** keine empirischen Daten; theoretisches Konzeptpapier mit Szenarien und Fallbeispielen

## Hauptargumente

- Digitalität als Alltagspraxis erfordert eine Unterscheidung zwischen technischen Innovationen (z.B. digitale Fallakten) und lebensweltlicher Digitalität von Adressat:innen; dies betont die Notwendigkeit, analytische Differenzen zu bewahren.
- KI-Systeme sind nicht neutrale Entscheidungshilfen, sondern Akteure, die eigene Agency ausüben und die Professionskulturen sowie Machtdynamiken in der Sozialen Arbeit beeinflussen.
- Bias in Trainingsdaten und algorithmischen Designs kann zu Diskriminierung marginalisierter Gruppen führen; ein ethischer Rahmen mit Prinzipien wie Transparenz, Fairness und Kindeswohl als oberste Priorität ist erforderlich.

## Kategorie-Evidenz

### Evidenz 1

Entwicklung von Leitlinien für ethischen Einsatz von KI in sozialer Arbeit; Schulung und Aufklärung von Fachkräften über Nutzung und Grenzen von KI-Tools; Abschnitt 'Verantwortungsvoller Umgang mit KI' adressiert Kompetenzentwicklung.

### Evidenz 2

Detaillierte Darstellung von ChatGPT, GPT-3.5, GPT-4, GPT-4o und deren Entwicklung; praktische Beispiele für text- und bildgenerierende KI-Tools (DALL-E, Deepl, Murf.ai, Sora, AIVA) im Kontext der Jugendhilfe.

### Evidenz 3

Exkurs zu Prompts mit Kategorien Klarheit, Kontext, Zielformulierung; Beispiele einfacher und komplexer Prompts für die Kinder- und Jugendhilfe; Diskussion von Sprache, Ton und Formulierungsstrategien.

### Evidenz 4

Klassische Programmierung vs. KI-Systeme; Machine Learning, Deep Learning, neuronale Netze; algorithmische Entscheidungssysteme; Natural Language Processing; Computer Vision für Verhaltenserkennung in AR-Szenarien.

### Evidenz 5

Direkter Fokus auf Anwendungen in Kinder- und Jugendhilfe (KJSH), Kinderschutz, Hilfeplanung, Hausbesuche, Online-Beratung, digitale Hilfeplangespräche; Praxisszenarien mit Fachkräften und Familien.

### Evidenz 6

Ausführliche Thematisierung von Bias in Trainingsdaten, algorithmischen Verzerrungen und Mangel an Diversität in der KI-Entwicklung; Folgen von Diskriminierung durch KI für marginalisierte Gruppen; Risiken für Arbeitsmarkt.

### Evidenz 7

Abschnitt zu Mangel an Diversität unter KI-Entwickler:innen und Forscher:innen; Forderung nach Inklusion und interkulturellen Perspektiven in der Kinder- und Jugendhilfe; Berücksichtigung verschiedener lebensweltlicher Kontexte.

### Evidenz 8

Grundprinzipien für ethischen Einsatz: Respektierung der Privatsphäre, Transparenz, Verantwortung und Rechenschaft, Fairness und Nicht-Diskriminierung, Kindeswohl als oberste Priorität; kritische Diskussion von Fair-ML-Anforderungen.

## Assessment-Relevanz

**Domain Fit:** Hochgradig relevant für die Schnittstelle KI und Soziale Arbeit. Das Paper adressiert konkret die Implementierung von KI-Systemen in der Kinder- und Jugendhilfe und kombiniert technisches Verständnis mit sozialpädagogischen Herausforderungen. Gender Studies sind nicht zentral, aber Diversität und Fairness werden thematisiert.

**Unique Contribution:** Bietet eine deutschsprachige, praxisorientierte Systematisierung von KI-Anwendungen in der Kinder- und Jugendhilfe mit kritischem Fokus auf Bias, Ethik und die Agentur von KI-Systemen; verbindet theoretische Konzepte von Digitalität mit konkreten 2035-Zukunftsszenarien für Fachkräfte.

**Limitations:** Keine empirischen Daten oder Evaluationsstudien; theoretisch-explorativer Charakter; Gender-Perspektive unterentwickelt; keine tiefergehende Analyse von intersektionalen Effekten; Anwendungsbeispiele sind Szenarien ohne Implementierungsevaluierung.

**Target Group:** Fachkräfte in der Kinder- und Jugendhilfe, Sozialarbeiter:innen, Leitungskräfte von Hilfeeinrichtungen, Ausbilder:innen im Bereich Soziale Arbeit, KI-Implementator:innen in sozialen Diensten, Policy-Maker:innen im Bereich Jugendhilfe, Hochschullehrende in Sozialwissenschaften und KI-Ethik

## Schlüsselreferenzen

- [[Stalder_2016]] - Kultur der Digitalität
- [[Weinhardt_2021]] - Doing Digitality
- [[Bettinger_Hugger_2020]] - Digitalität als Alltagspraxis
- [[Weizenbaum_1966]] - ELIZA - Chatbot als Psychotherapeutin-Simulation
- [[Turing_1950]] - Turing Test
- [[OpenAI_2022]] - ChatGPT und GPT-3.5
- [[OpenAI_2023]] - GPT-4
