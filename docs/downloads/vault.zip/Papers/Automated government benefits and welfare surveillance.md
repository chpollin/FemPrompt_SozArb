---
title: Automated government benefits and welfare surveillance
authors:
  - L. Dencik
  - A. Hintz
  - J. Redden
  - H. Warne
year: 2024
type: journalArticle
doi: 
url: "https://ojs.library.queensu.ca/index.php/surveillance-and-society/article/view/16107"
tags:
  - paper
llm_decision: Include
llm_confidence: 0.92
llm_categories:
  - KI_Sonstige
  - Soziale_Arbeit
  - Bias_Ungleichheit
human_decision: Exclude
human_categories:
  - KI_Sonstige
  - Soziale_Arbeit
agreement: disagree
---

# Automated government benefits and welfare surveillance

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** AI_Literacies, KI_Sonstige, Soziale_Arbeit, Bias_Ungleichheit, Diversitaet, Fairness
**Argumente:** 3 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 92 |
| Correctness | 98 |
| Category Validation | 95 |
| **Overall Confidence** | **95** |

### Stufe 4: Assessment

**LLM:** Include (Confidence: 0.92)
**Human:** Exclude

**Kategorie-Vergleich (bei Divergenz):**

| Kategorie | Human | LLM | Divergent |
|-----------|-------|-----|----------|
| AI_Literacies | Nein | Nein |  |
| Generative_KI | Nein | Nein |  |
| Prompting | Nein | Nein |  |
| KI_Sonstige | Ja | Ja |  |
| Soziale_Arbeit | Ja | Ja |  |
| Bias_Ungleichheit | Nein | Ja | X |
| Gender | Nein | Nein |  |
| Diversitaet | Nein | Nein |  |
| Feministisch | Nein | Nein |  |
| Fairness | Nein | Nein |  |

## Wissensdokument

# Automated Government Benefits and Welfare Surveillance

## Kernbefund

Die zentralen Probleme automatisierter Wohlfahrtsüberwachung sind nicht technologisch neuartig, sondern wiederholen historisch dokumentierte Muster von Verdacht gegenüber Armen, opaker Entscheidungsfindung und strafender Maßnahmen gegen marginalisierte Gruppen, die bereits vor der KI-Ära bestanden.

## Forschungsfrage

Was bedeutet künstliche Intelligenz für die Überwachung im digitalen Wohlfahrtsstaat, und sind die Probleme technologisch neuartig oder wiederholen sie historisch bekannte Muster administrativer Kontrolle?

## Methodik

Theoretisch/Literatur-Review mit fallgestützter Analyse; kritische Analyse von Governance-Infrastrukturen und deren historischen Kontinuitäten; Dokumentenanalyse (besonders niederländische SyRI-Skandal)
**Datenbasis:** nicht angegeben (theoretische und dokumentarische Analyse ohne Primärdatenerhebung)

## Hauptargumente

- KI-Technologien in der Wohlfahrtsverwaltung sollten als 'politische Technologien' verstanden werden, die der Regierungskontrolle dienen und von Governance-Problemen geprägt sind, nicht von technologischen Innovationen. Algorithmen sind Ausdruck bestehender administrativer Strukturen und Ziele.
- Der niederländische SyRI-Skandal zeigt, dass Hauptprobleme (Zielgerichtung gegen arme Gegenden, fehlende Transparenz, Reproduktion von Ungleichheit) durch menschliche Entscheidungen bei Systemdesign und Deployment entstehen, nicht durch algorithmische Komplexität selbst.
- Wohlfahrtsüberwachung hat historische Wurzeln in moralischer Regulierung von Armen, Verdacht auf 'Untätigkeit' und der Annahme, dass Wohlfahrtsempfänger Privatsphäre opfern müssen. Diese Logiken werden durch neue Technologien verstärkt, nicht erfunden.

## Kategorie-Evidenz

### Evidenz 1

Der Autor kritisiert die Reifizierung von KI als neues Phänomen und fordert ein differenziertes technisches Verständnis: 'Understanding key features of machine learning is often less important than an algorithm's objective function' und argumentiert für kritische Reflexion über KI-Hype und tatsächliche technische Kapazitäten.

### Evidenz 2

Detaillierte Analyse von Machine Learning, Predictive Analytics, algorithmic decision-making (ADM) Systemen, und Chatbots in der Wohlfahrtsverwaltung. Fokus auf automatisierte Entscheidungsfindung und statistische Klassifikationssysteme.

### Evidenz 3

Direkter Bezug zu Wohlfahrtsverwaltung, Sozialleistungen, und administrative Agenturen, die über soziale Hilfe entscheiden. Relevanz für Sozialarbeiter als 'street-level bureaucrats' und deren Diskretionsverlust durch Systemautomation.

### Evidenz 4

Zentrale Analyse struktureller Ungleichheit: 'ML-based algorithms can statistically reproduce social inequalities in their training data' und 'disproportionate targeting of ethnic groups for fraud investigation' trotz Verbots ethnischer Diskriminierung. Fokus auf Reproduktion von Klassenverhältnissen und Marginalisierung.

### Evidenz 5

Analyse von Diskriminierungsmechanismen gegen migrantische, arme und ethnisierte Bevölkerungsgruppen: 'the choice to deploy these systems against populations that are predominantly poor, racialized, or of immigrant background is just as important for the reproduction of inequality'.

### Evidenz 6

Diskussion algorithmic fairness und auditability von ADM-Systemen; Analyse von Rotterdam's Algorithmus als 'alarmingly inaccurate' und Forderung nach systematischer Kontrolle und Transparenzanforderungen für Entscheidungssysteme.

## Assessment-Relevanz

**Domain Fit:** Hochgradig relevant für Schnittstelle KI/Soziale Arbeit durch kritische Analyse von Wohlfahrtsautomation und deren Auswirkungen auf marginalisierte Klientel sowie auf Sozialarbeiter als implementierende Akteure. Verbindet Governance-Forschung mit Surveillance Studies und Fragen sozialer Gerechtigkeit.

**Unique Contribution:** Der Beitrag dekonstruiert KI-Hype systematisch durch historische Kontextualisierung und zeigt auf, dass zentrale Probleme digitalisierter Wohlfahrt nicht technologisch neuartig sind, sondern lange bekannte Muster von Klassenkontrolle und systematischer Verdächtigung widerspiegeln.

**Limitations:** Fokus primär auf Niederlande und Kanada, begrenzte Analyse intersektionaler Dimensionen (Gender wird nicht behandelt), keine empirische Erhebung von Betroffenenperspektiven oder Sozialarbeiter-Erfahrungen.

**Target Group:** Sozialarbeiter und Soziale Dienste, KI-Governance und Policy-Maker, Surveillance Studies Fachleute, Menschenrechtsorganisationen, Sozialwissenschaftler, kritische KI-Forscher, Aktivisten gegen digitale Ausgrenzung marginalisierter Gruppen

## Schlüsselreferenzen

- [[Eubanks_Virginia_2018]] - Automating Inequality: How High-Tech Tools Profile, Police, and Punish the Poor
- [[Bovens_Zouridis_2002]] - Street-level bureaucracy vs. screen-level bureaucracy
- [[Alston_Philip_2019]] - UN Report: Digital welfare state definition
- [[van_Bekkum_Borgesius_2021]] - Digital Welfare Fraud Detection and the Dutch SyRI Judgment
- [[Brayne_Sarah_2020]] - Predictive policing and feedback loops targeting disadvantaged populations
- [[Alkhatib_Ali_2021]] - Algorithmic systems as functionally similar to administrative states
- [[Hoffmann_Anna_Lauren_2021]] - Data violence and administrative violence
- [[Constantaras_et_al_2023]] - Rotterdam fraud detection algorithm analysis
- [[LepageRicher_McKelvey_2022]] - States of Computing: Government as information processing system
- [[Coser_Lewis_A_1965]] - Privacy denial for welfare recipients
