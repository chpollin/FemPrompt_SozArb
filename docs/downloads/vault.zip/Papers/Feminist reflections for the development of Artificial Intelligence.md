---
title: Feminist reflections for the development of Artificial Intelligence
authors:
  - Unknown Author
year: 2023
type: report
doi: 
url: "https://www.derechosdigitales.org/fair-2023-en/"
tags:
  - paper
llm_decision: Include
llm_confidence: 0.92
llm_categories:
  - KI_Sonstige
  - Bias_Ungleichheit
  - Gender
  - Diversitaet
  - Feministisch
human_decision: Exclude
human_categories:
  - KI_Sonstige
  - Bias_Ungleichheit
  - Gender
  - Feministisch
  - Fairness
agreement: disagree
---

# Feminist reflections for the development of Artificial Intelligence

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** AI_Literacies, KI_Sonstige, Soziale_Arbeit, Bias_Ungleichheit, Gender, Diversitaet, Feministisch, Fairness
**Argumente:** 3 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 88 |
| Correctness | 92 |
| Category Validation | 88 |
| **Overall Confidence** | **89** |

### Stufe 4: Assessment

**LLM:** Include (Confidence: 0.92)
**Human:** Exclude

**Kategorie-Vergleich (bei Divergenz):**

| Kategorie | Human | LLM | Divergent |
|-----------|-------|-----|----------|
| AI_Literacies | Nein | Nein |  |
| Generative_KI | Nein | Nein |  |
| Prompting | Nein | Nein |  |
| KI_Sonstige | Ja | Ja |  |
| Soziale_Arbeit | Nein | Nein |  |
| Bias_Ungleichheit | Ja | Ja |  |
| Gender | Ja | Ja |  |
| Diversitaet | Nein | Ja | X |
| Feministisch | Ja | Ja |  |
| Fairness | Ja | Nein | X |

## Wissensdokument

# Towards a feminist framework for AI development: from principles to practice

## Kernbefund

Feministische KI-Entwicklung erfordert nicht nur technische Lösungen, sondern eine Transformation von Praktiken in Design, Produktion, Deployment und Governance unter Berücksichtigung lokaler Kontexte, Care-Arbeit und intersektionaler Machtdynamiken in Lateinamerika.

## Forschungsfrage

Ist es möglich, KI-Systeme zu entwickeln, die keine Logiken der Unterdrückung reproduzieren, und wie können feministische Praktiken in der KI-Entwicklung in Lateinamerika integriert werden?

## Methodik

Mixed Methods: Nicht-erschöpfende Literaturanalyse von Audit-Frameworks und Fairness-Assessments; systematische Analyse von sechs Statements zu feministischen Prinzipien für digitale Technologien; qualitative Interviews mit sieben Frauen in KI/Data Science in Lateinamerika; interpretative Analyse von Erfahrungen vor dem Hintergrund feministischer und Social-Justice-Perspektiven
**Datenbasis:** n=7 qualitative Interviews mit Frauen in KI/Data Science aus Lateinamerika; systematische Analyse von 6 feministischen Prinzipien-Statements; Review von 3 feministischen Praxis-Guides aus Lateinamerika

## Hauptargumente

- KI-Systeme werden von einer homogenen Gruppe (überwiegend weiße Männer in den USA) entwickelt, deren Perspektive als neutral und objektiv dargestellt wird, aber tatsächlich Unterdrückungslogiken reproduziert. Die Hegemonie von Silicon-Valley-Modellen in Lateinamerika ist nicht nur eine Frage der Unterinvestition, sondern der strukturellen Reproduktion kolonialer Machtverhältnisse.
- Feministische KI-Entwicklung muss die Materialität und Sichtbarmachung von Care-Arbeit, Infrastruktur und deren Kontrolle thematisieren. Dies umfasst sowohl digitale Infrastruktur als auch die oft feminisierte, prekäre und unsichtbar gemachte Arbeit in der Produktion und Wartung von KI-Systemen.
- Alternative Ansätze wie Tequiologie (kolaborative, auf gegenseitiger Unterstützung basierende Technologieentwicklung) und Designjustice ermöglichen kontextgebundene, gemeinschaftsorientierte KI-Entwicklung, die nicht auf Marktlogiken und Effizienz reduziert ist, sondern auf lokale Bedürfnisse und Autonomie ausgerichtet ist.

## Kategorie-Evidenz

### Evidenz 1

Fokus auf Wissenstransfer, kritische Reflexion und Kompetenzerwerb in KI-Entwicklung: 'recognizing and making visible the multiple and diverse forms of the technical reconfigures our perception of who is part of a technology'

### Evidenz 2

Thematisierung von Natural Language Processing, Computer Vision, Robotics, algorithmischen Entscheidungssystemen, Machine Learning und Bias in Datenbanken und Audit-Frameworks.

### Evidenz 3

Fokus auf Soziale Dienste und technologische Interventionen in Kontexten von Gewalt gegen Frauen, Care-Arbeit und Gemeinschaftsorganisierung. Beispiel: 'app to tackle violence against women' und Analyse feministischer kollektiver Praxis.

### Evidenz 4

Zentrale Thematisierung von Bias in Datenbanken, strukturellen Ungleichheiten in Latinamerika (indigene Sprachen, Geschlechter-Digital-Divide, Arbeitsbedingungen in Elektronik-Fabriken): 'if you are born speaking an indigenous language your chances are going to be very different'

### Evidenz 5

Expliziter Fokus auf Geschlechterperspektive: Frauen im Tech/AI-Bereich, Geschlechter-Bias in Datensätzen, Gender-basierte Gewalt als Anwendungsfall, Unterrepräsentation von Frauen in datengetriebenen Rollen.

### Evidenz 6

Intersektionale Analyse mit Fokus auf marginalisierte Gruppen: indigene Bevölkerung, Frauen, nicht-binäre Personen, Arbeiter:innen, Geflüchtete. 'It is essential that we listen to and learn from the embodied experiences of datafication...in the lives of women and girls, indigenous communities, immigrants, refugees, platform workers, non-binary people, and rural communities'

### Evidenz 7

Explizite Verwendung feministischer Theorie (Haraway, D'Ignazio & Klein, hooks implizit durch Critical Race Theory, Crenshaw-Konzepte durch Intersektionalität): 'a feminist perspective', Referenz zu 'Feminist Principles of the Internet', 'Data Feminism', Manifesto for hackfeminist algorithms, Design Justice, Decolonial Feminism.

### Evidenz 8

Thematisierung von Fairness in Algorithmen, Audit-Frameworks, Bias-Mitigation, algorithmischer Gerechtigkeit und Impact-Assessment: 'algorithmic or datasets biases', 'Equalized Odds, Demographic Parity', auditability und reusability von Daten.

## Assessment-Relevanz

**Domain Fit:** Hochgradig relevant für die Schnittstelle KI/Soziale Arbeit/Gender. Das Paper adressiert direkt die Entwicklung von KI-Systemen, die keine Unterdrückungslogiken reproduzieren, mit explizitem Fokus auf Lateinamerika, feministische Methodik und Anwendungen im Sozialbereich (Gewalt gegen Frauen, Gemeinschaftsorganisierung, Care-Infrastrukturen).

**Unique Contribution:** Das Paper leistet einen originären Beitrag durch die Kombination von feministischer Theorie mit praktischen, lokalisierten Interviews von Frauen in KI/Data Science in Lateinamerika und entwickelt einen kontextgebundenen Handlungsleitfaden für feministische KI-Entwicklung, der über anglo-amerikanische Diskurse hinausgeht.

**Limitations:** Die Studie ist begrenzt auf n=7 Interviews und hat keine Evaluationsindikatoren für die konkrete Wirksamkeit der vorgeschlagenen Praktiken; die Systematisierung bleibt explorativer Art; der Leitfaden ist noch in Entwicklung und wenig operationalisiert.

**Target Group:** KI-Entwickler:innen und Informatiker:innen mit Interesse an sozialer Transformation; Sozialarbeiter:innen und Social-Change-Organisationen, die KI-Systeme einsetzen oder hinterfragen möchten; feministische Tech-Kollektive und digitale Aktivist:innen in Lateinamerika; Policymaker:innen und Ethiker:innen im Bereich digitale Gerechtigkeit; Akademiker:innen in KI Ethics, Gender Studies und Digital Humanities.

## Schlüsselreferenzen

- [[DIgnazio_Catherine_Klein_Lauren_F_2020]] - Data Feminism
- [[Benjamin_Ruha_2019]] - Race after Technology. Abolitionist tools for the New Jim Code
- [[Noble_Safiya_Umoja_2016]] - Traversing Technologies. A Future for Intersectional Black Feminist Technology Studies
- [[Peña_Paz_Varón_Joana_2021]] - Oppressive A.I.: Feminist Categories to Understand its Political Effects
- [[Velasco_Patricio_Venturini_Jamila_2021]] - Automated decision-making in public administration in Latin America
- [[Aguilar_Gil_Yásnaya_Elena_2020]] - A modest proposal to save the world
- [[Design_Justice_Network_2020]] - Design Justice Network Principles
- [[Ricaurte_Paola_2022]] - Artificial Intelligence and the Feminist Decolonial Imagination
- [[Wajcman_Judy_2006]] - Technofeminism
- [[Toupin_Sophie_Spideralex_2018]] - Radical Feminist Storytelling and Speculative Fiction: Creating new worlds by re-imagining hacking
