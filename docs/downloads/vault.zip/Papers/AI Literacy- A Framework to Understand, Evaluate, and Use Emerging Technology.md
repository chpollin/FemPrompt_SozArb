---
title: "AI Literacy: A Framework to Understand, Evaluate, and Use Emerging Technology"
authors:
  - Pati Ruiz
  - Kelly Mills
  - Keun-woo Lee
  - Merijke Coenraad
  - Judi Fusco
  - Jeremy Roschelle
  - Josh Weisgrau
year: 2024
type: report
doi: 
url: "https://hdl.handle.net/20.500.12265/218"
tags:
  - paper
llm_decision: Exclude
llm_confidence: 0.95
llm_categories:
  - AI_Literacies
human_decision: Include
human_categories:
  - AI_Literacies
  - Generative_KI
  - Prompting
  - KI_Sonstige
  - Bias_Ungleichheit
  - Gender
agreement: disagree
---

# AI Literacy: A Framework to Understand, Evaluate, and Use Emerging Technology

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** AI_Literacies, Generative_KI, Prompting, KI_Sonstige, Bias_Ungleichheit, Diversitaet, Fairness
**Argumente:** 5 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 92 |
| Correctness | 98 |
| Category Validation | 95 |
| **Overall Confidence** | **92** |

### Stufe 4: Assessment

**LLM:** Exclude (Confidence: 0.95)
**Human:** Include

**Kategorie-Vergleich (bei Divergenz):**

| Kategorie | Human | LLM | Divergent |
|-----------|-------|-----|----------|
| AI_Literacies | Ja | Ja |  |
| Generative_KI | Ja | Nein | X |
| Prompting | Ja | Nein | X |
| KI_Sonstige | Ja | Nein | X |
| Soziale_Arbeit | Nein | Nein |  |
| Bias_Ungleichheit | Ja | Nein | X |
| Gender | Ja | Nein | X |
| Diversitaet | Nein | Nein |  |
| Feministisch | Nein | Nein |  |
| Fairness | Nein | Nein |  |

## Wissensdokument

# AI Literacy: A Framework to Understand, Evaluate, and Use Emerging Technology

## Kernbefund

Ein integriertes AI Literacy Framework mit drei Modes of Engagement (Understand, Evaluate, Use), sechs AI Literacy Practices und zwei Core Values (Human Judgment, Centering Justice), das Schulleitern bei der Gestaltung von KI-Kompetenzvermittlung hilft und Risiken wie Bias, Datenschutz und Desinformation adressiert.

## Forschungsfrage

Welche Kompetenzen und Praktiken benötigen Lernende, Lehrende und Gemeinschaften, um KI-Systeme sicher und effektiv zu verstehen, zu bewerten und zu nutzen?

## Methodik

Theoretisch-konzeptionell: Synthese von Forschungsliteratur zu AI Literacy, Media Literacy, Computational Thinking und Tech Justice mit Stakeholder-Feedback von Experten und Praktikern aus K-12 Education; keine empirische Datenerhebung
**Datenbasis:** Keine empirische Datenerhebung; Framework basiert auf Literaturanalyse und Expert:innenfeedback von über 50 Reviewer:innen aus Schulen, Forschungsinstitutionen und Non-Profits

## Hauptargumente

- KI-Literalität ist essential für alle Beteiligten in Bildungssettings, um die Risiken von KI-Systemen (Bias, Datenverletzungen, Desinformation) zu mitigieren und informierte Entscheidungen über deren Nutzung zu treffen.
- Understanding und Evaluating von KI müssen dem Using vorausgehen und durchgehend implementiert werden; alle drei Modes sind interdependent und unterstützen sich gegenseitig.
- AI Literacy Practices (Algorithmic Thinking, Data Analysis, Data Privacy, Digital Communication, Ethics & Impact, Information Literacy) können konkret auf drei Types of Use (Interacting, Creating, Problem-Solving) angewendet werden, wobei jeder Typ spezifische Risiken und Anforderungen hat.
- Systemic bias in Trainingsdaten und die Perpetuierung historischer Ungleichheiten durch Algorithmen sind zentrale Herausforderungen, besonders bei generativen KI-Systemen, die ohne Oversight für vulnerable Populationen schädliche Outputs generieren können.
- Five Leadership Strategies (Adoption Guidance, Cross-Grade Integration, Professional Learning, Powerful Learning Experiences, Awareness & Agency) sind notwendig, um KI-Literalität strukturell in K-12 Education zu verankern und Equity zu fördern.

## Kategorie-Evidenz

### Evidenz 1

AI literacy is defined as 'the knowledge and skills that enable people to critically understand, evaluate, and use AI systems and tools to safely and effectively participate in an increasingly digital world.' Framework explicitly provides six AI Literacy Practices as 'actionable skills that learners can demonstrate.'

### Evidenz 2

Extensive discussion of generative AI platforms: 'Generative AI platforms such as ChatGPT, Claude, Gemini, and other LLMs can generate text responses to prompts and platforms such as DALL-E can generate images.' Detailed section on 'Creating with AI' addresses GenAI prompting skills and risks including bias and hallucinations.

### Evidenz 3

Section on 'Creating with AI' states: 'The skill of GenAI prompting involves creating good questions or commands that get the system to produce something that humans consider to be a quality output. While prompting itself is a skill, it requires an understanding of the desired outputs and of how to verify and validate that those outputs are accurate.'

### Evidenz 4

Framework addresses algorithmic systems generally, including adaptive technology, recommendation algorithms, and traditional ML for problem-solving: 'Interacting with AI involves engaging with adaptive technology in multiple modalities that adjusts to data collected.'

### Evidenz 5

Paper cites foundational works on algorithmic bias (Benjamin 2019, Broussard 2023, Buolamwini 2023, Noble 2018). States: 'the well-documented examples of AI tools perpetuating and reproducing systemic bias' and 'algorithms take on the biases that are already represented in the data and all data includes human biases.' Highlights that 'most of the training data available to AI systems comes from public interfaces on the internet, which is overrepresented as white and male.'

### Evidenz 6

Framework emphasizes 'human justice perspective' and references 'responsible AI and tech justice.' Strategy 5 explicitly promotes 'Awareness and Agency' for marginalized populations: 'raising awareness about algorithmic bias and advocating for changes in policies around algorithms and automation in our society.' Mentions vulnerable populations and the need for equity in AI literacy access.

### Evidenz 7

Core Values emphasize 'Centering Justice' in AI applications. Paper discusses need to 'mitigate the harmful effects of algorithms' and examines how AI systems can 'perpetuate and exacerbate existing inequities.' Recommends evaluation of algorithmic fairness through questions about bias in training data and impacts on different populations.

## Assessment-Relevanz

**Domain Fit:** Das Paper ist hochrelevant für KI-Bildung und Kompetenzentwicklung, adressiert Bias und Gerechtigkeit als zentrale Themen, hat aber keinen direkten Bezug zu Sozialer Arbeit. Die Erkenntnisse sind für sozialarbeiterische Lehre und Praxis zur KI-Vermittlung jedoch adaptierbar.

**Unique Contribution:** Das Paper leistet einen umfassenden, praktisch anwendbaren Framework für KI-Literalität in K-12 Settings, der erstmals explizit Justice und Human Judgment als Core Values verankert und konkrete Literacy Practices mit spezifischen Use-Cases (Interact, Create, Problem-Solve) verbindet.

**Limitations:** Die Studie ist rein konzeptionell-literaturbasiert ohne empirische Validierung des Frameworks; keine Daten zur Effektivität der vorgeschlagenen Strategien; Fokus liegt auf K-12 Education, Übertragbarkeit auf andere Kontexte (z.B. Higher Education, Soziale Arbeit, berufliche Kontexte) ist begrenzt.

**Target Group:** K-12 Schulleitern, Lehrkräfte, Curriculum-Entwickler:innen, Bildungsforschern und Policymaker; sekundär relevant für Medienpädagog:innen, Informatik-Lehrkräfte und Bildungsberater:innen. Für Sozialarbeiter:innen mit Bezug zu Kinder- und Jugendarbeit potentiell wertvoll.

## Schlüsselreferenzen

- [[Benjamin_2019]] - Race after Technology: Abolitionist Tools for the New Jim Code
- [[Broussard_2023]] - More than a Glitch: Confronting Race, Gender, and Ability Bias in Tech
- [[Buolamwini_2023]] - Unmasking AI: My Mission to Protect What is Human in a World of Machines
- [[Noble_2018]] - Algorithms of Oppression: How Search Engines Reinforce Racism
- [[ONeil_2016]] - Weapons of Math Destruction: How Big Data Increases Inequality and Threatens Democracy
- [[Druga_et_al_2021]] - The 4As: Ask, Adapt, Author, Analyze - AI Literacy Framework for Families
- [[White_Scott_2024]] - Responsible AI and Tech Justice: A Guide for K-12 Education
- [[Lee_Long_in press]] - AI Literacy: Definitions and Directions for an Essential New Digital Literacy
- [[EdSAFE_AI_Alliance_2024]] - SAFE Benchmarks Framework
- [[Ng_et_al_2021]] - Conceptualizing AI Literacy: An Exploratory Review
