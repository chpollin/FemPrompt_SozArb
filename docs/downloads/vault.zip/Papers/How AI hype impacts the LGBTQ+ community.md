---
title: How AI hype impacts the LGBTQ+ community
authors:
  - A. Kumar
  - M. Gartner
year: 2024
type: journalArticle
doi: 10.1007/s43681-024-00423-8
url: "https://doi.org/10.1007/s43681-024-00423-8"
tags:
  - paper
llm_decision: Include
llm_confidence: 0.92
llm_categories:
  - KI_Sonstige
  - Bias_Ungleichheit
  - Gender
  - Diversitaet
  - Feministisch
  - Fairness
human_decision: Exclude
human_categories:
  - KI_Sonstige
  - Bias_Ungleichheit
  - Gender
  - Feministisch
  - Fairness
agreement: disagree
---

# How AI hype impacts the LGBTQ+ community

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** AI_Literacies, Generative_KI, KI_Sonstige, Bias_Ungleichheit, Gender, Diversitaet, Feministisch, Fairness
**Argumente:** 3 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 92 |
| Correctness | 98 |
| Category Validation | 96 |
| **Overall Confidence** | **95** |

### Stufe 4: Assessment

**LLM:** Include (Confidence: 0.92)
**Human:** Exclude

**Kategorie-Vergleich (bei Divergenz):**

| Kategorie | Human | LLM | Divergent |
|-----------|-------|-----|----------|
| AI_Literacies | Nein | Nein |  |
| Generative_KI | Nein | Nein |  |
| Prompting | Nein | Nein |  |
| KI_Sonstige | Ja | Ja |  |
| Soziale_Arbeit | Nein | Nein |  |
| Bias_Ungleichheit | Ja | Ja |  |
| Gender | Ja | Ja |  |
| Diversitaet | Nein | Ja | X |
| Feministisch | Ja | Ja |  |
| Fairness | Ja | Ja |  |

## Wissensdokument

# How AI hype impacts the LGBTQ+ community

## Kernbefund

AI-Hype verschleiert reale Probleme von Bias, Schaden und Ausbeutung, die marginalisierte Communities am stärksten treffen, während er eine Cishet-Baseline und heteronormative Strukturen in AI-Systemen verfestigt.

## Forschungsfrage

Wie beeinflussen AI-Hype und Marketing-getriebene frühe Adoption von AI-Technologien die LGBTQ+-Community, und welche Auswirkungen hat dies auf marginalisierte Gruppen?

## Methodik

Theoretisch / Literaturanalyse: Queer Theory, Critical Theory, Foucauldian Power Analysis

## Hauptargumente

- AI-Hype perpetuiert schädliche Stereotype und Diskriminierung gegen marginalisierte Communities, insbesondere die LGBTQ+-Community, durch Übertreibung von AI-Fähigkeiten und Verheimlichung von Bias und Limitation.
- Die Cishet-Baseline (Heteronormativität und Cisnormativität) ist strukturell in AI-Systemen verankert und wird durch Marketing-Hype unsichtbar gemacht, was zu systematischer Ausgrenzung von queer und trans Personen führt.
- Policy-Maker verstehen AI-Fähigkeiten hauptsächlich durch Clickbait-Medienberichterstattung statt durch wissenschaftliche Literatur, was zu fehlgeleiteten Implementierungen führt, die marginalisierte Communities disproprtional schädigen.

## Kategorie-Evidenz

### Evidenz 1

Paper analysiert, wie Hype und fehlerhafte Verständigung von AI-Capabilities bei Policy-Makern zu kritischer Literacies-Lücke führt: 'policymakers don't read the scientific literature but they do read the clickbait'

### Evidenz 2

Explizite Behandlung von generativen AI-Systemen und deren Missgendering-Praktiken: 'misgendering by generative AI systems'

### Evidenz 3

Umfassende Analyse von algorithmic bias, dating algorithms, facial recognition, healthcare AI systems, content moderation algorithms und algorithmic decision-making

### Evidenz 4

Zentrale These: 'exaggerating the capabilities of AI systems...downplaying their potential biases' führt zu 'reinforcement of stereotypes and biases' und harms für marginalisierte Gruppen

### Evidenz 5

Expliziter Gender-Fokus: 'potential to unintentionally reinforce stereotypes around gender' und 'cisgender heteronormative (cishet) baseline'

### Evidenz 6

Intersektionale Analyse: 'Intersectionality of different marginalising factors is also a key contributor of further marginalisation' und Fokus auf LGBTQ+ als marginalisierte Community

### Evidenz 7

Verwendet explizit queer theory (de Lauretis, Foucault) und feministische theoretische Perspektiven: 'queer and feminist theoretical perspectives can offer valuable insights' sowie Referenzen auf intersektionale und anti-oppressive Frameworks

## Assessment-Relevanz

**Domain Fit:** Hochgradig relevant für die Schnittstelle AI/Soziale Arbeit/Gender: Das Paper untersucht, wie AI-Hype marginalisierte Communities, insbesondere LGBTQ+-Personen, schadet und dabei strukturelle Ungleichheiten verschärft. Dies hat direkten Bezug zu sozialarbeiterischen Belangen von Vulnerable Populations und Gender-Gerechtigkeit.

**Unique Contribution:** Erste umfassende theoretische Analyse der Verbindung zwischen AI-Hype als Marketing-Phänomen und spezifischen Schadenserfahrungen der LGBTQ+-Community durch queer-theoretische und feminist-kritische Lenses.

**Limitations:** Das Paper ist theoretisch-konzeptionell angelegt ohne empirische Datenerhebung (Interviews, Surveys, Case Studies); eine empirische Validierung der Hype-Auswirkungen auf konkrete LGBTQ+-Erfahrungen würde die Argumente stärken.

**Target Group:** AI-Ethiker:innen, Queer Theorist:innen, Policy-Maker, LGBTQ+-Advocate:innen, Sozialarbeiter:innen im Queer-Support, KI-Entwickler:innen mit Interesse an Fairness und Inklusion, Aktivist:innen marginalisierter Communities

## Schlüsselreferenzen

- [[Lipton_Z_2018]] - Policymakers and scientific literature vs. clickbait
- [[de_Lauretis_T_1991]] - Queer theory founding
- [[Foucault_M_None]] - Power dynamics, knowledge-power interplay, history of sexuality
- [[Park_R_None]] - Chicago School of Sociology - marginality concept
- [[Scheuerman_MK_Paul_J_Brubaker_JR_2019]] - How computers see gender
- [[Tomasev_N_McKee_KR_Kay_J_Mohamed_S_2021]] - Fairness for Unobserved Characteristics - Queer Communities
- [[Ovalle_A_Liang_D_Boyd_A_2023]] - Mobile Biometrics and Technopolicy for Queer Communities
- [[Drage_E_Mackereth_K_2022]] - Does AI Debias Recruitment? Race, Gender, and AI's Eradication of Difference
- [[Ballatore_A_Natale_S_2023]] - Technological failures and the myth of AI
- [[Haimson_OL_et_al_2021]] - Disproportionate removals and content moderation for marginalized users
