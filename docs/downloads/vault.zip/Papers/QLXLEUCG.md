---
title: Der Einfluss der Algorithmen: Neue Qualitäten durch Big Data Analytics und Künstliche Intelligenz
authors:
  - D. Schneider
  - U. Seelmeyer
year: 2018
type: journalArticle
doi: 10.1007/s12054-018-0046-y
tags:
  - paper
  - feminist-ai
  - bias-research
date_added: 2026-02-22
date_modified: 2026-02-22
---

# Der Einfluss der Algorithmen: Neue Qualitäten durch Big Data Analytics und Künstliche Intelligenz

## Abstract

Examines how algorithmic decision-making affects professional judgment formation and discretionary decision-making space for practitioners. Analyzes automation bias where professionals may over-rely on algorithmic recommendations without adequate critical evaluation. Stresses social work requires debate about what forms of knowledge new technologies can generate, where limits lie, and how it can meaningfully be incorporated into professional reflection and decision-making practices.

## Key Concepts

## Full Text

---
title: "Der Einfluss der Algorithmen: Neue Qualitäten durch Big Data Analytics und Künstliche Intelligenz"
authors: ["Diana Schneider", "Udo Seelmeyer"]
year: 2018
type: journalArticle
language: de
processed: 2026-02-05
source_file: Schneider_2018_Der_Einfluss_der_Algorithmen_Neue_Qualitäten.md
confidence: 94
---

# Der Einfluss der Algorithmen: Neue Qualitäten durch Big Data Analytics und Künstliche Intelligenz

## Kernbefund

Big Data und KI verkleinern die von Rolf beschriebene 'vorläufige Formalisierungslücke' erheblich, führen aber zu neuen Herausforderungen hinsichtlich vermeintlicher Objektivität, Bias-Reproduktion und Ermessensspielraum-Einschränkung. Neue Anforderungen an Fachlichkeit entstehen durch erforderliche 'data literacy' und konsistenten Persönlichkeitsschutz.

## Forschungsfrage

Welche Veränderungen und Herausforderungen bringt der Einsatz von Big Data und Künstlicher Intelligenz in der Sozialen Arbeit mit sich und welche neuen Anforderungen ergeben sich daraus für die Professionalität von Fachkräften?

## Methodik

Theoretisch-konzeptionell; kombiniert Technikphilosophie (Formalisierungstheorie) mit fallstudienartiger Analyse (CFRA-Tool); konzeptionelle Literaturanalyse
**Datenbasis:** nicht empirisch; konzeptionelle Analyse mit Referenzen auf internationale Fallbeispiele (insbesondere CFRA in USA)

## Hauptargumente

- Software-Einsatz in der Sozialen Arbeit folgt einem dreischrittigen Formalisierungsprozess (Semiotisierung, Formalisierung, Algorithmisierung), wobei soziale Realität nur begrenzt als Code abbildbar ist; es existieren notwendige und vorläufige Formalisierungslücken.
- Künstliche Intelligenz und maschinelles Lernen mittels neuronaler Netze ermöglichen die Verarbeitung unstrukturierter Daten und schließen die vorläufige Formalisierungslücke rasant, schaffen aber neue Risiken durch versteckte Bias, subjektive Datenextraktion und fehlende Transparenz der Entscheidungskriterien.
- Algorithmen in der Sozialen Arbeit (z.B. CFRA für Kindeswohlgefährdung) können zu De-Professionalisierung, Ermessensspielraum-Verengung und fehlerhafter Gleichsetzung von Prognosekompetenz mit Interventionsentscheidung führen; dabei werden Lösungsansätze und Ursachenstrukturen ignoriert.
- Formalisierung wird fälschlicherweise mit Objektivierung gleichgesetzt, obwohl Vorurteile in unstrukturierten Daten sowie durch Forscher:innen und Entwickler:innen in der Datenaufbereitung entstehen und durch selbstlernende Systeme verstärkt werden.

## Kategorie-Evidenz

### Evidenz 1

Zentrale Forderung: 'Sowohl data literacy als kompetenter Umgang mit komplexen Datenquellen und anspruchsvollen Verfahren zu deren Verarbeitung als auch ein konsequenter Persönlichkeitsschutz bilden neue Anforderungen an die Professionalität von Fachkräften.'

### Evidenz 2

Ausführliche Behandlung von maschinellem Lernen, neuronalen Netzen, Big Data Analytics, Mustererkennung und algorithmischen Entscheidungssystemen: 'Das Neue an Technologien wie Big Data Analytics, maschinellem Lernen und Künstlicher Intelligenz (KI) besteht darin, dass nicht nur strukturierte Daten, sondern auch unstrukturierte Daten wie (Frei-) Texte, Audio- und Videodaten maschinell verarbeitet werden können.'

### Evidenz 3

Direkter Fokus auf Soziale Arbeit als Anwendungsfeld: 'Digitalisierung prägt zunehmend auch Arbeitsvollzüge und Entscheidungsprozesse in der Sozialen Arbeit.' Fallbeispiele aus Jugendhilfe (CFRA, Kindeswohlgefährdung). Autoren arbeiten an FH Bielefeld, Fachbereich Sozialwesen.

### Evidenz 4

Kritische Analyse von Bias-Reproduktion: 'Da ein Algorithmus die in ihm enthaltenden Daten nur kristallisieren und verschärfen kann, besteht stets die Gefahr, hier Vorurteile zu reproduzieren bzw. zu verstärken.' Stigmatisierungspotenzial durch Milieu-basierte Durchschnittsprognosen.

### Evidenz 5

Implizite Adressierung durch Fokus auf Ermessensspielraum-Einschränkung und Standardisierung, die ganzheitliche Betrachtung von Individuen erschwert: 'wird doch nicht das hinter den Ergebnissen der Datenanalyse stehende Individuum betrachtet, sondern lediglich die Häufigkeitsverteilung innerhalb seines Milieus'.

### Evidenz 6

Expliziter Fokus auf algorithmische Fairness und faire Entscheidungsfindung: 'Gleichsam wird deutlich, dass ein gelingender Umgang mit den genannten Herausforderungen allein damit noch nicht gewährleistet ist.' Kritik an vermeintlicher Objektivität und fehlerhaften Korrelationen; Forderung nach Systemen, die Entscheidungen unterstützen statt ersetzen.

## Assessment-Relevanz

**Domain Fit:** Hochgradig relevant für die Schnittstelle KI und Soziale Arbeit. Das Paper adressiert zentral die Frage, wie algorithmische Systeme und KI die Professionalisierung, Ethik und Handlungsfähigkeit in Sozialen Diensten verändern, besonders im Kontext von Entscheidungsfindung und Bias.

**Unique Contribution:** Systematische Analyse der Formalisierungsprozesse, die KI in der Sozialen Arbeit ermöglichen, verbunden mit kritischer Reflexion der damit verbundenen Herausforderungen (Bias, Objektivierungsmythos, De-Professionalisierung) und konkreten Regulierungsempfehlungen.

**Limitations:** Keine empirische Erhebung; konzeptionelle Analyse basiert auf Literatur und einem internationalen Fallbeispiel (CFRA); Geschlechterperspektive und intersektionale Dimensionen nicht explizit thematisiert; zukünftige Entwicklung von KI schwer vorhersehbar.

**Target Group:** Sozialarbeiter:innen und Fachkräfte in Sozialen Diensten, KI-Entwickler:innen und Softwareanbieter für Sozialbereich, Policymaker und Regulierungsinstitutionen, Hochschullehrende in Sozialer Arbeit, Forscher:innen an der Schnittstelle von KI und Soziale Arbeit, Interessierte an Algorithmenethik und digitaler Gerechtigkeit

## Schlüsselreferenzen

- [[Rolf_2008]] - Formalisierungslücken und Software-Transformation sozialer Wirklichkeit
- [[HøybyeMortensen_2015]] - Standardisierung und Ermessensspielraum
- [[Schrödter_et_al_2018]] - Prognosekompetenz vs. Interventionsentscheidung bei Risikoeinschätzung
- [[Gillingham_Graham_2016]] - Subjektive Einfärbung durch Datenextraktion und -aufbereitung
- [[Datta_et_al_2015]] - Bias-Reproduktion durch Algorithmen
- [[Ley_Seelmeyer_2004]] - Software-Einfluss auf Ermächtigung und De-Professionalisierung
- [[Finck_Janneck_2008]] - Technologien als soziotechnische Systeme
