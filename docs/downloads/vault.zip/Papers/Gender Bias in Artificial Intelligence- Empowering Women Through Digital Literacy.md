---
title: "Gender Bias in Artificial Intelligence: Empowering Women Through Digital Literacy"
authors:
  - S. S. Shah
year: 2025
type: journalArticle
doi: 10.70389/PJAI.1000088
url: 
tags:
  - paper
llm_decision: Include
llm_confidence: 0.95
llm_categories:
  - AI_Literacies
  - KI_Sonstige
  - Bias_Ungleichheit
  - Gender
  - Diversitaet
  - Fairness
human_decision: Exclude
human_categories: []
agreement: disagree
---

# Gender Bias in Artificial Intelligence: Empowering Women Through Digital Literacy

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** AI_Literacies, KI_Sonstige, Bias_Ungleichheit, Gender, Diversitaet, Fairness
**Argumente:** 3 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 88 |
| Correctness | 92 |
| Category Validation | 85 |
| **Overall Confidence** | **88** |

### Stufe 4: Assessment

**LLM:** Include (Confidence: 0.95)
**Human:** Exclude

**Kategorie-Vergleich (bei Divergenz):**

| Kategorie | Human | LLM | Divergent |
|-----------|-------|-----|----------|
| AI_Literacies | Nein | Ja | X |
| Generative_KI | Nein | Nein |  |
| Prompting | Nein | Nein |  |
| KI_Sonstige | Nein | Ja | X |
| Soziale_Arbeit | Nein | Nein |  |
| Bias_Ungleichheit | Nein | Ja | X |
| Gender | Nein | Ja | X |
| Diversitaet | Nein | Ja | X |
| Feministisch | Nein | Nein |  |
| Fairness | Nein | Ja | X |

## Wissensdokument

# Gender Bias in Artificial Intelligence: Empowering Women Through Digital Literacy

## Kernbefund

Digitale Literaturprogramme sind ein vielversprechendes Instrument zur Bekämpfung von Geschlechtsbias in KI, indem sie kritisches Denken fördern, Frauen zum Verfolgen von KI-Karrieren ermutigen und frauengeführte KI-Projekte katalysieren. Systemische Veränderungen in KI-Entwicklung, Design und Bildungspolitik sind jedoch notwendig.

## Forschungsfrage

Wie manifestieren sich Geschlechtsbias in KI-Systemen und inwiefern können digitale Literaturinitiativen Frauen befähigen, kritisch mit KI-Technologien umzugehen und Geschlechtsungleichheiten in diesem Bereich abzubauen?

## Methodik

Theoretisch: Narrative Review von Fachliteratur aus 2010-2024; systematische Literatursuche in Web of Science, Scopus, IEEE Xplore, Google Scholar, ACM Digital Library; thematische Analyse nach Braun und Clarke; Schneeballmethode für Referenzen
**Datenbasis:** Narrative Review: 107 ausgewählte Quellen aus initialen 300 gefundenen Quellen; keine primären empirischen Daten; Analysefokus auf Peer-reviewed Artikel, Reports und Case Studies

## Hauptargumente

- Geschlechtsbias in KI ist systemisch und entsteht durch: Unterrepräsentation von Frauen in Entwicklungsteams, verzerrte Trainingsdaten und algorithmische Design-Entscheidungen, die Geschlechterstereotypen verstärken.
- Geschlechtsbias in KI wirkt sich kaskadierend auf Frauenkarrieren aus: Mangel an Rollenvorbildern, Stereotype-Threat, unhöfliche Arbeitskultur und hohe Abgangsquoten führen zu fortgesetzter Unterrepräsentation.
- Digitale Literaturprogramme (z.B. AI4ALL mit 78% STEM-Fortsetzungsquote und 91% erhöhtem KI-Interesse) befähigen Frauen durch kritisches Denken, verbesserte Karrierechancen und brechen Exklusionszyklen auf.

## Kategorie-Evidenz

### Evidenz 1

Digital literacy includes not only knowing how to use technology but also how to think about, criticise, and deal with digital technologies, like AI systems. [...] Digital literacy programs are important because they teach women how to think critically, which helps them find bugs in AI systems and fix them.

### Evidenz 2

Gender bias in AI is well-documented, manifesting in various ways, including biased algorithms, the under-representation of women in AI development teams [...] AI-based hiring tools are less helpful for women and voice recognition systems often do not work well with female sounds.

### Evidenz 3

The findings reveal systemic gender biases embedded in AI applications across diverse domains, such as recruitment, healthcare, and financial services. [...] AI systems can reinforce gender stereotypes and biases without trying to if the people who work on them are not diverse.

### Evidenz 4

Only 22% of AI workers around the world are women. [...] Gender bias in AI goes beyond the number of women working in the field and includes the data and algorithms that support these technologies. [...] AI-assisted performance review systems were 23% less likely to suggest women for senior positions than reviews done by humans only.

### Evidenz 5

More diverse development teams using inclusive AI design methods have been shown to reduce gender bias. [...] Putting gender-sensitive STEM education at the top of policy lists has a big impact on the number of women working in AI.

### Evidenz 6

AI not only mirrors but also potentially exacerbates existing social problems, such as gender bias, when observed in the actual world. [...] The study highlights the importance of inclusive AI design, gender-responsive education policies, and sustained research efforts to mitigate bias and promote equity.

## Assessment-Relevanz

**Domain Fit:** Das Paper ist hochgradig relevant für die Schnittstelle von KI, Digitale Literatur und Gender, adressiert aber Soziale Arbeit nicht explizit. Es bietet wertvollen Überblick über strukturelle Geschlechterbias in KI-Systemen und Lösungsansätze durch Bildung, relevant für sozialpolitische Interventionen.

**Unique Contribution:** Systematische Synthese der Verschränkung von Geschlechterbias in KI mit digitalen Literaturinitiativen als Empowerment-Tool, mit globalem Fokus auf unterschiedliche Kontexte (HICs vs. LMICs).

**Limitations:** Narrative Review ohne primäre empirische Datenerhebung; Fokus auf englischsprachige Literatur; begrenzte Diskussion intersektionaler Perspektiven trotz Erwähnung; keine Implementierungs- oder Skalierungsempfehlungen für LMICs.

**Target Group:** AI-Entwickler, Policymaker in Tech und Bildung, Frauen in Tech-Karrieren, Gender-Forscher, digitale Literatur-Pädagogen, Organisationen zur Förderung von Frauen in STEM, internationale Entwicklungsorganisationen

## Schlüsselreferenzen

- [[Priyadarshini_Priyadarshini_2024]] - Gender disparity in artificial intelligence: creating awareness of unconscious bias
- [[Andrews_Bucher_2022]] - Automating discrimination: AI hiring practices and gender inequality
- [[Hussien_et_al_2024]] - Unpacking the double-edged sword: how artificial intelligence shapes hiring process through biased HR data
- [[Strengers_Kennedy_2021]] - The smart wife: Why Siri, Alexa, and other smart home devices need a feminist reboot
- [[Mehrabi_et_al_2021]] - A survey on bias and fairness in machine learning
- [[World_Economic_Forum_2019]] - Why AI is failing the next generation of women
- [[Roopaei_et_al_2021]] - Women in AI: barriers and solutions
- [[Hall_Ellis_2023]] - A systematic review of socio-technical gender bias in AI algorithms
