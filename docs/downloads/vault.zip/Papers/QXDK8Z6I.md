---
title: "Artificial Intelligence and Structural Injustice: Foundations for Equity, Values, and Responsibility"
authors:
  - J. Himmelreich
  - D. Lim
year: 2022
type: journalArticle
doi: 
url: "https://arxiv.org/abs/2205.02389"
tags:
  - paper
llm_decision: Include
llm_confidence: 0.92
llm_categories:
  - KI_Sonstige
  - Bias_Ungleichheit
  - Diversitaet
  - Fairness
human_decision: Exclude
human_categories:
  - KI_Sonstige
  - Bias_Ungleichheit
  - Gender
  - Feministisch
agreement: disagree
---

# Artificial Intelligence and Structural Injustice: Foundations for Equity, Values, and Responsibility

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** KI_Sonstige, Bias_Ungleichheit, Gender, Diversitaet, Fairness
**Argumente:** 5 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 92 |
| Correctness | 98 |
| Category Validation | 95 |
| **Overall Confidence** | **94** |

### Stufe 4: Assessment

**LLM:** Include (Confidence: 0.92)
**Human:** Exclude

**Kategorie-Vergleich (bei Divergenz):**

| Kategorie | Human | LLM | Divergent |
|-----------|-------|-----|----------|
| AI_Literacies | Nein | Nein |  |
| Generative_KI | Nein | Nein |  |
| Prompting | Nein | Nein |  |
| KI_Sonstige | Ja | Ja |  |
| Soziale_Arbeit | Nein | Nein |  |
| Bias_Ungleichheit | Ja | Ja |  |
| Gender | Ja | Nein | X |
| Diversitaet | Nein | Ja | X |
| Feministisch | Ja | Nein | X |
| Fairness | Nein | Ja | X |

## Wissensdokument

# AI and Structural Injustice: Foundations for Equity, Values, and Responsibility

## Kernbefund

Strukturelle Ungerechtigkeit bietet sowohl ein analytisches als auch ein normatives Rahmenwerk für KI-Governance und ermöglicht es, systemische Bias-Muster zu identifizieren, die Harm-and-Benefits-Ansätze übersehen würden. Ein struktureller Gerechtigkeitsansatz basiert auf Iris Marion Youngs Theorie und liefert tiefere Grundlagen für Diversity, Equity und Inclusion als alternative governance-Ansätze.

## Forschungsfrage

Wie kann ein struktureller Gerechtigkeitsansatz zur Governance von KI-Systemen beitragen und warum ist dieser Ansatz dem Harm-and-Benefits oder Value-Statement-Ansatz überlegen?

## Methodik

Theoretisch | Konzeptionelle Analyse mit illustrativen Beispielen aus der KI-Praxis (Gesundheitswesen, Hiring, Policing)
**Datenbasis:** nicht empirisch | Theoretische Analyse mit Case Study (Obermeyer et al. 2019 Studie zu medizinischem Algorithmus)

## Hauptargumente

- Strukturelle Injustiz ist ein analytisches und evaluatives Konzept: Sie erfordert strukturelle Erklärungen (wie gesellschaftliche Strukturen individuelle Handlungen und aggregierte Ergebnisse beeinflussen) und eine Theorie der Gerechtigkeit, um zu verstehen, warum bestimmte Unterschiede ungerecht sind.
- Der Harm-and-Benefits-Ansatz ist unzureichend, weil er individuelle Schäden isoliert, kollektive Schäden übersieht, sich auf interessen-basierte Harm-Konzepte beschränkt und komplexe Fragen der Aggregation und Gewichtung nicht löst.
- Value-Statement- und Ethik-Codes-Ansätze leiden unter Compliance-Verschiebung, Ethik-Washing und mangelnder Durchsetzung; DEI-Statements ohne strukturelles Verständnis können zu oberflächlichem Virtue-Signaling werden statt echtem Wandel zu bewirken.
- Strukturelle Erklärungen sind unverzichtbar um vorauszusehen, wie KI in bestehende ungerechte Strukturen eingebettet ist (z.B. räumliche Segregation bei Nummernschildlesern, niedrigere Gesundheitsausgaben für Black Patienten die als Proxy für Need genutzt werden).
- Substantive Verantwortung ohne Zurechnung von Schuld: Individuen und Organisationen können für die Behebung struktureller Ungerechtigkeit verantwortlich sein, auch wenn sie nicht schuldhaft daran beigetragen haben, wenn man zwischen attributiver und substantiver Verantwortung unterscheidet.

## Kategorie-Evidenz

### Evidenz 1

Die Autor:innen definieren AI als 'statistical methods that use Machine Learning (ML) to make data-based predictions or decisions' und untersuchen algorithmische Entscheidungssysteme in Healthcare, Hiring, Policing und Infrastruktur.

### Evidenz 2

Zentral ist die Analyse von 'racial bias in AI' (Obermeyer et al. 2019), strukturelle Erklärungen für unterschiedliche Behandlung Black patients: 'On average, however, the healthcare system spends less on Black patients than on white patients at all levels of healthcare needs.'

### Evidenz 3

Expliziter Gender-Fokus: 'We concentrate here mostly on gender and race. Structural injustices usually attach to salient social categories such as race, gender, age, ability, or sexual orientation.' sowie Beispiele wie 'gender prejudice' und gendered hiring discrimination (Lakisha/Emily Studie).

### Evidenz 4

Direkter Bezug zu DEI: 'The chapter suggests that structural injustice provides methodological and normative foundations for the values and concerns of Diversity, Equity, and Inclusion.' Behandlung marginalisierter Communities und intersektionaler Perspektiven.

### Evidenz 5

Umfangreiche Kritik an Fairness-Fokus: 'There is a consensus in AI governance that AI should be fair. However, this focus on fairness is limiting in important ways.' Analyse der epistemic limitations von Fairness und Unterscheidung zwischen Fairness und Equity/Justice.

## Assessment-Relevanz

**Domain Fit:** Hochrelevant für die Schnittstelle KI und Soziale Gerechtigkeit. Das Paper liefert theoretische Grundlagen für ein strukturelles Verständnis von Diskriminierung und Ungerechtigkeit in KI-Systemen, das für Sozialarbeiter:innen und Policymaker:innen zentral ist. Die Fokussierung auf strukturelle (nicht individuelle) Ursachen ist für Soziale Arbeit grundlegend.

**Unique Contribution:** Das Paper überträgt die philosophische Theorie der strukturellen Ungerechtigkeit (Iris Marion Young) systematisch auf KI-Governance und demonstriert, warum dieser Ansatz normativ und methodisch überlegen zu etablierten Frameworks (Harm-Benefit-Analysen, Ethik-Codes, Value Statements) ist.

**Limitations:** Das Paper konzentriert sich auf stilisierte Beispiele hauptsächlich aus nordamerikanischem Kontext; es adressiert nicht explizit praktische Implementierungsfragen oder hat Schwierigkeiten mit epistemischer Erkennbarkeit von Strukturen zugegeben ('The theory is epistemically hard').

**Target Group:** KI-Governance-Akteur:innen (Policymaker, Regulatoren), KI-Entwickler:innen mit ethischem Interesse, Wissenschaftler:innen in Applied Ethics und Political Philosophy, Diversity-und-Inclusion-Fachkräfte, Sozialwissenschaftler:innen die strukturelle Ungerechtigkeit untersuchen

## Schlüsselreferenzen

- [[Young_Iris_Marion_2011]] - Responsibility for Justice
- [[Obermeyer_Ziad_et_al_2019]] - Dissecting racial bias in an algorithm used to manage the health of populations
- [[Eubanks_Virginia_2018]] - Automating Inequality: How High-Tech Tools Profile, Police, and Punish the Poor
- [[Bertrand_Marianne_Mullainathan_Sendhil_2004]] - Are Emily and Greg More Employable than Lakisha and Jamal? A Field Experiment on Labor Market Discrimination
- [[Rawls_John_1971]] - A Theory of Justice
- [[Haslanger_Sally_2015]] - What is a (social) structural explanation?
- [[Herzog_Lisa_2017]] - What Could Be Wrong with a Mortgage? Private Debt Markets from a Perspective of Structural Injustice
- [[Mittelstadt_Brent_2019]] - Principles alone cannot guarantee ethical AI
- [[Rini_Regina_2020]] - The Ethics of Microaggression
- [[Mills_Charles_W_2017]] - Black Rights/white Wrongs: The Critique of Racial Liberalism
