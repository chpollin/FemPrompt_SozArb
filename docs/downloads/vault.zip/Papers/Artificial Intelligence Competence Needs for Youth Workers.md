---
title: Artificial Intelligence Competence Needs for Youth Workers
authors:
  - Miriam Lanzetta
  - Gianluca Abbruzzese
  - OVIDIU ACOMI
  - Nicoleta Acomi
  - Jorge Machado
  - Sonia Anastasia Maravelaki
  - Angela Mangiullo
  - Beatryz Schneider
  - Salomé Marques
year: 2024
type: journalArticle
doi: 10.5281/ZENODO.11525357
url: "https://zenodo.org/doi/10.5281/zenodo.11525357"
tags:
  - paper
llm_decision: Include
llm_confidence: 0.95
llm_categories:
  - AI_Literacies
  - Generative_KI
  - Soziale_Arbeit
human_decision: Include
human_categories:
  - AI_Literacies
  - Generative_KI
  - KI_Sonstige
  - Soziale_Arbeit
agreement: agree
---

# Artificial Intelligence Competence Needs for Youth Workers

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** AI_Literacies, Generative_KI, Prompting, KI_Sonstige, Soziale_Arbeit, Bias_Ungleichheit, Gender, Diversitaet, Fairness
**Argumente:** 3 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 88 |
| Correctness | 98 |
| Category Validation | 92 |
| **Overall Confidence** | **92** |

### Stufe 4: Assessment

**LLM:** Include (Confidence: 0.95)
**Human:** Include

## Wissensdokument

# Artificial Intelligence Competence Needs for Youth Workers

## Kernbefund

Jugendarbeiter:innen benötigen ein Spektrum technischer, analytischer und sozialer Kompetenzen (AI-Literalität, kritisches Denken, Datenkompetenz, ethische Verantwortung), wobei erhebliche Kompetenzlücken und Herausforderungen bei der Integration von KI-Tools bestehen.

## Forschungsfrage

Welche spezifischen Kompetenzen benötigen Jugendarbeiter:innen, um künstliche Intelligenz effektiv in ihre professionelle Arbeit zu integrieren?

## Methodik

Mixed Methods: Systematische Literaturanalyse (30+ Quellen), Fokusgruppen in 4 Ländern (Italien, Rumänien, Griechenland, Portugal) mit Jugendarbeitsfachleuten, Interviews
**Datenbasis:** Fokusgruppen mit Jugendarbeitsfachleuten in 4 europäischen Ländern; genaue Anzahl der Teilnehmenden nicht spezifiziert

## Hauptargumente

- KI-Technologien haben tiefgreifende Auswirkungen auf Jugendliche in Bildung, sozialen Interaktionen und psychologischem Wohlbefinden, daher müssen Jugendarbeiter:innen als Vermittler fungieren, um Jugendliche bei der kritischen Nutzung von KI zu unterstützen.
- Existierende Kompetenzrahmen (DigComp 2.2, DigCompEdu, UNESCO AI Competency Framework) können als Grundlagen dienen, müssen aber spezifisch für die Kontexte von Jugendarbeit adaptiert werden.
- Effektive KI-Integration in Jugendarbeit erfordert eine Balance zwischen technischen Fähigkeiten (Prompt Engineering, Datenkompetenz), Soft Skills (kritisches Denken, Kommunikation) und ethischer Verantwortung, um Datenschutz, Bias-Bewusstsein und kulturelle Sensibilität zu gewährleisten.

## Kategorie-Evidenz

### Evidenz 1

AI literacy als 'Familiarity with AI concepts, terminology, and applications to understand how AI tools work and their impact on youth work practices.' Umfangreicher Fokus auf KI-Kompetenzen und Kompetenzrahmen für Jugendarbeiter:innen.

### Evidenz 2

ChatGPT wird als Tool für Inhalterstellung, Ideengenerierung und kritisches Denken erwähnt: 'providing high-quality, free translation services and supporting critical thinking through tools like ChatGPT.'

### Evidenz 3

Prompt Engineering als essenzielle Fähigkeit identifiziert: 'youth workers need to develop prompt engineering skills to generate relevant and personalised content effectively.'

### Evidenz 4

Umfangreiche Diskussion von KI-Systemen allgemein: Suchmaschinen-Algorithmen, Personalisierung, 'Black Box' Decision-Making, Deep-Fakes, algorithmische Bias, Social Media AI-Systeme.

### Evidenz 5

Direkter Fokus auf Jugendarbeiter:innen und Jugendarbeitspraxis: 'youth workers play a critical role in guiding young people to make an effective and responsible use of AI systems' und umfangreiche Analyse von KI-Use-Cases in Jugendarbeitskontexten.

### Evidenz 6

Algorithmischer Bias und Ungleichheit werden analysiert: 'aware that the data, on which AI depends, may include biases... search results about occupation may include stereotypes about male or female jobs' und Digital Divide zwischen englischsprachigen und nicht-englischsprachigen Tools.

### Evidenz 7

Geschlechtsspezifische Unterschiede in KI-Nutzung untersucht: 'Generative AI use among GenZ by gender' und stereotypische Bias in KI-Systemen ('male bus drivers, female salesperson').

### Evidenz 8

Inklusion und Repräsentation werden betont: 'multilingual content and fostering cultural exchange and inclusivity', Herausforderungen mit lokalen Sprachen ('particularly problematic in countries like Greece, where there is a pressing need for localised AI solutions') und kulturelle Nuancen in KI-Interpretation.

### Evidenz 9

Faire Nutzung von KI-Systemen und Schutzmechanismen: 'ensuring that these tools are used in ways that protect and respect young people's rights', Bias-Awareness und ethische Verantwortung in KI-Anwendungen.

## Assessment-Relevanz

**Domain Fit:** Hochgradig relevant für die Schnittstelle KI/Soziale Arbeit: Das Paper adressiert direkt die Kompetenzanforderungen von Jugendarbeiter:innen beim Umgang mit KI und untersucht sowohl technische als auch ethische Dimensionen, was für ein emanzipatorisches Verständnis von Sozialer Arbeit zentral ist.

**Unique Contribution:** Das Paper trägt durch eine systematische Analyse von KI-Kompetenzen speziell für Jugendarbeiter:innen (nicht nur allgemeine Educator:innen oder Bürger:innen) und durch empirische Fokusgruppen in vier europäischen Ländern bei, die kontextspezifische Herausforderungen und Bedarfe identifizieren.

**Limitations:** Fokusgruppen-Größe und genaue Zusammensetzung nicht detailliert angegeben; begrenzt auf vier europäische Länder, daher keine globale Perspektive; der Fokus liegt eher auf Kompetenzen als auf strukturelle oder systemische Kritik von KI-Systemen.

**Target Group:** Jugendarbeiter:innen, Ausbilder:innen in der Sozialen Arbeit, Policymaker im Jugendsektor, KI-Entwickler:innen, die mit Jugendlichen arbeiten, Forschende in der Schnittstelle KI und Soziale Arbeit, Organisationen im Non-Formal Learning Sektor

## Schlüsselreferenzen

- [[Vuorikari_R_Kluzer_S_and_Punie_Y_2022]] - DigComp 2.2: The Digital Competence Framework for Citizens
- [[UNESCO_2023]] - UNESCO's AI Competency Framework for Teachers
- [[Digital_Promise_nicht spezifiziert]] - AI Literacy Framework
- [[European_Union_HighLevel_Expert_Group_on_AI_nicht spezifiziert]] - Ethics Guidelines for Trustworthy AI
