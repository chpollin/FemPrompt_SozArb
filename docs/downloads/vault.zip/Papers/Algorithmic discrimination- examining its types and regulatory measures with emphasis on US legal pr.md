---
title: "Algorithmic discrimination: examining its types and regulatory measures with emphasis on US legal practices"
authors:
  - X. Wang
  - Y. C. Wu
  - X. Ji
  - H. Fu
year: 2024
type: journalArticle
doi: 10.3389/frai.2024.1320277
url: "https://doi.org/10.3389/frai.2024.1320277"
tags:
  - paper
llm_decision: Include
llm_confidence: 0.92
llm_categories:
  - KI_Sonstige
  - Bias_Ungleichheit
  - Fairness
human_decision: Exclude
human_categories: []
agreement: disagree
---

# Algorithmic discrimination: examining its types and regulatory measures with emphasis on US legal practices

## Transformation Trail

### Stufe 1: Extraktion & Klassifikation (LLM)

**Extrahierte Kategorien:** KI_Sonstige, Soziale_Arbeit, Bias_Ungleichheit, Diversitaet, Fairness
**Argumente:** 3 extrahiert

### Stufe 3: Verifikation (LLM)

| Metrik | Score |
|--------|-------|
| Completeness | 92 |
| Correctness | 98 |
| Category Validation | 88 |
| **Overall Confidence** | **92** |

### Stufe 4: Assessment

**LLM:** Include (Confidence: 0.92)
**Human:** Exclude

**Kategorie-Vergleich (bei Divergenz):**

| Kategorie | Human | LLM | Divergent |
|-----------|-------|-----|----------|
| AI_Literacies | Nein | Nein |  |
| Generative_KI | Nein | Nein |  |
| Prompting | Nein | Nein |  |
| KI_Sonstige | Nein | Ja | X |
| Soziale_Arbeit | Nein | Nein |  |
| Bias_Ungleichheit | Nein | Ja | X |
| Gender | Nein | Nein |  |
| Diversitaet | Nein | Nein |  |
| Feministisch | Nein | Nein |  |
| Fairness | Nein | Ja | X |

## Wissensdokument

# Algorithmic discrimination: examining its types and regulatory measures with emphasis on US legal practices

## Kernbefund

Das Paper identifiziert fünf primäre Typen algorithmischer Voreingenommenheit (Bias durch algorithmische Agenten, diskriminierende Feature-Selektion, Proxy-Diskriminierung, Disparate Impact, zielgerichtete Werbung) und kategorisiert US-Regulierungsrahmen in fünf Ansätze (principled regulation, preventive controls, consequential liability, self-regulation, heteronomy regulation).

## Forschungsfrage

Welche Typen von algorithmischer Diskriminierung existieren und welche regulatorischen Maßnahmen sind in den USA und international vorhanden, um diese zu bekämpfen?

## Methodik

Theoretisch/Mixed Methods - Systematische Literaturanalyse (85 Artikel), Analyse von Rechtsdokumenten und vergleichende Fallstudien über mehrere Sektoren und Länder
**Datenbasis:** Systematische Literaturanalyse von 85 peer-reviewed Artikeln aus ACM Digital Library, IEEE Xplore, LexisNexis, HeinOnline und Google Scholar; Analyse von Gerichtsfällen und Regulierungsdokumenten

## Hauptargumente

- Algorithmische Diskriminierung kann sich in mehreren verschiedenen Formen manifestieren - von explizit intendierter Diskriminierung bis zu unbewussten Verzerrungen in Trainingsdaten, Feature-Auswahl oder Modellgestaltung - und erfordert daher differenzierte regulatorische Ansätze.
- Bestehende US-Antidiskriminierungsgesetze sind unzureichend für die Regulierung algorithmischer Systeme; es werden proaktive Impact Assessments, Transparenzanforderungen und Auditierungsmechanismen benötigt, um systematische Diskriminierung zu verhindern.
- Juristische Überprüfung muss sowohl intentionale als auch unintentionale algorithmische Diskriminierung erfassen; unintentionale Diskriminierung sollte durch Analyse von Datenmustern, Impact-Assessment und Ursachenanalyse erkannt werden, um strukturelle Ungleichheiten zu adressieren.

## Kategorie-Evidenz

### Evidenz 1

Das Paper konzentriert sich auf 'algorithmic decision-making systems' in Kriminalitätsprognose, Einstellung, Bildung und Kreditvergabe und behandelt klassische Machine Learning, nicht generative KI.

### Evidenz 2

Explizite Behandlung von Algorithmen im Criminal Justice System ('judges to estimate the risk of reoffending'), Arbeitseinstellung und Bildung ('schools to choose whether to admit students'), die zentrale Domänen Sozialer Arbeit und ihrer Schnittstellen sind.

### Evidenz 3

Kernfokus des Papers: 'Algorithmic discrimination can manifest in various forms, such as bias by the algorithmic agents, biased feature selection... These different types of algorithmic bias can lead to unfair treatment and disparate impacts on protected groups, raising concerns about equal rights, due process, and social justice'

### Evidenz 4

Paper diskutiert 'disparate impacts on protected groups' und bezieht sich auf verschiedene marginalisierte Gruppen in Kontexten wie Criminal Justice Risk Assessments und Hiring Algorithms, mit Bezug zu 'lack of diversity in the development teams' als Ursache.

### Evidenz 5

Zentrales Thema durchgehend: 'algorithmic fairness, transparency, and accountability', spezifische Behandlung von Fairness-Metriken, Fairness Constraints in ML und 'algorithmic auditing and impact assessments' zur Messung und Gewährleistung von Fairness.

## Assessment-Relevanz

**Domain Fit:** Das Paper ist hochrelevant für die Schnittstelle KI und Soziale Arbeit, da es konkrete algorithmische Systeme in Bereichen adressiert, die zentral für Soziale Arbeit sind (Criminal Justice, Employment, Education), und strukturelle Mechanismen der Diskriminierung analysiert, die marginalisierte Gruppen betreffen.

**Unique Contribution:** Der Hauptbeitrag liegt in der systematischen Taxonomie von fünf Typen algorithmischer Diskriminierung und der vergleichenden Analyse von US-Regulierungsrahmen mit internationalen Perspektiven, kombiniert mit praktischen Fallstudien zur Illustration realer Auswirkungen.

**Limitations:** Das Paper konzentriert sich primär auf den US-Kontext und das Rechtssystem; es fehlt eine explizit intersektionale oder feministische Analyse der Diskriminierungsmechanismen, und die Perspektive betroffener Communitys ist unterrepräsentiert.

**Target Group:** Policymaker, Jurist:innen, KI-Entwickler:innen, Regulierungsbehörden, Sozialarbeiter:innen in Justiz- und Sozialverwaltung, Forscher:innen in KI-Ethik und Algorithmic Fairness, Aktivist:innen im Bereich Algorithmic Justice

## Schlüsselreferenzen

- [[Selbst_and_Barocas_2016]] - Big Data's Disparate Impact
- [[Buolamwini_and_Gebru_2018]] - Gender Shades: Intersectional Accuracy Disparities in Commercial Gender Classification
- [[Kroll_et_al_2017]] - Accountable Algorithms
- [[Crawford_and_Schultz_2014]] - Big Data and Due Process
- [[Pasquale_2015]] - The Black Box Society
- [[ONeil_2017]] - Weapons of Math Destruction
- [[West_et_al_2019]] - Discriminating Systems: Gender, Race and Power in AI
- [[Reisman_et_al_2018]] - Algorithmic Impact Assessments: A Practical Framework for Public Agency
- [[Prince_and_Schwarcz_2019]] - Proxy Discrimination in the Age of Artificial Intelligence and Big Data
- [[Berk_et_al_2021]] - Fairness in Criminal Justice Risk Assessments: The State of the Art
