---
title: A framework for the learning and teaching of Critical AI Literacy skills (Version 0.1)
authors:
  - M. Hauck
  - E. Moore
  - C. Wright
year: 2025
type: report
url: https://www.open.ac.uk/blogs/learning-design/wp-content/uploads/2025/01/OU-Critical-AI-Literacy-framework-2025-external-sharing.pdf
tags:
  - paper
  - feminist-ai
  - bias-research
date_added: 2026-02-22
date_modified: 2026-02-22
---

# A framework for the learning and teaching of Critical AI Literacy skills (Version 0.1)

## Abstract

This framework defines Critical AI Literacy as expanding beyond traditional AI literacy to examine how Large Language Models contribute to ongoing epistemic injustices that can lead to significant social and personal harm. It applies equality, diversity, inclusion, and accessibility principles to AI use, emphasizing the importance of critically evaluating AI-generated outputs and engaging in equitable and inclusive prompting practices. Critical AI Literacy is conceptualized as context-specific and treats literacy as a social practice rather than a possession. At advanced levels, it examines AI's potential to shift power relationships and explores how AI contributes to inequalities while considering ways it could help redress power balances.

## Key Concepts

## Full Text

---
title: "A framework for the Learning and Teaching of Critical AI Literacy skills"
authors: ["Dr Mirjam Hauck", "Eleanor Moore", "Carol Wright"]
year: 2025
type: workingPaper
language: en
processed: 2026-02-05
source_file: Hauck_2025_A_framework_for_the_learning_and_teaching_of.md
confidence: 94
---

# A framework for the Learning and Teaching of Critical AI Literacy skills

## Kernbefund

Ein umfassendes Framework für Critical AI Literacy, das technische KI-Konzepte mit kritischer Reflexion, ethischen Überlegungen und EDIA-Prinzipien verbindet und konkrete Handlungsempfehlungen für Lehrende bietet.

## Forschungsfrage

Wie können Lehrende und Lernende Critical AI Literacy-Kompetenzen unter Berücksichtigung von Equality, Diversity, Inclusion und Accessibility (EDIA) entwickeln?

## Methodik

Theoretisch; Framework-Entwicklung basierend auf Literaturanalyse und Best-Practice-Sammlung; Struktur angelehnt an Sharples (2024); iterativ und kollaborativ konzipiert

## Hauptargumente

- KI unterscheidet sich fundamental von anderen digitalen Technologien durch ihr Potenzial, Gesellschaft, Wirtschaft und Bildungssysteme tiefgreifend zu transformieren, was spezialisierte Kompetenzen über traditionelle digitale Literalität hinaus erfordert.
- Critical AI Literacy muss sich an Critical Digital Literacy orientieren und Machtstrukturen in KI-Systemen analysieren, insbesondere wie Wissen, Identitäten und Beziehungen so gestaltet werden, dass einige privilegiert und andere marginalisiert werden.
- Eine erfolgreiche Integration von Critical AI Literacy in die Hochschullehre erfordert ein iteratives, kollaboratives Vorgehen mit EDIA-Prinzipien als zentralem Orientierungspunkt und konkrete, disziplinübergreifende Implementierungsbeispiele.
- Lernende benötigen reflektive Mindsets und metacognitive Fähigkeiten, um mit der rasanten Entwicklung von KI-Technologien Schritt zu halten und diese verantwortungsvoll in beruflichen und privaten Kontexten einzusetzen.

## Kategorie-Evidenz

### Evidenz 1

Gesamter Fokus des Papers auf 'Critical AI Literacy' als Kompetenzrahmen; 'a set of competencies that enables individuals to critically evaluate AI technologies; communicate and collaborate effectively with AI'

### Evidenz 2

Expliziter Fokus auf LLMs und GenAI: 'Large Language Models (LLMs) -AI tools which generate human-like responses'; Umgang mit Generative AI in Learning, Teaching and Assessment

### Evidenz 3

Framework-Sektion 'Learning and teaching with AI' enthält: 'Support students in crafting effective prompts and refining AI content' und 'Offer guidance and examples on prompt creation and adaptation with a focus on EDIA principles'

### Evidenz 4

Breites Spektrum an KI-Anwendungen: 'types of AI products: text, image, video, code, music generators; AI embedded in tools such as search engines; AI analytics and predictive analytics'

### Evidenz 5

Zentrales Thema: 'Critical AI Literacy examines how Large Language Models (LLMs)...contribute to ongoing epistemic injustices'; 'Be mindful of biases in AI outputs, such as gender, cultural, disability, racial or cultural bias'

### Evidenz 6

EDIA-Perspektive durchgängig: 'Critical AI Literacy applies the lens of equality, diversity, inclusion and accessibility (EDIA) to the use of AI'; Beispiele wie 'OU's Digital Assistant, which supports students' accessibility needs'

### Evidenz 7

Ethische Bewertungskriterien für KI-Tools: 'Use key criteria to evaluate AI tools (e.g. functionality, accessibility, privacy, security, copyright)'; Alignment mit Institutional Fairness-Prinzipien

## Assessment-Relevanz

**Domain Fit:** Das Paper adressiert die Schnittstelle von KI-Kompetenzentwicklung und sozialer Gerechtigkeit (equity, diversity, inclusion, accessibility), wobei es primär im Hochschulkontext angesiedelt ist. Der Bezug zu Sozialer Arbeit ist implizit durch die EDIA-Perspektive und Fokus auf marginalisierte Gruppen vorhanden, wird aber nicht explizit ausgeführt.

**Unique Contribution:** Das Framework integriert erstmals systematisch Critical Digital Literacy-Ansätze in AI-Literacy und verankert EDIA-Prinzipien nicht als Zusatz, sondern als zentrale Kategorie in allen sieben Framework-Dimensionen; mit konkreten Handlungsempfehlungen für Lehrende.

**Limitations:** Rein theoretisches Framework ohne empirische Validierung oder Implementierungsergebnisse; begrenzte Diskussion von Kontexten außerhalb der englischsprachigen Hochschullandschaft; fehlendes Engagement mit feministischen oder intersektionalen Theorietraditionen trotz starkem EDIA-Fokus.

**Target Group:** Hochschullehrende und Bildungsdesigner:innen in der Hochschullehre; Lerndesigner:innen und Curricula-Entwickler:innen; Institutionale Führungskräfte in Lehre und Lernen; Studierende mit Karriereinteresse in AI-Anwendungen; Policymaker im Hochschulsektor. Potenziell relevant für Sozialarbeiter:innen, die mit Zielgruppen arbeiten, die durch KI-Systeme beeinflusst werden.

## Schlüsselreferenzen

- [[Long_D_Magerko_B_2020]] - What is AI literacy? Competencies and design considerations
- [[Darvin_R_2017]] - Language, ideology, and critical digital literacy
- [[Chiu_TKF_Ahmad_Z_Ismailov_M_Sanusi_IT_2024]] - What are artificial intelligence literacy and competency?
- [[Darvishi_A_Khosravi_H_Sadiq_S_Gašević_D_Siemens_G_2024]] - Impact of AI assistance on student agency
- [[Sharples_M_2024]] - What to teach about AI?
- [[Jiang_L_Gu_MM_2022]] - Toward a Professional Development Model for Critical Digital Literacies in TESOL
- [[Mirra_N_Garcia_A_2020]] - 'I Hesitate but I Do Have Hope': Youth speculative civic literacies for troubled times
- [[Miao_F_Shiohira_K_2024]] - AI Competency Framework for Students (UNESCO)
