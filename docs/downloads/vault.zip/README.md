# FemPrompt working collection

Historical and provisional research material, not a completed or uniformly verified synthesis.
The source-reviewed public release is built separately with agent/model/date attribution.
record-index.json retains aliases and exact bibliographic Versions. Document reuse across records does not establish that the source was read in each of those Versions.
