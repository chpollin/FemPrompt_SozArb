---
title: Feminist Frameworks
category: Mitigation_Strategies
frequency: 2
papers: 1
tags: [concept, mitigation_strategies]
date_created: 2026-02-22
---

# Feminist Frameworks

**Category:** Mitigation_Strategies  
**Mentioned:** 2 times across 1 papers

## Papers

- [[Feminist reflections for the development of artificial intelligence]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Feminist Frameworks here*
