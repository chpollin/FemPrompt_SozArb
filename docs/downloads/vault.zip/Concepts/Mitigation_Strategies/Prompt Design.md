---
title: Prompt Design
category: Mitigation_Strategies
frequency: 3
papers: 2
tags: [concept, mitigation_strategies]
date_created: 2026-02-22
---

# Prompt Design

**Category:** Mitigation_Strategies  
**Mentioned:** 3 times across 2 papers

## Papers

- [[AI Creates the Message- Integrating AI Language Learning Models into Social Work Education and Practice]]
- [[Reflexive prompt engineering- A framework for responsible prompt engineering and AI interaction design]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Prompt Design here*
