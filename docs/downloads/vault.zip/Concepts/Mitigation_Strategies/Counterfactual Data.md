---
title: Counterfactual Data
category: Mitigation_Strategies
frequency: 3
papers: 2
tags: [concept, mitigation_strategies]
date_created: 2026-02-22
---

# Counterfactual Data

**Category:** Mitigation_Strategies  
**Mentioned:** 3 times across 2 papers

## Papers

- [[Prompting fairness- Learning prompts for debiasing large language models]]
- [[Tang_2024_GenderCARE_A_Comprehensive_Framework_for]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Counterfactual Data here*
