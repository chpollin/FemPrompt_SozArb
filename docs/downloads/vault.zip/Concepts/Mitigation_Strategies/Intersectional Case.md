---
title: Intersectional Case
category: Mitigation_Strategies
frequency: 4
papers: 1
tags: [concept, mitigation_strategies]
date_created: 2026-02-22
---

# Intersectional Case

**Category:** Mitigation_Strategies  
**Mentioned:** 4 times across 1 papers

## Papers

- [[Assessing GPT's bias towards stigmatized social groups- An intersectional case study on nationality prejudice and psychophobia]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Intersectional Case here*
