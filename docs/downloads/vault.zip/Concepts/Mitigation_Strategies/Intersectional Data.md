---
title: Intersectional Data
category: Mitigation_Strategies
frequency: 4
papers: 2
tags: [concept, mitigation_strategies]
date_created: 2026-02-22
---

# Intersectional Data

**Category:** Mitigation_Strategies  
**Mentioned:** 4 times across 2 papers

## Papers

- [[Friedrich-Ebert-Stiftung_2025_artificial]]
- [[Gender in a stereo-(gender)typical EU AI law- A feminist reading of the AI Act]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Intersectional Data here*
