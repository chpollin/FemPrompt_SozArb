---
title: Counterfactual Fairness
category: Mitigation_Strategies
frequency: 6
papers: 2
tags: [concept, mitigation_strategies]
date_created: 2026-02-22
---

# Counterfactual Fairness

**Category:** Mitigation_Strategies  
**Mentioned:** 6 times across 2 papers

## Papers

- [[A survey on fairness in large language models]]
- [[Counterfactual fairness in text classification through robustness]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Counterfactual Fairness here*
