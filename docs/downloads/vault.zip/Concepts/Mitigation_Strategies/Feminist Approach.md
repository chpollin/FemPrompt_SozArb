---
title: Feminist Approach
category: Mitigation_Strategies
frequency: 3
papers: 3
tags: [concept, mitigation_strategies]
date_created: 2026-02-22
---

# Feminist Approach

**Category:** Mitigation_Strategies  
**Mentioned:** 3 times across 3 papers

## Papers

- [[An empirical study of structural social and ethical challenges in AI]]
- [[Friedrich-Ebert-Stiftung_2025_artificial]]
- [[Gender in a stereo-(gender)typical EU AI law- A feminist reading of the AI Act]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Feminist Approach here*
