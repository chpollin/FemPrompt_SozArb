---
title: Calibration
category: Mitigation_Strategies
frequency: 6
papers: 5
tags: [concept, mitigation_strategies]
date_created: 2026-02-22
---

# Calibration

**Category:** Mitigation_Strategies  
**Mentioned:** 6 times across 5 papers

## Papers

- [[Gohar_2023_Survey]]
- [[Pan_2025_AI_literacy_and_trust_A_multi-method_study_of]]
- [[Revisiting Technical Bias Mitigation Strategies]]
- [[Trust in artificial intelligence–based clinical decision support systems among health care workers- Systematic review]]
- [[What large language models know and what people think they know]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Calibration here*
