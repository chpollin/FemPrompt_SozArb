---
title: Intersectional Evidence
category: Mitigation_Strategies
frequency: 4
papers: 1
tags: [concept, mitigation_strategies]
date_created: 2026-02-22
---

# Intersectional Evidence

**Category:** Mitigation_Strategies  
**Mentioned:** 4 times across 1 papers

## Papers

- [[Measuring gender and racial biases in large language models- Intersectional evidence from automated resume evaluation]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Intersectional Evidence here*
