---
title: Intersectional Stereotypes
category: Mitigation_Strategies
frequency: 10
papers: 2
tags: [concept, mitigation_strategies]
date_created: 2026-02-22
---

# Intersectional Stereotypes

**Category:** Mitigation_Strategies  
**Mentioned:** 10 times across 2 papers

## Papers

- [[Flexible intersectional stereotype extraction (FISE)- Analyzing intersectional biases in large language models]]
- [[Intersectional Stereotypes in Large Language Models- Dataset and Analysis]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Intersectional Stereotypes here*
