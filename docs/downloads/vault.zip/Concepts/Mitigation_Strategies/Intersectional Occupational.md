---
title: Intersectional Occupational
category: Mitigation_Strategies
frequency: 3
papers: 1
tags: [concept, mitigation_strategies]
date_created: 2026-02-22
---

# Intersectional Occupational

**Category:** Mitigation_Strategies  
**Mentioned:** 3 times across 1 papers

## Papers

- [[Gender, race, and intersectional bias in AI resume screening via language model retrieval]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Intersectional Occupational here*
