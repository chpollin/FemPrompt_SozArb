---
title: Counterfactual Token
category: Mitigation_Strategies
frequency: 3
papers: 1
tags: [concept, mitigation_strategies]
date_created: 2026-02-22
---

# Counterfactual Token

**Category:** Mitigation_Strategies  
**Mentioned:** 3 times across 1 papers

## Papers

- [[Counterfactual fairness in text classification through robustness]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Counterfactual Token here*
