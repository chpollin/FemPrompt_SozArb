---
title: Inclusive Ai
category: Mitigation_Strategies
frequency: 11
papers: 5
tags: [concept, mitigation_strategies]
date_created: 2026-02-22
---

# Inclusive Ai

**Category:** Mitigation_Strategies  
**Mentioned:** 11 times across 5 papers

## Papers

- [[How can feminism inform AI governance in practice-]]
- [[How to Create Inclusive AI Images- A Guide to Bias-Free Prompting]]
- [[Ng_2022_Using_digital_story_writing_as_a_pedagogy_to]]
- [[What are artificial intelligence literacy and competency- A comprehensive framework to support them]]
- [[Women4Ethical AI- Global cooperation for gender-inclusive AI]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Inclusive Ai here*
