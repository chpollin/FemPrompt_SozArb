---
title: Fairness Constraints
category: Mitigation_Strategies
frequency: 3
papers: 2
tags: [concept, mitigation_strategies]
date_created: 2026-02-22
---

# Fairness Constraints

**Category:** Mitigation_Strategies  
**Mentioned:** 3 times across 2 papers

## Papers

- [[Advancing Accountability in AI]]
- [[Algorithmic discrimination- examining its types and regulatory measures with emphasis on US legal practices]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Fairness Constraints here*
