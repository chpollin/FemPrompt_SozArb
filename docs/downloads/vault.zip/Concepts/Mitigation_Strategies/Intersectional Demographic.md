---
title: Intersectional Demographic
category: Mitigation_Strategies
frequency: 6
papers: 3
tags: [concept, mitigation_strategies]
date_created: 2026-02-22
---

# Intersectional Demographic

**Category:** Mitigation_Strategies  
**Mentioned:** 6 times across 3 papers

## Papers

- [[Factoring the Matrix of Domination- A Critical Review and Reimagination of Intersectionality in AI Fairness]]
- [[Intersectional Stereotypes in Large Language Models- Dataset and Analysis]]
- [[Ovalle_2023_Factoring]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Intersectional Demographic here*
