---
title: Feminist AI
category: Mitigation_Strategies
frequency: 32
papers: 10
tags: [concept, mitigation_strategies]
date_created: 2026-02-22
---

# Feminist AI

**Category:** Mitigation_Strategies  
**Mentioned:** 32 times across 10 papers

## Papers

- [[Alliance_2024_Incubating]]
- [[Avoiding Catastrophe Through Intersectionality in Global AI Governance]]
- [[Avoiding catastrophe through intersectionality in global AI governance]]
- [[Gengler_2024_Faires_KI-Prompting_–_Ein_Leitfaden_für]]
- [[How can feminism inform AI governance in practice-]]
- [[Incubating Feminist AI- Executive Summary 2021-2024]]
- [[Tensions in digital welfare states- Three perspectives on care and control]]
- [[Towards Substantive Equality in Artificial Intelligence- Transformative AI Policy for Gender Equality and Diversity]]
- [[What is Feminist AI-]]
- [[Wudel_2025_What]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Feminist AI here*
