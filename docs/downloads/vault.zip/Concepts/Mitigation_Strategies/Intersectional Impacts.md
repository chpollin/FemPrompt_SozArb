---
title: Intersectional Impacts
category: Mitigation_Strategies
frequency: 2
papers: 1
tags: [concept, mitigation_strategies]
date_created: 2026-02-22
---

# Intersectional Impacts

**Category:** Mitigation_Strategies  
**Mentioned:** 2 times across 1 papers

## Papers

- [[Digital literacy as a new determinant of health- A scoping review]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Intersectional Impacts here*
