---
title: Intersectional Definition
category: Mitigation_Strategies
frequency: 6
papers: 2
tags: [concept, mitigation_strategies]
date_created: 2026-02-22
---

# Intersectional Definition

**Category:** Mitigation_Strategies  
**Mentioned:** 6 times across 2 papers

## Papers

- [[Gohar_2023_Survey]]
- [[Intersectional Fairness- A Fractal Approach]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Intersectional Definition here*
