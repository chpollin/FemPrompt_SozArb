---
title: Equitable Ai
category: Mitigation_Strategies
frequency: 3
papers: 2
tags: [concept, mitigation_strategies]
date_created: 2026-02-22
---

# Equitable Ai

**Category:** Mitigation_Strategies  
**Mentioned:** 3 times across 2 papers

## Papers

- [[Prompt Engineering Techniques for Mitigating Cultural Bias Against Arabs and Muslims in Large Language Models- A Systematic Review]]
- [[Social work and artificial intelligence- Collaboration and challenges]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Equitable Ai here*
