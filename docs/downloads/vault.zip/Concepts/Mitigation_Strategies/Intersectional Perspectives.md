---
title: Intersectional Perspectives
category: Mitigation_Strategies
frequency: 4
papers: 2
tags: [concept, mitigation_strategies]
date_created: 2026-02-22
---

# Intersectional Perspectives

**Category:** Mitigation_Strategies  
**Mentioned:** 4 times across 2 papers

## Papers

- [[Artificial Intelligence Competence Needs for Youth Workers]]
- [[Tensions in digital welfare states- Three perspectives on care and control]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Intersectional Perspectives here*
