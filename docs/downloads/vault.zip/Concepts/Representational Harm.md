---
title: Representational Harm
type: concept
frequency: 2
papers_count: 2
related_concepts: []
tags:
  - concept
---
# Representational Harm

## Definition

Schädigung durch systematisch eingeengte, stereotype oder othering Darstellungen marginalisierter Gruppen in KI-generierten Texten, die auch bei nicht-explizit negativem Inhalt soziale Marginalisierung perpetuieren.

## Papers

- [[Unequal voices- How LLMs construct constrained queer narratives]]
- [[BBQ- A hand-built bias benchmark for question answering]]

## Assessment-Divergenz

Von 1 bewerteten Papers: 0 Divergenzen (0%)

