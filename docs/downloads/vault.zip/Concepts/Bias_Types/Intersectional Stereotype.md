---
title: Intersectional Stereotype
category: Bias_Types
frequency: 6
papers: 1
tags: [concept, bias_types]
date_created: 2026-02-22
---

# Intersectional Stereotype

**Category:** Bias_Types  
**Mentioned:** 6 times across 1 papers

## Papers

- [[Flexible intersectional stereotype extraction (FISE)- Analyzing intersectional biases in large language models]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Intersectional Stereotype here*
