---
title: Stereotypischer
category: Bias_Types
frequency: 2
papers: 1
tags: [concept, bias_types]
date_created: 2026-02-22
---

# Stereotypischer

**Category:** Bias_Types  
**Mentioned:** 2 times across 1 papers

## Papers

- [[Kamruzzaman_2024_Prompting]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Stereotypischer here*
