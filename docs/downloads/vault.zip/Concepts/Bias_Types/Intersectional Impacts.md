---
title: Intersectional Impacts
category: Bias_Types
frequency: 2
papers: 1
tags: [concept, bias_types]
date_created: 2026-02-22
---

# Intersectional Impacts

**Category:** Bias_Types  
**Mentioned:** 2 times across 1 papers

## Papers

- [[Digital literacy as a new determinant of health- A scoping review]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Intersectional Impacts here*
