---
title: Stereotypischen
category: Bias_Types
frequency: 4
papers: 3
tags: [concept, bias_types]
date_created: 2026-02-22
---

# Stereotypischen

**Category:** Bias_Types  
**Mentioned:** 4 times across 3 papers

## Papers

- [[Bias, accuracy, and trust- Gender-diverse perspectives on large language models]]
- [[Kamruzzaman_2024_Prompting]]
- [[Self-debiasing large language models- Zero-shot recognition and reduction of stereotypes]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Stereotypischen here*
