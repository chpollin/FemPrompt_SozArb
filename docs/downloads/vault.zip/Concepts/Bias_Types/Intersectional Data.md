---
title: Intersectional Data
category: Bias_Types
frequency: 4
papers: 2
tags: [concept, bias_types]
date_created: 2026-02-22
---

# Intersectional Data

**Category:** Bias_Types  
**Mentioned:** 4 times across 2 papers

## Papers

- [[Friedrich-Ebert-Stiftung_2025_artificial]]
- [[Gender in a stereo-(gender)typical EU AI law- A feminist reading of the AI Act]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Intersectional Data here*
