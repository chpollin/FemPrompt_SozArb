---
title: Intersectional Perspectives
category: Bias_Types
frequency: 4
papers: 2
tags: [concept, bias_types]
date_created: 2026-02-22
---

# Intersectional Perspectives

**Category:** Bias_Types  
**Mentioned:** 4 times across 2 papers

## Papers

- [[Artificial Intelligence Competence Needs for Youth Workers]]
- [[Tensions in digital welfare states- Three perspectives on care and control]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Intersectional Perspectives here*
