---
title: Stereotypisieren
category: Bias_Types
frequency: 2
papers: 2
tags: [concept, bias_types]
date_created: 2026-02-22
---

# Stereotypisieren

**Category:** Bias_Types  
**Mentioned:** 2 times across 2 papers

## Papers

- [[How to Create Inclusive AI Images- A Guide to Bias-Free Prompting]]
- [[The cultural stereotype and cultural bias of ChatGPT]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Stereotypisieren here*
