---
title: Intersectional Nature
category: Bias_Types
frequency: 2
papers: 1
tags: [concept, bias_types]
date_created: 2026-02-22
---

# Intersectional Nature

**Category:** Bias_Types  
**Mentioned:** 2 times across 1 papers

## Papers

- [[Assessing GPT's bias towards stigmatized social groups- An intersectional case study on nationality prejudice and psychophobia]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Intersectional Nature here*
