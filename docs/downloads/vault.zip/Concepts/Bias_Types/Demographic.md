---
title: Demographic
category: Bias_Types
frequency: 3
papers: 2
tags: [concept, bias_types]
date_created: 2026-02-22
---

# Demographic

**Category:** Bias_Types  
**Mentioned:** 3 times across 2 papers

## Papers

- [[Measuring gender and racial biases in large language models- Intersectional evidence from automated resume evaluation]]
- [[PreciseDebias- An automatic prompt engineering approach for generative AI to mitigate image demographic biases]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Demographic here*
