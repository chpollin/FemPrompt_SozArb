---
title: Intersectional Demographic
category: Bias_Types
frequency: 6
papers: 3
tags: [concept, bias_types]
date_created: 2026-02-22
---

# Intersectional Demographic

**Category:** Bias_Types  
**Mentioned:** 6 times across 3 papers

## Papers

- [[Factoring the Matrix of Domination- A Critical Review and Reimagination of Intersectionality in AI Fairness]]
- [[Intersectional Stereotypes in Large Language Models- Dataset and Analysis]]
- [[Ovalle_2023_Factoring]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Intersectional Demographic here*
