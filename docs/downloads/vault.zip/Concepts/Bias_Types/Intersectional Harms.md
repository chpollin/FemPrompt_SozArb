---
title: Intersectional Harms
category: Bias_Types
frequency: 4
papers: 1
tags: [concept, bias_types]
date_created: 2026-02-22
---

# Intersectional Harms

**Category:** Bias_Types  
**Mentioned:** 4 times across 1 papers

## Papers

- [[Coded injustice- Surveillance and discrimination in Denmark's automated welfare state]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Intersectional Harms here*
