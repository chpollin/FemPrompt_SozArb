---
title: Stereotypische
category: Bias_Types
frequency: 9
papers: 6
tags: [concept, bias_types]
date_created: 2026-02-22
---

# Stereotypische

**Category:** Bias_Types  
**Mentioned:** 9 times across 6 papers

## Papers

- [[Bias, accuracy, and trust- Gender-diverse perspectives on large language models]]
- [[Explicitly unbiased large language models still form biased associations]]
- [[How to Create Inclusive AI Images- A Guide to Bias-Free Prompting]]
- [[Prompting techniques for reducing social bias in LLMs through System 1 and System 2 cognitive processes]]
- [[Qiu_2025_Mitigating]]
- [[The power of prompts- Evaluating and mitigating gender bias in MT with LLMs]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Stereotypische here*
