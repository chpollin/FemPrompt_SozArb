---
title: Disparity
category: Bias_Types
frequency: 6
papers: 4
tags: [concept, bias_types]
date_created: 2026-02-22
---

# Disparity

**Category:** Bias_Types  
**Mentioned:** 6 times across 4 papers

## Papers

- [[AI algorithm transparency, pipelines for trust not prisms- mitigating general negative attitudes and enhancing trust toward AI]]
- [[Are -Intersectionally Fair- AI Algorithms Really Fair to Women of Color- A Philosophical Analysis]]
- [[Bias against women and girls in large language models- A UNESCO study]]
- [[Measuring and mitigating unintended bias in text data]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Disparity here*
