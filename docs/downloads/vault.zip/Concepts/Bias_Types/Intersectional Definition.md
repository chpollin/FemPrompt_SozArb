---
title: Intersectional Definition
category: Bias_Types
frequency: 6
papers: 2
tags: [concept, bias_types]
date_created: 2026-02-22
---

# Intersectional Definition

**Category:** Bias_Types  
**Mentioned:** 6 times across 2 papers

## Papers

- [[Gohar_2023_Survey]]
- [[Intersectional Fairness- A Fractal Approach]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Intersectional Definition here*
