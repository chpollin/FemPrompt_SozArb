---
title: Stereotypisierung
category: Bias_Types
frequency: 7
papers: 5
tags: [concept, bias_types]
date_created: 2026-02-22
---

# Stereotypisierung

**Category:** Bias_Types  
**Mentioned:** 7 times across 5 papers

## Papers

- [[Assessing GPT's bias towards stigmatized social groups- An intersectional case study on nationality prejudice and psychophobia]]
- [[Bias, accuracy, and trust- Gender-diverse perspectives on large language models]]
- [[Flexible intersectional stereotype extraction (FISE)- Analyzing intersectional biases in large language models]]
- [[Ng_2025_Opportunities,_challenges_and_school_strategies]]
- [[Self-debiasing large language models- Zero-shot recognition and reduction of stereotypes]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Stereotypisierung here*
