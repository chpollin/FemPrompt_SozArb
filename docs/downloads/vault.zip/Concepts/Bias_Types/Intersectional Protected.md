---
title: Intersectional Protected
category: Bias_Types
frequency: 2
papers: 1
tags: [concept, bias_types]
date_created: 2026-02-22
---

# Intersectional Protected

**Category:** Bias_Types  
**Mentioned:** 2 times across 1 papers

## Papers

- [[Bias in decision-making for AI's ethical dilemmas- A comparative study of ChatGPT and Claude]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Intersectional Protected here*
