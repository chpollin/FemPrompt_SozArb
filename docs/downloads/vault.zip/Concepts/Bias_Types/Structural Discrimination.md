---
title: Structural Discrimination
category: Bias_Types
frequency: 3
papers: 3
tags: [concept, bias_types]
date_created: 2026-02-22
---

# Structural Discrimination

**Category:** Bias_Types  
**Mentioned:** 3 times across 3 papers

## Papers

- [[Coded injustice- Surveillance and discrimination in Denmark's automated welfare state]]
- [[What is Feminist AI-]]
- [[Wudel_2025_What]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Structural Discrimination here*
