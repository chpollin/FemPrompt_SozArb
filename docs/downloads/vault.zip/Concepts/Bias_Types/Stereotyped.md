---
title: Stereotyped
category: Bias_Types
frequency: 2
papers: 1
tags: [concept, bias_types]
date_created: 2026-02-22
---

# Stereotyped

**Category:** Bias_Types  
**Mentioned:** 2 times across 1 papers

## Papers

- [[Qiu_2025_Mitigating]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Stereotyped here*
