---
title: Intersectional Spaces
category: Bias_Types
frequency: 2
papers: 1
tags: [concept, bias_types]
date_created: 2026-02-22
---

# Intersectional Spaces

**Category:** Bias_Types  
**Mentioned:** 2 times across 1 papers

## Papers

- [[Flexible intersectional stereotype extraction (FISE)- Analyzing intersectional biases in large language models]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Intersectional Spaces here*
