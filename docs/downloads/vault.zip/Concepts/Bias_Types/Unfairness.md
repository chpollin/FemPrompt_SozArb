---
title: Unfairness
category: Bias_Types
frequency: 5
papers: 2
tags: [concept, bias_types]
date_created: 2026-02-22
---

# Unfairness

**Category:** Bias_Types  
**Mentioned:** 5 times across 2 papers

## Papers

- [[Measuring and mitigating unintended bias in text data]]
- [[Ovalle_2023_Factoring]]

## Related Concepts

*Add related concepts here*

## Notes

*Add your notes about Unfairness here*
