---
title: Concept Frequency Analysis
type: analysis
tags: [analysis, frequency]
---

# Concept Frequency Analysis

## Most Frequent Concepts (All Categories)

1. [[Intersectionality]] - 193 mentions
1. [[Discrimination]] - 126 mentions
1. [[Debiasing]] - 103 mentions
1. [[Stereotyping]] - 73 mentions
1. [[Intersectional Accuracy]] - 58 mentions
1. [[Prompt Engineering]] - 56 mentions
1. [[Stereotype]] - 54 mentions
1. [[Algorithmic Bias]] - 43 mentions
1. [[Stereotypen]] - 40 mentions
1. [[Feminist AI]] - 32 mentions
1. [[Stereotypical]] - 22 mentions
1. [[Bias Mitigation]] - 18 mentions
1. [[Fine-tuning]] - 17 mentions
1. [[Algorithmic Discrimination]] - 14 mentions
1. [[Bias Evaluation]] - 13 mentions
1. [[Inclusive Ai]] - 11 mentions
1. [[Intersectional Stereotypes]] - 10 mentions
1. [[Stereotypische]] - 9 mentions
1. [[Prejudice]] - 8 mentions
1. [[Equitable Access]] - 7 mentions

## Frequency Distribution

- Rare (1): 40 concepts
- Low (2-4): 33 concepts
- High (10+): 17 concepts
- Medium (5-9): 13 concepts
